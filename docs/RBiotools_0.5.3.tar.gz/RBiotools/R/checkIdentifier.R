#' checkIdentifier
#'
#' Makes the use of Whole Genome Shotgun (WGS) sequencing project identifers (such as Prefix, Project, Caption, Locus, GenBank_assembly, and RefSeq_assembly) seamlessly interchangable when calling RBiotools functions.
#'
#' @param givenID character WGS sequencing project identifier
#'
#' @details For WGS identifiers, \code{checkIdentifier} examines the contents of the \code{wgsName.df} table to determine whether the WGS project is known to the current R session. If not, \code{checkIdentifier} uses \code{rentrez} functions that work with the NCBI Eutils API to search and download summary data for WGS projects from the GenBank Nucleotide and Assembly databases. These data are then parsed and the WGS identifers extracted are added as a new entry in \code{wgsName.df}. The "Locus" identifier is returned to the calling function, since it is the identifier that is used, when sequence integers are incorporated, to download contigs from a WGS project.
#'
#' \strong{Note:} It is likely that there are some situations in which \code{checkIdentifier} will fail. Prior to 2019, a WGS contig was identified by a 4-letter alphabetic prefix and a two-digit version for the WGS and then a six-digit sequence for the contig. From NCBI documentation, \emph{"In January 2019 GenBank began assigning accessions with a stable 6-letter WGS accession prefix and a \strong{minimum} of 9 digits, e.g., XXXXXX000000000, XXXXXX010000000, and XXXXXX010000001, for the wgs project, its first version, and its first sequence, respectively."} The current implementation of \code{checkIdentifier} assumes that the complete accession will be the 6-letter prefix followed by exactly 9 digits, 2 for version and 7 for sequence.
#'
#' \strong{Note:} In general, \code{checkIdentifier} finds the identifiers for the \emph{latest} version of a WGS sequencing project. It is possible, however, due to inconsistencies in the GenBank databases, that unexpected behavior will result, as in the example below, in which, there is a discrepancy in the identifiers extracted from GenBank. The "1" in WGS_Project and WGS_Locus indicates that the latest version of the WGS project is version 1, but the ".2" in GenBank_Assembly and RefSeq_Assembly indicates that the latest version of the WGS project is version 2. A search of the GenBank Assembly database for the term "GCF_000446905" finds two versions of a WGS sequencing project, an earlier version with project ID AIBS01 and 121 contigs and a later version, also with project ID AIBS01, and 120 contigs. A further search of the GenBank Nucleotide database finds contigs with identifiers AIBS01000001 - AIBS01000121, but no contigs with identifiers beginning with AIBS02. Calling the function \code{downloadGenBank} with the WGS_Locus "AIBS01000000" will return 121 contigs.
#'
#' @return character WGS sequencing project identifier
#'
#' @examples
#' \dontrun{
#' gbID <- "GCF_000446905"            # A RefSeq assembly identifier for a WGS project
#' wgsID <- checkIdentifier(gbID)     # Returns the WGS_Locus identifier "AIBS01000000" ...
#'    # ... and also writes the following into the wgsName.df data frame:
#'    #   WGS_Prefix         AIBS
#'    #   WGS_Project        AIBS01
#'    #   WGS_Caption        AIBS00000000
#'    #   WGS_Locus          AIBS01000000
#'    #   GenBank_Assembly   GCA_000446905.2
#'    #   RefSeq_Assembly    GCF_000446905.2
#'    #   contigs            120
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom rentrez entrez_search entrez_summary



checkIdentifier <- function(givenID)
{

  verbose <- FALSE     # Used primarily for debugging
                       # Make verbose a parameter with various levels?

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }
  
  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("wgsName.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)



  # Find the TYPE of the given identifier

  # Default - A complete genome identifier
  type <- 0


  # WGS Project
  #
  # From NCBI WGS documentation:
  #   Each WGS project is assigned a stable 4-letter WGS accession prefix, which does not change as the project is updated.
  #   If a WGS project's assigned accession number is XXXX00000000, then that project's first assembly version would be
  #   XXXX01000000, and the first contig of that version would be XXXX01000001. (The last six digits of this ID identify each
  #   individual contig). When there is more sequencing and the genome is reassembled, the contigs are submitted as the 02
  #   version of the WGS project. No linkage or relationship is expected between the old and new contigs, and the new contigs
  #   are given new accession numbers beginning with XXXX02000001. The 01 contigs are suppressed when the 02 contigs are
  #   released.
  #
  #   In January 2019 GenBank began assigning accessions with a stable 6-letter WGS accession prefix and a *** MINIMUM *** of
  #   9 digits, e.g., XXXXXX000000000, XXXXXX010000000, and XXXXXX010000001, for the wgs project, its first version, and its
  #   first sequence, respectively.
  #
  # Note: In addition to the WGS **ACCESSIONS**, there is also a WGS Project identifier (also, know as the WGS "prefix") that
  #   consists of the "WGS accession prefix" and the WGS project version. There is some inconsistency in the terminology.

  if ( grepl("^[[:upper:]]{4}$",            givenID)  || # A pre-2019 style WGS prefix ...
       grepl("^[[:upper:]]{4}[[:digit:]]+", givenID)     # ... another pre-2019 style WGS identifier
     )
  {
    type <- 1
  }

  else
  if ( grepl("^[[:upper:]]{6}$",            givenID)  || # A 2019+ style WGS prefix ...
       grepl("^[[:upper:]]{6}[[:digit:]]+", givenID)     # ... another 2019+ style WGS identifier
                                                         # TO DO: implementation for more than 7 digits, if necessary
     )
  {
    type <- 2
  }

  # else if (grepl("^[[:upper:]]{6}[[:digit:]]{2}$", givenID)) {    # A 2019+ WGS identifier with 7 digits after version
  #                                                                 # TO DO: implementation for more than 7 digits, if necessary
  #   type <- 2
  # }

  else
  if (grepl("^GCA_[[:digit:]]+", givenID)) {                 # A GenBank assembly accession number
    type <- 3
  }

  else
  if (grepl("^GCF_[[:digit:]]+", givenID)) {                 # A RefSeq assembly accession number
    type <- 4
  }




  # Process the identifier
  # ----------------------

  if (type == 0) {        # Complete genome accession
    if (verbose) {
      cat("Complete genome\n")
    }

    givenID <- gsub('\\.\\d$', '', givenID)     # remove version extension

    return(givenID)
  }



  # WGS pre-2019
  #-------------

  if (type == 1) {
    if (verbose) {
      cat("WGS pre-2019\n")
    }

    prefix <- substr(givenID,1,4)
    if (!any(wgsName.df$WGS_Prefix == prefix)) {   # There is no entry for this WGS in wgsName.df

      caption <- paste0(prefix, "00000000")

      project <- paste0(prefix, "01") # Assume project is version 1

      # Search the nucleotide database
      results <- entrez_search("nucleotide", caption)
      summary <- entrez_summary("nucleotide", id = results$ids)
      locus   <- gsub('.*\\|([A-Z]*\\d+)', '\\1', summary$extra)

      project <- substr(locus,1,6)

      # Search the assembly database
      results <- entrez_search (db = "assembly", term = project)
      summary <- entrez_summary(db = "assembly", id = results$ids)

      if (typeof(summary[[1]]) == "list") {   # Multiple versions ... find the latest
        latest <- 0
        for (i in 1:length(summary)) {
          if ("latest" %in% summary[[i]]$propertylist) {  #
            latest <- i
          }
        }
        if (latest == 0) { # latest not found, use the first
          summary <- summary[[1]]
        }
        else {
          summary <- summary[[latest]]
        }
      }

      genbank <- summary$synonym$genbank
      refseq  <- summary$synonym$refseq
      contigs   <- gsub('.*<Stat category=\\"contig_count\\" sequence_tag=\\"all\\">(\\d+)</Stat>.*', '\\1', c(summary$meta))
      scaffolds <- gsub('.*<Stat category=\\"scaffold_count\\" sequence_tag=\\"all\\">(\\d+)</Stat>.*', '\\1', c(summary$meta))


      if (verbose) {
        cat(paste0("  prefix:    ", prefix,    "\n"))
        cat(paste0("  project:   ", project,   "\n"))
        cat(paste0("  caption:   ", caption,   "\n"))
        cat(paste0("  locus:     ", locus,     "\n"))
        cat(paste0("  genbank:   ", genbank,   "\n"))
        cat(paste0("  refseq:    ", refseq,    "\n"))
        cat(paste0("  scaffolds: ", scaffolds, "\n"))
        cat(paste0("  contigs:   ", contigs,   "\n"))
      }

      newRow <- data.frame(WGS_Prefix       = prefix,
                           WGS_Project      = project,
                           WGS_Caption      = caption,
                           WGS_Locus        = locus,
                           GenBank_Assembly = genbank,
                           RefSeq_Assembly  = refseq,
                           GenomeID         = "",
                           scaffolds        = scaffolds,
                           contigs          = contigs,
                           stringsAsFactors = FALSE
                          )

      if (wgsName.df[1,]$WGS_Prefix == "NONE") {
        wgsName.df <<- newRow
      }
      else {
        wgsName.df <<- rbind(wgsName.df, newRow)
      }
    }

    else {  # There is an entry for this WGS in wgsName.df
      row <- wgsName.df$WGS_Prefix == prefix
      locus <- wgsName.df[row,]$WGS_Locus
    }

    return(locus)
  }


  # WGS 2019+
  #----------

  if (type == 2) {
    if (verbose) { cat("WGS 2019+\n") }

    prefix <- substr(givenID,1,6)   

    if (!any(wgsName.df$WGS_Prefix == prefix)) {   # There is no entry for this WGS in wgsName.df

      caption <- paste0(prefix, "000000000")       # Per NCBI documentation, 9 is the MINIMUM number of digits.
                                                   # If the following searches fail, a loop incrementally adding 0's may be necessary.

      project <- paste0(prefix, "01") # Assume project is version 1

      ## Search the nucleotide database
      results <- entrez_search("nucleotide", caption)
      summary <- entrez_summary("nucleotide", id = results$ids)
      locus   <- gsub('.*\\|([A-Z]*\\d+)', '\\1', summary$extra)

      project <- substr(locus,1,8)

      ## Search the assembly database
      results <- entrez_search (db = "assembly", term = project)
      summary <- entrez_summary(db = "assembly", id = results$ids)

      if (typeof(summary[[1]]) == "list") {   # Multiple versions ... find the latest
        latest <- 0
        for (i in 1:length(summary)) {
          if ("latest" %in% summary[[i]]$propertylist) {  #
            latest <- i
          }
        }
        if (latest == 0) { # latest not found, use the first
          summary <- summary[[1]]
        }
        else {
          summary <- summary[[latest]]
        }
      }

      genbank <- summary$synonym$genbank
      refseq  <- summary$synonym$refseq
      contigs   <- gsub('.*<Stat category=\\"contig_count\\" sequence_tag=\\"all\\">(\\d+)</Stat>.*', '\\1', c(summary$meta))
      scaffolds <- gsub('.*<Stat category=\\"scaffold_count\\" sequence_tag=\\"all\\">(\\d+)</Stat>.*', '\\1', c(summary$meta))

      if (verbose) {
        cat(paste0("  prefix:    ", prefix,    "\n"))
        cat(paste0("  project:   ", project,   "\n"))
        cat(paste0("  caption:   ", caption,   "\n"))
        cat(paste0("  locus:     ", locus,     "\n"))
        cat(paste0("  genbank:   ", genbank,   "\n"))
        cat(paste0("  refseq:    ", refseq,    "\n"))
        cat(paste0("  scaffolds: ", scaffolds, "\n"))
        cat(paste0("  contigs:   ", contigs,   "\n"))
      }

      newRow <- data.frame(WGS_Prefix       = prefix,
                           WGS_Project      = project,
                           WGS_Caption      = caption,
                           WGS_Locus        = locus,
                           GenBank_Assembly = genbank,
                           RefSeq_Assembly  = refseq,
                           GenomeID         = "",
                           scaffolds        = scaffolds,
                           contigs          = contigs,
                           stringsAsFactors = FALSE
                          )

      if (wgsName.df[1,]$WGS_Prefix == "NONE") {
        wgsName.df <<- newRow
      }
      else {
        wgsName.df <<- rbind(wgsName.df, newRow)
      }
    }

    else {  # There is an entry for this WGS in wgsName.df
      row <- wgsName.df$WGS_Prefix == prefix
      locus <- wgsName.df[row,]$WGS_Locus
    }

    return(locus)
  }




  if (type == 3) {
    if (verbose) {
      cat("GenBank assemby accession number\n")
    }

    genbank <- givenID
    genbank <- gsub('\\.\\d$', '', genbank)     # remove version extension for search

    # if (!any(wgsName.df$GenBank_Assembly == genbank)) {   # This is a new entry for wgsName.df

    row <- grepl(genbank, wgsName.df$GenBank_Assembly)    # row(s) that match refseq
    if (!any(row)) {                                      # This is a new entry for wgsName.df

      # Search the assembly database
      results <- entrez_search (db = "assembly", term = genbank)
      summary <- entrez_summary(db = "assembly", id = results$ids)

      if (typeof(summary[[1]]) == "list") {   # Multiple versions ... find the latest
        latest <- 0
        for (i in 1:length(summary)) {
          if ("latest" %in% summary[[i]]$propertylist) {  #
            latest <- i
          }
        }
        if (latest == 0) { # latest not found, use the first
          summary <- summary[[1]]
        }
        else {
          summary <- summary[[latest]]
        }
      }

      # Check assembly status
      # ---------------------
      assemblyStatus <- summary$assemblystatus

      if (assemblyStatus == "Complete Genome") {
        cat(paste0("Assembly Status: ", assemblyStatus, "\n"))

        # The only relevant identifiers in the Assembly database will be GenBank and RefSeq
        genbank <- summary$synonym$genbank
        cat(paste0("  genbank: ", genbank, "\n"))
        refseq <- summary$synonym$refseq
        cat(paste0("  refseq: ", refseq, "\n"))

        # Use the BioProject Accession number to search the nucleotide database
        bioSampleAccn <- summary$biosampleaccn
        results <- entrez_search (db = "nucleotide", term = bioSampleAccn)
        summary <- entrez_summary(db = "nucleotide", id = results$ids)
        if (typeof(summary[[1]]) == "list") {
          summary <- summary[[1]]
        }

        genomeID <- summary$caption
        cat(paste0("  GenomeID: ", genomeID, "\n"))

        newRow <- data.frame(WGS_Prefix       = "",
                             WGS_Project      = "",
                             WGS_Caption      = "",
                             WGS_Locus        = "",
                             GenBank_Assembly = genbank,
                             RefSeq_Assembly  = refseq,
                             GenomeID         = genomeID,
                             scaffolds        = 1,
                             contigs          = 1,
                             stringsAsFactors = FALSE
                          )

        if (wgsName.df[1,]$WGS_Prefix == "NONE") {
          wgsName.df <<- newRow
        }
        else {
          wgsName.df <<- rbind(wgsName.df, newRow)
        }

        return(genomeID)

      }


      else if (assemblyStatus == "Contig" || assemblyStatus == "Scaffold") {
        cat(paste0("Assembly Status: ", assemblyStatus, "\n"))

        if (typeof(summary[[1]]) == "list") {   # Multiple versions ... find the latest
          latest <- 0
          for (i in 1:length(summary)) {
            if ("latest" %in% summary[[i]]$propertylist) {  #
              latest <- i
            }
          }
          if (latest == 0) { # latest not found, use the first
            summary <- summary[[1]]
          }
          else {
            summary <- summary[[latest]]
          }
        }

        genbank <- summary$synonym$genbank
          # genbank <- gsub('\\.\\d$', '', genbank)     # remove version extension
        refseq  <- summary$synonym$refseq
          # refseq <- gsub('\\.\\d$', '', refseq)       # remove version extension

        project <- summary$wgs

        if (grepl("^[[:upper:]]{4}[[:digit:]]{2}", project)) {          # A pre-2019 WGS identifier
          prefix  <- substr(project,1,4)
          caption <- paste0(prefix,  "00000000")
          locus   <- paste0(project, "000000")
        }
        if (grepl("^[[:upper:]]{6}[[:digit:]]{2}", project)) {          # A 2019+ WGS identifier
          prefix  <- substr(project,1,6)
          caption <- paste0(prefix,  "000000000")
          locus   <- paste0(project, "0000000")
        }

        # Extract number of contigs from 'meta' (HTML markdown) in the assembly summary list
        contigs   <- gsub('.*<Stat category=\\"contig_count\\" sequence_tag=\\"all\\">(\\d+)</Stat>.*', '\\1', c(summary$meta))
        scaffolds <- gsub('.*<Stat category=\\"scaffold_count\\" sequence_tag=\\"all\\">(\\d+)</Stat>.*', '\\1', c(summary$meta))

        if (verbose) {
          cat(paste0("  prefix:    ", prefix,    "\n"))
          cat(paste0("  project:   ", project,   "\n"))
          cat(paste0("  caption:   ", caption,   "\n"))
          cat(paste0("  locus:     ", locus,     "\n"))
          cat(paste0("  genbank:   ", genbank,   "\n"))
          cat(paste0("  refseq:    ", refseq,    "\n"))
          cat(paste0("  scaffolds: ", scaffolds, "\n"))
          cat(paste0("  contigs:   ", contigs,   "\n"))
        }

        newRow <- data.frame(WGS_Prefix       = prefix,
                             WGS_Project      = project,
                             WGS_Caption      = caption,
                             WGS_Locus        = locus,
                             GenBank_Assembly = genbank,
                             RefSeq_Assembly  = refseq,
                             GenomeID         = "",
                             scaffolds        = scaffolds,
                             contigs          = contigs,
                             stringsAsFactors = FALSE
                            )

        if (wgsName.df[1,]$WGS_Prefix == "NONE") {
          wgsName.df <<- newRow
        }
        else {
          wgsName.df <<- rbind( wgsName.df, newRow)
        }
      }
    }

    else {
      #  row      <- wgsName.df$GenBank_Assembly == genbank

      if (sum(row) > 1) {   # The same GenBank identifier appears in multiple rows
         cat(paste0("The GenBank identifier ", genbank, " appears in multiple rows of wgsName.df"))
      }
      locus    <- wgsName.df[row,]$WGS_Locus
      genomeID <- wgsName.df[row,]$GenomeID
     }

     if (locus    != "") { return(locus)    }
     if (genomeID != "") { return(genomeID) }

  }




  if (type == 4) {
    if (verbose) {
      cat("RefSeq assemby accession number\n")
    }

    refseq <- givenID
    refseq <- gsub('\\.\\d$', '', refseq)     # remove version extension for search

    # if (!any(wgsName.df$RefSeq_Assembly == refseq))   # This is a new entry for wgsName.df

    row <- grepl(refseq, wgsName.df$RefSeq_Assembly)    # row(s) that match refseq
    if (!any(row)) {                                    # This is a new entry for wgsName.df

      # Search the assembly database
      results <- entrez_search (db = "assembly", term = refseq)
      summary <- entrez_summary(db = "assembly", id = results$ids)

      if (typeof(summary[[1]]) == "list") {   # Multiple versions ... find the latest
        latest <- 0
        for (i in 1:length(summary)) {
          if ("latest" %in% summary[[i]]$propertylist) {  #
            latest <- i
          }
        }
        if (latest == 0) { # latest not found, use the first
          summary <- summary[[1]]
        }
        else {
          summary <- summary[[latest]]
        }
      }

      # Check assembly status
      # ---------------------
      assemblyStatus <- summary$assemblystatus

      if (assemblyStatus == "Complete Genome") {
        cat(paste0("Assembly Status: ", assemblyStatus, "\n"))

        # The only relevant identifiers in the Assembly database will be GenBank and RefSeq
        genbank <- summary$synonym$genbank
        cat(paste0("  genbank: ", genbank, "\n"))
        refseq <- summary$synonym$refseq
        cat(paste0("  refseq: ", refseq, "\n"))

        # Use the BioProject Accession number to search the nucleotide database
        bioSampleAccn <- summary$biosampleaccn
        results <- entrez_search (db = "nucleotide", term = bioSampleAccn)
        summary <- entrez_summary(db = "nucleotide", id = results$ids)
        if (typeof(summary[[1]]) == "list") {
          summary <- summary[[1]]
        }

        genomeID <- summary$caption
        cat(paste0("  GenomeID: ", genomeID, "\n"))

        newRow <- data.frame(WGS_Prefix       = "",
                             WGS_Project      = "",
                             WGS_Caption      = "",
                             WGS_Locus        = "",
                             GenBank_Assembly = genbank,
                             RefSeq_Assembly  = refseq,
                             GenomeID         = genomeID,
                             scaffolds        = 1,
                             contigs          = 1,
                             stringsAsFactors = FALSE
                          )

        if (wgsName.df[1,]$WGS_Prefix == "NONE") {
          wgsName.df <<- newRow
        }
        else {
          wgsName.df <<- rbind(wgsName.df, newRow)
        }

        return(genomeID)

      }

      
      else if (assemblyStatus == "Contig" || assemblyStatus == "Scaffold") {
        cat(paste0("Assembly Status: ", assemblyStatus, "\n"))
      
        if (typeof(summary[[1]]) == "list") {   # Multiple versions ... find the latest
          latest <- 0
          for (i in 1:length(summary)) {
            if ("latest" %in% summary[[i]]$propertylist) {  #
              latest <- i
            }
          }
          if (latest == 0) { # latest not found, use the first
            summary <- summary[[1]]
          }
          else {
            summary <- summary[[latest]]
          }
        }

        genbank <- summary$synonym$genbank
          # genbank <- gsub('\\.\\d$', '', genbank)     # remove version extension
        refseq  <- summary$synonym$refseq
          # refseq <- gsub('\\.\\d$', '', refseq)       # remove version extension

        project <- summary$wgs

        if (grepl("^[[:upper:]]{4}[[:digit:]]{2}", project)) {          # A pre-2019 WGS identifier
          prefix  <- substr(project,1,4)
          caption <- paste0(prefix,  "00000000")
          locus   <- paste0(project, "000000")
        }
        if (grepl("^[[:upper:]]{6}[[:digit:]]{2}", project)) {          # A 2019+ WGS identifier
          prefix  <- substr(project,1,6)
          caption <- paste0(prefix,  "000000000")
          locus   <- paste0(project, "0000000")
        }

        # Extract number of contigs from 'meta' (HTML markdown) in the assembly summary list
        contigs   <- gsub('.*<Stat category=\\"contig_count\\" sequence_tag=\\"all\\">(\\d+)</Stat>.*', '\\1', c(summary$meta))
        scaffolds <- gsub('.*<Stat category=\\"scaffold_count\\" sequence_tag=\\"all\\">(\\d+)</Stat>.*', '\\1', c(summary$meta))

        if (verbose) {
          cat(paste0("  prefix:    ", prefix,    "\n"))
          cat(paste0("  project:   ", project,   "\n"))
          cat(paste0("  caption:   ", caption,   "\n"))
          cat(paste0("  locus:     ", locus,     "\n"))
          cat(paste0("  genbank:   ", genbank,   "\n"))
          cat(paste0("  refseq:    ", refseq,    "\n"))
          cat(paste0("  scaffolds: ", scaffolds, "\n"))
          cat(paste0("  contigs:   ", contigs,   "\n"))
        }

        newRow <- data.frame(WGS_Prefix       = prefix,
                             WGS_Project      = project,
                             WGS_Caption      = caption,
                             WGS_Locus        = locus,
                             GenBank_Assembly = genbank,
                             RefSeq_Assembly  = refseq,
                             GenomeID         = "",
                             scaffolds        = scaffolds,
                             contigs          = contigs,
                             stringsAsFactors = FALSE
                            )

        if (wgsName.df[1,]$WGS_Prefix == "NONE") {
          wgsName.df <<- newRow
        }
        else {
          wgsName.df <<- rbind(wgsName.df, newRow)
        }
      }
    }

    else {
      # row <- wgsName.df$RefSeq_Assembly == refseq

      if (sum(row) > 1) { # The same RefSeq identifier appears in multiple rows
        cat(paste0("The RefSeq identifier ", refseq, " appears in multiple rows of wgsName.df"))
      }
      locus    <- wgsName.df[row,]$WGS_Locus
      genomeID <- wgsName.df[row,]$GenomeID
    }

    if (locus    != "") { return(locus)    }
    if (genomeID != "") { return(genomeID) }

  }

  return(0)
}
