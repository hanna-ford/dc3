#' rnammer
#'
#' An R implementation of the widely-used ribosomal RNA gene prediction software tool for bacterial, archaeal, eukaryotic genomes.
#'
#' @references Lagesen et al. \emph{RNAmmer: consistent and rapid annotation of ribosomal RNA genes:} \url{https://doi.org/10.1093/nar/gkm160}
#'
#' @param seqSet DNAStringSet containing DNA sequence(s) to search for ribosomal RNA genes
#' @param dom    character Domain: "ARC" for Archaea, "BAC" for Bacteria, "EUK" for Eukarya
#' @param mol    character Molecule: "TSU" for 5/8s, "SSU" for 16/18s, "LSU" for 23/28s
#'
#' @details RNAmmer implements computational predictors for the major rRNA species from all kingdoms of life. The software uses hidden Markov models trained on data from the 5S ribosomal RNA database and the European ribosomal RNA database project. A pre-screening step makes the method fast with little loss of sensitivity. This implementation exists entirely in the R layer, including the hidden Markov models, with code written in R and C, integrated using the \code{Rcpp} package.
#'
#' \emph{\strong{Note:} \code{rnammer} will seldom, if ever, need to be called directly by the \code{RBiotools} user. \code{RBiotools} functions will automatically call \code{rnammer} when necessary.}
#'
#' @return allGenes.df -- a data frame with called genes, genomic coordinates, scores, and nucleotide sequences
#'
#' @examples
#' \dontrun{
#' org <- "U00096"                        # Escherichia coli str. K-12 substr. MG1655
#' genomeSeq <- GenomeSeqList[org][[org]] # fetch sequence from list of genomic sequences
#' geneCalls <- rnammer(genomeSeq)        # Call rnammer with a DNAStringSet
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings DNAString DNAStringSet reverseComplement
#' @importFrom Rcpp evalCpp




rnammer <- function(seqSet, dom, mol) {

  # seqSet - a DNAStringSet, the sequence(s) to search for rRNA
  # dom    - domain of life
  # mol    - specific rRNA molecule we're searching for

  if      (dom == "ARC") { domain = 0 }  # Archaea
  else if (dom == "BAC") { domain = 1 }  # Bacteria
  else if (dom == "EUK") { domain = 2 }  # Eukarya
  else                   { return (paste(dom, "is an unknown Domain. Choices are 'ARC' for Archaea, 'BAC' for Bacteria, 'EUK' for Eukarya")) }

  if      (mol== "TSU") { rRNA = 0 }   # 5/8s
  else if (mol== "SSU") { rRNA = 1 }   # 16/18s
  else if (mol== "LSU") { rRNA = 2 }   # 23/28s
  else                  { return (paste(mol, "is an unknown Molecule. Choices are 'TSU' for 5/8s, 'SSU' for 16/18s, 'LSU' for 23/28s")) }

  # Flanking regions around the small subunit ribosomal RNA (16S)

  FLANK_BEG_SSU <- 2500
  FLANK_END_SSU <- 2500

  # Initial data frame for rRNA from all sequences in seqSet

  allSeq.df <- data.frame()

  # Loop through all sequences in seqSet

  nSeq <- length(seqSet)
  for (i in 1:nSeq) {

    seq <- seqSet[i]
    rev <- reverseComplement(seq)

    # Find the directory where the RNAmmer HMM files are stored
    #   This is difficult to do from the C++ layer
    # We know the HMM for bacterial 16S will be in this directory

    knownFile <- "bac.ssu.rnammer.hmm"
    hmmDir <- sub(knownFile, "", system.file("extdata", knownFile, package = "RBiotools"))

    rrna.df <- as.data.frame(hmmAccess(as.character(seq), as.character(rev), domain, rRNA, hmmDir),stringsAsFactors=FALSE)
    rrna.df <- rrna.df[order(-rrna.df$score),]

    # Add to data frame: 1) sequence number, 2) domain, 3) molecule
  
    if (nrow(rrna.df) > 0) {
      rrna.df <- cbind(sequence = i, domain = dom, molecule = mol, rrna.df)
    }

    allSeq.df <- rbind(allSeq.df, rrna.df)

  }

  # Sort across all sequences and add rank determined by score

  if (nrow(allSeq.df) > 0) {
    allSeq.df <- allSeq.df[order(-allSeq.df$score),]
    allSeq.df <- cbind(rank = 1: nrow(allSeq.df), allSeq.df)
  }
  
  return(allSeq.df)
  
}
