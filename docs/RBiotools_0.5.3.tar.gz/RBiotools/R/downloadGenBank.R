#' downloadGenBank
#'
#' Downloads genomic information for a set of genomes into an RBiotools session
#'
#' @param accessionList character vector containing GenBank accession numbers
#'
#' @details This is a convenience function that determines whether each accession number in \code{accessionList} is associated with an organism or with a Whole Genome Shotgun (WGS) project and then calls either \code{downloadGenome} or \code{downloadWGS}. It uses the \code{rentrez} function \code{entrez_summary}, which works with the NCBI Eutils API to search the GenBank nucleotide database, to determine the type of download. It catches errors -- both from the user, such as invalid accession numbers, and from GenBank, such as violations of access policies (not expected) -- and skips any accession number that causes an error. \code{downloadGenBank} currently recognizes GenBank IDs for finished genomes and GenBank IDs, GenBank WGS assembly IDs, and RefSeq WGS assembly IDs for Whole Genome Shotgun projects.
#'
#' \emph{\strong{Note:} \code{downloadGenBank} will seldom, if ever, need to be called directly by the \code{RBiotools} user. \code{RBiotools} functions will automatically initiate downloads from GenBank, if necessary.}
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' accessionIDs <- c(
#'   "REQD01000000",  # Listeria monocytogenes strain PNUSAL004150 - a WGS project
#'   "CP015831"       # Escherichia coli O157 strain 644-PT8       - a finished genome
#' )
#'
#' downloadGenBank(accessionIDs)
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom rentrez entrez_search entrez_summary




downloadGenBank <- function(accessionList) {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)
  get("rRNAcalled.df", envir = .GlobalEnv)

  for (uncheckedID in accessionList) {   # The accessionList consists of unchecked IDs

    aaa <- checkIdentifier(uncheckedID)

    done <- !is.null(GenomeSeqList[[aaa]])

    if (done) {  ## Genome data HAS been downloaded
      cat(paste("Genome data for accession ID:", aaa, "has already downloaded\n"))
    }

    if (!done) {    ## Genome data has NOT been downloaded

      ## Download the genome data ...
      ## ... and insert sequence into the GenBankList as a DNAStringSet with the accession ID as its name

      ## Check the type of download ... organism or WGS

      goodDownload <- tryCatch(
        {
          summary <- entrez_summary(db = "nucleotide", id = aaa)
          flag <- TRUE
        },
        warning = function(w) {
          flag <- FALSE
        },
        error = function(e) {
          flag <- FALSE
        }
      )

      if (goodDownload) {   # valid accession ID
        title <- summary$title

        # This check seems to be a consistently good way to identify WGS sequencing projects
        if (grepl("whole genome shotgun sequencing project", title)) {
          downloadWGS(aaa)
        }
        else {
          downloadGenome(aaa)
        }
      }
      else {   # Not a good download, a warning or error was caught
        cat(paste0("In downloadGenBank: An error occured in downloading ", aaa, ", Skipping this download.\n"))
      }
    }
  }
}
