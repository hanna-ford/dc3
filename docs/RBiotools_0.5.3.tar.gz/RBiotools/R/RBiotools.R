#' RBiotools: An R package for comparative microbial genomic analysis
#'
#' The RBiotools package is a collection of object-oriented functions that work with sets of genome identifiers, such as GenBank accession numbers.
#' 
#' @references Vesth et al. \emph{CMG-Biotools, a Free Workbench for Basic Comparative Microbial Genomics} \url{http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0060120})
#' @references Hallin, Binnewies, and Ussery: \emph{The genome BLASTatlas—a GeneWiz extension for visualization of whole-genome homology} \url{http://pubs.rsc.org/en/content/articlelanding/2008/mb/b717118h/}
#' @references Ostrouchov, Chen, Schmidt, and Patel: \emph{Programming with Big Data in R}. 6th Extremely Large Databases Conference (XLDB), Stanford, CA, USA, September 2012.
#' @references Schmidt, Chen, Matheson, and Ostrouchov: \emph{Programming with BIG Data in R: Scaling Analytics from One to Thousands of Nodes}. Big Data Research, Volume 8, July 2017. \url{https://doi.org/10.1016/j.bdr.2016.10.002}
#' 
#' @section Future Development:
#' \itemize{
#'   \item{The current version of \code{RBiotools} implements the functionality of CMG-Biotools. The CMG-Biotools system, usually installed on a virtual machine, contains the GeneWiz browser to create and visualize genome atlases. The \code{RBiotools} function \code{createAtlas}, written entirely in R, creates an SVG file that can be opened with a browser to visualize the genome atlas. \code{createAtlas} currently produces basic genome atlases that display coding sequences and rRNA genes on the forward and reverse strands, as well as stacking energy, position preference, and GC-skew. Future versions of \code{createAtlas} will support additional analyses of genomic data and improved visualization capabilities.}
#'   \item {Future versions of \code{RBiotools} will integrate \strong{pbdR} (Programming with Big Data in R) packages to support utilization of high-performance computing (HPC) resources.}
#' }
#'
#' The \code{RBiotools} developers welcome
#' \itemize{
#'   \item{Reports of unexpected or faulty behavior in \code{RBiotools}}
#'   \item{Suggestions for streamlining and simplifying the use of \code{RBiotools}, for making \code{RBiotools} more intuitive, or for any other enhancements or modifications}
#'   \item{Suggestions for clarifying or improving \code{RBiotools} documentation}
#'   \item{Suggestions for additional \code{RBiotools} functionality, the highest priority being \strong{\emph{what is most useful to clinical researchers and experimental biologists}}}
#' }
#'
#' @details \code{RBiotools} is a collection of functions and data structures that support comparative microbial genomics analysis. It is intended for use by clinical researchers, experimental biologists, and students in microbial genomics courses. Design goals include to be simple and intuitive and to handle data conversion and manipulation seamlessly. The large majority of data is stored internally in global data structures, and reliance on external files is minimized. Most of the currently implemented functions require a single parameter, a set of one or more GenBank accession numbers. Additional parameters for the plotting functions are available to users to select alternative methods, to add custom titles, or to choose color palettes.
#' \code{RBiotools} functions fall into five categories:
#' \enumerate{
#'   \item \strong{Initialization} -- Initializing \code{RBiotools} global data structures prior to any \code{RBiotools} session
#'   \item \strong{Data Importation} -- Importing of genomic data, specifically genomic sequences and gene counts, downloaded to \code{RBiotools} from GenBank or uploaded to \code{RBiotools} from FASTA files
#'   \item \strong{Data Extraction} -- Fetching data from \code{RBiotools} global data structures for viewing or analysis
#'   \item \strong{Data Analysis} -- Analyzing genomic or derived data
#'   \item \strong{Data Visualization} -- Creating various plots and charts of genomic and derived data
#' } 
#' \strong{None of these functions must be called explicitly by users except the functions for creating plots and charts and the function for uploading user-supplied genomic data.} All other functions will be called automatically if initialization of global data structures is required, if data needs to be downloaded from GenBank, or if analysis of genomic data, such as gene calling, is necessary.
#'
#' @docType package
#' @name RBiotools
#'
"_PACKAGE"
