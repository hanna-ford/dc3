#include <Rcpp.h>
using namespace Rcpp;

#include <iostream>
#include <string>
#include <vector>

// Adapted from the code at GitHub:soedinglab/MMseqs2 (hereinafter refered to as "original C++ code") and described in
//   Nature Communications
//     Clustering huge protein sequence sets in linear time
//     Martin Steinegger and Johannes Söding
//     https://doi.org/10.1038/s41467-018-04964-5

// Copyright (c) 2021 Michael R. Leuze
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
//   documentation files (the "Software"), to deal in the Software without restriction, including without limitation
//   the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
//   to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//     * The above copyright notice and this permission notice shall be included in all copies or substantial portions
//       of the Software.
//     * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
//       TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//       THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
//       CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
//       DEALINGS IN THE SOFTWARE.



#define DEBUG 0
#define TEST_SEQ ULONG_MAX
// #define SIZE_T_MAX 18446744073709551615   // 2^64 - 1    <- equivalent to predefined ULONG_MAX

#define BIT_SET(a,b) ((a) | (1ULL<<(b)))
#define RoL(val, numbits) (val << numbits) ^ (val >> (32 - numbits))

short unsigned RAND[21] = { 0x4567, 0x23c6, 0x9869, 0x4873, 0xdc51, 0x5cff, 0x944a,
                            0x58ec, 0x1f29, 0x7ccd, 0x58ba, 0xd7ab, 0x41f2, 0x1efb,
                            0xa9e3, 0xe146, 0x007c, 0x62c2, 0x0854, 0x27f8, 0x231b};

#define HAMMING 0
#define SUBSTITUTION 1




// The BLOSUM62 substitution matrix for sequence alignment of proteins
//   Some of the functions in the original C++ code use ROUNDED integer values

double blosum62[21][21] = 
{
  {  3.9291, -0.4085, -1.7534, -0.8639, -2.2101,  0.1596, -1.6251, -1.3218, -0.7340, -1.4646, -0.9353, -1.5307, -0.8143, -0.8040, -1.4135,  1.1158, -0.0454, -0.1894, -2.5269, -1.7640, -1.0000 },
  { -0.4085,  8.5821, -3.4600, -3.6125, -2.3755, -2.5004, -2.9878, -1.2277, -3.0363, -1.2775, -1.4198, -2.6598, -2.7952, -2.9019, -3.3892, -0.8750, -0.8667, -0.8077, -2.3041, -2.4071, -1.0000 },
  { -1.7534, -3.4600,  5.7742,  1.5103, -3.4839, -1.3135, -1.1189, -3.1212, -0.7018, -3.6057, -3.0585,  1.2717, -1.4801, -0.3134, -1.6058, -0.2610, -1.0507, -3.1426, -4.2143, -3.0650, -1.0000 },
  { -0.8639, -3.6125,  1.5103,  4.9028, -3.1924, -2.1102, -0.1177, -3.1944,  0.7753, -2.8465, -1.9980, -0.2680, -1.1162,  1.8546, -0.1154, -0.1469, -0.8633, -2.4423, -2.8354, -2.0205, -1.0000 },
  { -2.2101, -2.3755, -3.4839, -3.1924,  6.0461, -3.1074, -1.2342, -0.1609, -3.0787,  0.4148,  0.0126, -2.9940, -3.5973, -3.1644, -2.7863, -2.3690, -2.1076, -0.8490,  0.9176,  2.9391, -1.0000 },
  {  0.1596, -2.5004, -1.3135, -2.1102, -3.1074,  5.5633, -2.0409, -3.7249, -1.5280, -3.6270, -2.6766, -0.4228, -2.1335, -1.7852, -2.3041, -0.2925, -1.5754, -3.1387, -2.4915, -3.0398, -1.0000 },
  { -1.6251, -2.9878, -1.1189, -0.1177, -1.2342, -2.0409,  7.5111, -3.2316, -0.7210, -2.7867, -1.5513,  0.5785, -2.1609,  0.4480, -0.2499, -0.8816, -1.6859, -3.1175, -2.3422,  1.6926, -1.0000 },
  { -1.3218, -1.2277, -3.1212, -3.1944, -0.1609, -3.7249, -3.2316,  3.9985, -2.6701,  1.5216,  1.1268, -3.2170, -2.7567, -2.7696, -2.9902, -2.3482, -0.7176,  2.5470, -2.5805, -1.3314, -1.0000 },
  { -0.7340, -3.0363, -0.7018,  0.7753, -3.0787, -1.5280, -0.7210, -2.6701,  4.5046, -2.4468, -1.3547, -0.1790, -1.0136,  1.2726,  2.1087, -0.2034, -0.6696, -2.2624, -2.9564, -1.8200, -1.0000 },
  { -1.4646, -1.2775, -3.6057, -2.8465,  0.4148, -3.6270, -2.7867,  1.5216, -2.4468,  3.8494,  1.9918, -3.3789, -2.8601, -2.1339, -2.1546, -2.4426, -1.1975,  0.7884, -1.6319, -1.0621, -1.0000 },
  { -0.9353, -1.4198, -3.0585, -1.9980,  0.0126, -2.6766, -1.5513,  1.1268, -1.3547,  1.9918,  5.3926, -2.1509, -2.4764, -0.4210, -1.3671, -1.4809, -0.6663,  0.6872, -1.4248, -0.9949, -1.0000 },
  { -1.5307, -2.6598,  1.2717, -0.2680, -2.9940, -0.4228,  0.5785, -3.2170, -0.1790, -3.3789, -2.1509,  5.6532, -2.0004,  0.0017, -0.4398,  0.6009, -0.0461, -2.8763, -3.6959, -2.0818, -1.0000 },
  { -0.8143, -2.7952, -1.4801, -1.1162, -3.5973, -2.1335, -2.1609, -2.7567, -1.0136, -2.8601, -2.4764, -2.0004,  7.3646, -1.2819, -2.1086, -0.8090, -1.0753, -2.3487, -3.6542, -2.9198, -1.0000 },
  { -0.8040, -2.9019, -0.3134,  1.8546, -3.1644, -1.7852,  0.4480, -2.7696,  1.2726, -2.1339, -0.4210,  0.0017, -1.2819,  5.2851,  0.9828, -0.1011, -0.6753, -2.1984, -1.9465, -1.4211, -1.0000 },
  { -1.4135, -3.3892, -1.6058, -0.1154, -2.7863, -2.3041, -0.2499, -2.9902,  2.1087, -2.1546, -1.3671, -0.4398, -2.1086,  0.9828,  5.4735, -0.7648, -1.1223, -2.5026, -2.6794, -1.6939, -1.0000 },
  {  1.1158, -0.8750, -0.2610, -0.1469, -2.3690, -0.2925, -0.8816, -2.3482, -0.2034, -2.4426, -1.4809,  0.6009, -0.8090, -0.1011, -0.7648,  3.8844,  1.3811, -1.6462, -2.7519, -1.6858, -1.0000 },
  { -0.0454, -0.8667, -1.0507, -0.8633, -2.1076, -1.5754, -1.6859, -0.7176, -0.6696, -1.1975, -0.6663, -0.0461, -1.0753, -0.6753, -1.1223,  1.3811,  4.5453, -0.0555, -2.4289, -1.6060, -1.0000 },
  { -0.1894, -0.8077, -3.1426, -2.4423, -0.8490, -3.1387, -3.1175,  2.5470, -2.2624,  0.7884,  0.6872, -2.8763, -2.3487, -2.1984, -2.5026, -1.6462, -0.0555,  3.7689, -2.8343, -1.2075, -1.0000 },
  { -2.5269, -2.3041, -4.2143, -2.8354,  0.9176, -2.4915, -2.3422, -2.5805, -2.9564, -1.6319, -1.4248, -3.6959, -3.6542, -1.9465, -2.6794, -2.7519, -2.4289, -2.8343, 10.5040,  2.1542, -1.0000 },
  { -1.7640, -2.4071, -3.0650, -2.0205,  2.9391, -3.0398,  1.6926, -1.3314, -1.8200, -1.0621, -0.9949, -2.0818, -2.9198, -1.4211, -1.6939, -1.6858, -1.6060, -1.2075,  2.1542,  6.5950, -1.0000 },
  { -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000, -1.0000 }
};


int bIdx[128] = { 21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,
                  21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,
                  21,21,21,21,21,21,21,21,21,21,12,21,21,21,21,21,
                  21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,
                  21, 0,21, 1, 2, 3, 4, 5, 6, 7,21, 8, 9,10,11,21,
                  12,13,14,15,16,21,17,18,20,19,21,21,21,21,21,21,
                  21, 0,21, 1, 2, 3, 4, 5, 6, 7,21, 8, 9,10,11,21,
                  12,13,14,15,16,21,17,18,20,19,21,21,21,21,21,21
                };

unsigned int computeSubstitutionDistance(char *seq1, char *seq2, unsigned int length) {

  int max = 0;
  int score = 0;

  for (unsigned int pos = 0; pos < length; pos++) {
    int curr = std::round(blosum62[bIdx[static_cast<int>(seq1[pos])]][bIdx[static_cast<int>(seq2[pos])]]);
        // Rcout << "seq1[" << pos << "]: " << seq1[pos] << " seq2[" << pos << "]: " << seq2[pos] << " curr: " << curr << "\n";
    score = curr  + score;
    score = (score < 0) ? 0 : score;
    max = (score > max)? score : max;
  }
  max = (max<0) ? 0 : max;

  return max;
}


unsigned int computeInverseHammingDistance(char *seq1, char *seq2, unsigned int length) {

  int diff = 0;

  for (unsigned int pos = 0; pos < length; pos++ ) {
    diff += (seq1[pos] == seq2[pos]);
  }

  return diff;
}



struct LocalAlignment{
  int startPos;                     // Not used for HAMMING or SUBSTITUTION  ???
  int endPos;                       // Not used for HAMMING or SUBSTITUTION  ???
  unsigned int score;
  unsigned int diagonalLen;
  unsigned int distToDiagonal;
  int diagonal;
};


LocalAlignment ungappedAlignmentByDiagonal(char *querySeq, unsigned int querySeqLen,
                                           char *dbSeq,    unsigned int dbSeqLen,
                                           int diagonal, int alnMode) {


  unsigned int minDistToDiagonal = abs(diagonal);
  LocalAlignment res;
  res.distToDiagonal = minDistToDiagonal;
  res.diagonal = diagonal;

  if (diagonal >= 0 && minDistToDiagonal < querySeqLen) {
    unsigned int minSeqLen = std::min(dbSeqLen, querySeqLen - minDistToDiagonal);
    res.diagonalLen = minSeqLen;
    if (alnMode == HAMMING) {
      res.score = computeInverseHammingDistance(querySeq + minDistToDiagonal, dbSeq, minSeqLen);
    }
    else if  (alnMode == SUBSTITUTION) {
      res.score = computeSubstitutionDistance( querySeq + minDistToDiagonal, dbSeq, minSeqLen);
    }
  }
  else if (diagonal < 0 && minDistToDiagonal < dbSeqLen) {
    unsigned int minSeqLen = std::min(dbSeqLen - minDistToDiagonal, querySeqLen);
    res.diagonalLen = minSeqLen;
    if (alnMode == HAMMING) {
      res.score = computeInverseHammingDistance (querySeq, dbSeq + minDistToDiagonal, minSeqLen);
    }
    else if  (alnMode == SUBSTITUTION) {
      res.score = computeSubstitutionDistance (querySeq, dbSeq + minDistToDiagonal, minSeqLen);
    }
  }

  return res;
}




// [[Rcpp::export]]

List computeLinclustDatasets(DataFrame DF, int ksize, int mode) {

  // DF - a dataframe with three columns:
  //      accession:  Organism GenBank accession number
  //      identifier: Gene "identifier" from the ProdicalCalls dataframe
  //      protein:    The amino acid sequence, "protein" from the ProdicalCalls dataframe, with final "*" removed
  //
  // ksize - the length of k-mers
  // mode 0: return "pre_clust" dataset
  //      1: return "pre_clust" and "pref_rescore2" datasets

  List seqID = DF["identifier"];
  List seqs  = DF["protein"];


  // DEBUGGING COUNTER
  int ungappedAlignmentCounter = 0;

  // ------------------- //
  // PART 1: kmermatcher //
  // ------------------- //

  // Table to translate ASCII character representations of amino acids to integers.
  // This table codes "the default [reduced amino acid] alphabet with A = 13,
  //   which performed well over all tested clustering sequences identities from 50% to 100%."
  //   (AST) (C) (BDN) (EQZ) (FY) (G) (H) (IV) (KR) (LM) (P) (W) (X)

  // Note that * is assigned 12, consistent with the original C++ code

  int aa2int[128] = { 20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
                      20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
                      20,20,20,20,20,20,20,20,20,20,12,20,20,20,20,20,
                      20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
                      20, 0, 2, 1, 2, 3, 4, 5, 6, 7,20, 8, 9, 9, 2,20,
                      10, 3, 8, 0, 0,20, 7,11,12, 4, 3,20,20,20,20,20,
                      20, 0, 2, 1, 2, 3, 4, 5, 6, 7,20, 8, 9, 9, 2,20,
                      10, 3, 8, 0, 0,20, 7,11,12, 4, 3,20,20,20,20,20
                    };

  // Powers of 12 used to compute int2index defined in prefiltering/Indexer.h

  long long powers[10] = { 1,
                           12,
                           144,
                           1728,
                           20736,
                           248832,
                           2985984,
                           35831808,
                           429981696,
                           5159780352
                         };


  // *************************************************
  // ************* STRUCTURE DEFINITIONS ************* 
  // *************************************************

  // ************* KmerPosition ************* 

  struct KmerPosition {      // KmerPosition is a template in original C++ code
      size_t        kmer;
      unsigned int  id;
      int           seqLen;
      int           pos;

      static bool compareRepSequenceAndIdAndPos(const KmerPosition &first, const KmerPosition &second){
        if (first.kmer < second.kmer)
          return true;
        if (second.kmer < first.kmer)
          return false;
        if (first.seqLen > second.seqLen)
          return true;
        if (second.seqLen > first.seqLen)
          return false;
        if (first.id < second.id)
          return true;
        if (second.id < first.id)
          return false;
        if (first.pos < second.pos)
          return true;
        if (second.pos < first.pos)
          return false;
        return false;
    }

    static bool compareRepSequenceAndIdAndDiag(const KmerPosition &first, const KmerPosition &second){
        if (first.kmer < second.kmer)
            return true;
        if (second.kmer < first.kmer)
            return false;
        if (first.id < second.id)
            return true;
        if (second.id < first.id)
            return false;
        if (first.pos < second.pos)
            return true;
        if (second.pos < first.pos)
            return false;
        return false;
    }

  };



  // ************* SequencePosition ************* 

  struct SequencePosition{
    short score;
    size_t kmer;
    unsigned int pos;

    static bool compareByScore(const SequencePosition &first, const SequencePosition &second){
      if(first.score < second.score)
        return true;
      if(second.score < first.score)
        return false;
      if(first.kmer < second.kmer)
        return true;
      if(second.kmer < first.kmer)
        return false;
      if(first.pos < second.pos)
        return true;
      if(second.pos < first.pos)
        return false;
      return false;
    }
  };



  // ************* hit_t ************* 

  struct hit_t {
    unsigned int seqId;
    int prefScore;
    // unsigned short diagonal;
    short diagonal;

    static bool compareHitsByScoreAndId(hit_t first, hit_t second){
      if (first.prefScore > second.prefScore )
        return true;
      if (second.prefScore > first.prefScore )
        return false;
      if (first.seqId < second.seqId )
        return true;
      if (second.seqId < first.seqId )
        return false;
      return false;
    }
  };



  int S = seqs.length();    // number of amino acid Sequences
  size_t kmersKept = 20;    // number of k-mers selected from each sequence (if sufficiently long)

  // Rcout << "number of sequences: " << S << "\n";
  // Rcout << "k-mers per sequence: " << kmersKept << "\n";


  const unsigned int BUFFER_SIZE = S * (kmersKept+1) + 10;   // should never exceed S * (kmersKept+1)
//size_t bufferPos = 0;
  unsigned int bufferPos = 0;

  KmerPosition * threadKmerBuffer = new KmerPosition[BUFFER_SIZE];


  int i,
      K,  // number of K-mers of length ksize in an amino acid sequence
      R;  // number of Residues (AA) in the sequence


  char c;
  int  j, x;

  unsigned short prevHash;
  unsigned int   prevFirstRes;

  size_t nextIndx;
  size_t res1, res2, res3, res4;    // used in computing int2index from AA group integers

  std::vector<int>              aaSeqInt(0);      // vector with the AA codes changed to the integer representations for the reduced AA alphabet 
  std::vector<short unsigned>   kmerHash(0);
  std::vector<size_t>           kmerIndx(0);
  std::vector<short>            score(0);
  std::vector<int>              includeKmer(0);   // logical (0,1) vector to exclude k-mers containing "X" or "*" from top kmers





  for (i = 0; i < S; i++) {

    // R = strlen(seqID[i]);
    // R = strlen(seqs[i]);

    // Rcout << i << ": " << R << "\n";

    SequencePosition * kmers = new SequencePosition[65537];    // hard-coded: 2^16 + 1

    // STEP 1: --------------------------------------------------------------------------------
    //   Translate the amino acids in the sequence to the corresponding reduced AA group number

    R = strlen(seqs[i]);
                                 // if (i < 200) {Rcout << "sequence " << i << " has " << R << " AA\n"; }
    char aaSeq[R];
    strcpy(aaSeq, seqs[i]);
                                 // if (i < 200) {Rcout << "aaSeq: " << aaSeq << "\n"; }

    aaSeqInt.clear(); // Remove all elements

    for (j = 0; j < R; j++) {
      c = (char) aaSeq[j];
      x = (int) c;
      aaSeqInt.push_back(aa2int[x]);
    }

    if (TEST_SEQ == i) {
      Rcout << "aaSeqInt (" << aaSeqInt.size() << "):";
      for (unsigned int z = 0; z < aaSeqInt.size(); z++)
        Rcout << " " << aaSeqInt[z];
      Rcout << "\n\n";
    }


    // STEP 2: -----------------------------------------------------------------------
    //   Check for k-mers containing "X" or "*", which will be excluded from top k-mers

    includeKmer.clear();

    K = R - ksize + 1;

    for (j = 0; j < K; j++) {
      size_t xCount = 0;
      for (size_t kpos = j; kpos < j+ksize; kpos++) {
        xCount += (aaSeqInt[kpos] == aa2int[(int) 'X']);
      }
      if (xCount > 0 ) { includeKmer.push_back(0); }
      else             { includeKmer.push_back(1); }
    }

    if (TEST_SEQ == i) {
      Rcout << "includeKmer (" << includeKmer.size() << "):";
      for (unsigned int z = 0; z < includeKmer.size(); z++)
        Rcout << " " << includeKmer[z];
      Rcout << "\n\n";
    }

    if (DEBUG > 0) {
      Rcout << "includeKmer (" << includeKmer.size() << "):\n";
      for (unsigned int z = 0; z < includeKmer.size(); z++)
        Rcout << " " << z << ": " << includeKmer[z] << "\n";
    }




    // STEP 3: -------------------------------------------
    //   Compute the hashes for each k-mer in the sequence

    kmerHash.clear(); // Remove all elements
    score.clear();    // Remove all elements

    // circular hash - for FIRST k-mer in sequence
    prevHash = 0;
    prevFirstRes = 0;

    short unsigned h = 0x0;
    h = h ^ RAND[aaSeqInt[0]];                    // XOR h and ki
    for (j = 1; j < ksize; ++j){
      h = RoL(h, 5);
      h ^= RAND[aaSeqInt[j]];                     // XOR h and ki
    }
    kmerHash.push_back(h);

    short s = h;
    score.push_back(s);

    prevHash = h;
    prevFirstRes = aaSeqInt[0];


    // circular hash next - for ALL SUBSEQUENT k-mers in sequence
    for (j = 1; j < K; j++) {
       h ^= RoL(RAND[prevFirstRes], (5*(ksize-1)) % 16);   // undo INITIAL_VALUE and first letter x[0] of old key
       h =  RoL(h, 5);                                     // circularly permute all letters x[1:length-1] to 5 positions to left
       h ^= RAND[aaSeqInt[j+ksize-1]];                     // add new, last letter of new key x[1:length]
       kmerHash.push_back(h);

       prevHash = h;
       prevFirstRes = aaSeqInt[j];
    }

    

    if (TEST_SEQ == i) {
      Rcout << "kmerHash:";
      for (unsigned int z = 0; z < kmerHash.size(); z++)
        Rcout << " " << kmerHash[z];
      Rcout << "\n\n";
    }


    // STEP 4: --------------------------------------------------------------
    //   Compute the indices for each set of <ksize> hashes from the sequence

    kmerIndx.clear(); // Remove all elements

    for (j = 0; j < K; j++) {               // This mirrors the C++ code ... a rather quirky way to accumulate an index
      res1  = aaSeqInt[j+0] * powers[0];
      res2  = aaSeqInt[j+1] * powers[1];
      res3  = aaSeqInt[j+2] * powers[2];
      res4  = aaSeqInt[j+3] * powers[3];
      res1 += aaSeqInt[j+4] * powers[4];
      res2 += aaSeqInt[j+5] * powers[5];
      res3 += aaSeqInt[j+6] * powers[6];
      res4 += aaSeqInt[j+7] * powers[7];
      res1 += aaSeqInt[j+8] * powers[8];
      res2 += aaSeqInt[j+9] * powers[9];
      nextIndx = res1 + res2 + res3 + res4;
      kmerIndx.push_back(nextIndx);

      (kmers + j)->kmer = nextIndx;       // Insert the kmer index into the kmers structure kmer element
    }



    if (TEST_SEQ == i) {
      Rcout << "kmerIndx:";
      for (unsigned int z = 0; z < kmerHash.size(); z++)
        Rcout << " " << kmerIndx[z];
      Rcout << "\n\n";
    }


    // STEP 5: ----------------------------------------------------------------------------------------------
    //   Compute the score, which is a conversion of the unsigned short kmerHash to a (signed) short variable
    //     The result for a value x < 32768 is unchanged
    //     The result for a value x > 32767 is (2^16 - x)

    score.clear(); // Remove all elements
    score.assign(kmerHash.begin(), kmerHash.end()); 

    for (j = 0; j < K; j++) {
      (kmers + j)->score = score[j];
    }


  
    if (TEST_SEQ == i) {
      Rcout << "score:";
      for (unsigned int z = 0; z < score.size(); z++)
        Rcout << " " << score[z];
      Rcout << "\n\n";
    }


    // STEP 6: ---------------------------------------------------------------------------------------------
    //   Add position to the kmers structure and sort the k-mers by "score", "kmer", and "pos" in that order

    // Keep only "valid" k-mers, that is, only k-mers that do not contain "X" or "*"

    SequencePosition * validKmers = new SequencePosition[65537];    // hard-coded: 2^16 + 1

    int validIndex = 0;
    for (j = 0; j < K; j++) {
      if (includeKmer[j]) {
        (validKmers + validIndex)->score = (kmers + j)->score;
        (validKmers + validIndex)->kmer  = (kmers + j)->kmer;
        (validKmers + validIndex)->pos   = validIndex;
        validIndex++;
      }
    }

    // Deallocate the kmers structure array
    delete [] kmers;

    // Reset the value of K to the number of included k-mers
    K = validIndex;

    if (DEBUG > 0) {
      Rcout << "K reset to " << validIndex << "\n";
    }

    if (DEBUG > 0) {
      Rcout << "STEP 6: " << K << " unsorted kmers:\n";
      Rcout << "score kmer pos:\n";
      for (j = 0; j < K; j++) {
        Rcout << (validKmers + j)->score << " " << (validKmers + j)->kmer << " " << (validKmers + j)->pos;
        if ((validKmers +j)->pos >= K) { Rcout << " *"; }
        Rcout << "\n";
      }
    }

    // Sort the kmers
    std::sort(validKmers, validKmers + K, SequencePosition::compareByScore);

    if (DEBUG > 0) {
      Rcout << K << " sorted kmers:\n";
      Rcout << "score kmer pos:\n";
      for (j = 0; j < K; j++) {
        Rcout << (validKmers + j)->score << " " << (validKmers + j)->kmer << " " << (validKmers + j)->pos;
        if ((validKmers +j)->pos >= K) { Rcout << " *"; }
        Rcout << "\n";
      }
    }


    // STEP 7: --------------------------------------------------------------------------
    //   Compute the identity hash, a "k-mer to represent the identity" for this sequence

    const size_t A = 31;

    size_t highestPossibleIndex = 67546215516;    // hard-coded
    size_t hh = 0;

    for (size_t ii = 0; ii < aaSeqInt.size(); ++ii) {
       hh = ((hh*A) + aaSeqInt[ii]);
    }

    size_t seqHash = highestPossibleIndex + static_cast<unsigned int>(hh);

    if (DEBUG > 1) { Rcout << "Sequence Identity Hash: " << seqHash << "\n"; }


    // STEP 8: ---------------------------------------------------------------
    //   Load the kmers into the threadKmerBuffer for more good stuff to come!

    // Load the sequence identity k-mer
    threadKmerBuffer[bufferPos].kmer   = seqHash;
    threadKmerBuffer[bufferPos].id     = i;
    threadKmerBuffer[bufferPos].pos    = 0;
    threadKmerBuffer[bufferPos].seqLen = R;

    bufferPos++;

    if (DEBUG > 2) {
      if (bufferPos >= BUFFER_SIZE) {
        Rcout << "bufferPos: " << bufferPos << " exceeds BUFFER_SIZE: " << BUFFER_SIZE << "\n";
      }
    }


    size_t topKmer = 0;
    size_t addKmer = 0;


    size_t kmersKeptAdj = kmersKept;
    if (kmersKeptAdj > K-1) {  // for short sequences, adjust the number of k-mers kept
      kmersKeptAdj = K-1;
    }

    while (addKmer < kmersKeptAdj) {
      if ((validKmers + topKmer)->pos > 0) {                                // Skip the first k-mer in the sequence, located at positon 0
                                                                            //   This makes sense, since the first AA will *always* be methionine
                                                                            //   so the first k-mer can be dropped with no loss of information
        threadKmerBuffer[bufferPos].kmer = (validKmers + topKmer)->kmer;
        threadKmerBuffer[bufferPos].id = i;
        threadKmerBuffer[bufferPos].pos = (validKmers + topKmer)->pos;
        threadKmerBuffer[bufferPos].seqLen = R;
        bufferPos++;   // buffer position filled

        if (DEBUG > 2) {
          if (bufferPos >= BUFFER_SIZE) {
            Rcout << "bufferPos: " << bufferPos << " exceeds BUFFER_SIZE: " << BUFFER_SIZE << "\n";
          }
        }

        addKmer++;     // k-mer was added to buffer
      }
      topKmer++;       // move to consider next k-mer
    }

    // Deallocate the validKmers structure array
    delete [] validKmers;

  }


  // Empty all vectors
  aaSeqInt.clear();
  includeKmer.clear();
  kmerHash.clear();
  score.clear();
  kmerIndx.clear();

// Rcout << "END PART 1\n";
// Rcout << "bufferPos: " << bufferPos << " BUFFER_SIZE: " << BUFFER_SIZE << "\n";



  // ----------------------- //
  // PART 2: rescoreDiagonal //
  // ----------------------- //

  
  // Sort the threadKmerBuffer
  std::sort(threadKmerBuffer, threadKmerBuffer + bufferPos, KmerPosition::compareRepSequenceAndIdAndPos);

  // Print the threadKmerBuffer
  if (DEBUG > 0) {
    Rcout << "Printing threadKmerBuffer values\n";
    for (unsigned int z = 0; z < bufferPos; z++) {
      Rcout <<         threadKmerBuffer[z].kmer;
      Rcout << "  " << threadKmerBuffer[z].id;
      Rcout << "  " << threadKmerBuffer[z].pos;
      Rcout << "  " << threadKmerBuffer[z].seqLen;
      Rcout << "\n";
    }
  }


  // Assign Group

//int           writePos          = 0;
  unsigned int  writePos          = 0;
  size_t        previousHash      = threadKmerBuffer[0].kmer;
  unsigned long repSeqId          = threadKmerBuffer[0].id;
  int           previousHashStart = 0;
  int           prevSetSize       = 0;

  int          queryLen          = threadKmerBuffer[0].seqLen;
  int          repSeq_i_pos      = threadKmerBuffer[0].pos;

// Rcout << "writePos: " << writePos << " previousHash: " << previousHash << " repSeqId: " << repSeqId << " previousHashStart: " << previousHashStart << "\n";
// Rcout << "  prevSetSize: " << prevSetSize << " queryLen: " << queryLen << " repSeq_i_pos: " << repSeq_i_pos << "\n";

  double covThr = 0.8;  // Parameter used in calculating "canBeCovered"

  KmerPosition * hashSeqPair = new KmerPosition[BUFFER_SIZE];  // BUFFER_SIZE is overkill. It's an upper bound on hashSeqPair size.

  // Initialize
  for (unsigned int z = 0; z < BUFFER_SIZE; z++) {
    hashSeqPair[z].kmer     = 0;
    hashSeqPair[z].id       = 0;
    hashSeqPair[z].seqLen   = 0;
  }

// Rcout << "hashSeqPair[].kmer\n";
// for (unsigned int z = 0; z < BUFFER_SIZE; z++) {
//   Rcout << z << ": " << hashSeqPair[z].kmer << "\n";
// }

  for (unsigned int kmerIdx = 0; kmerIdx < bufferPos; kmerIdx++) {

    size_t currKmer = threadKmerBuffer[kmerIdx].kmer;

// Rcout << "kmerIdx: " << kmerIdx << " currKmer: " << currKmer << " previousHash: " << previousHash << " bufferPos: " << bufferPos << "\n";

    if (previousHash != currKmer) {
// Rcout << " in IF clause -- previousHash: " << previousHash << " currKmer: " << currKmer << "\n";
      for (unsigned int z = previousHashStart; z < kmerIdx; z++) {
        size_t kmer = threadKmerBuffer[z].kmer;
        size_t rId = (kmer != ULONG_MAX) ? ((prevSetSize == 1) ? ULONG_MAX : repSeqId) : ULONG_MAX;

// Rcout << "  z: " << z << " kmer: " << kmer << " rId: " << rId << "\n";

        if (rId != ULONG_MAX) {     // There is more than one appearance of the kmer
// Rcout << "    more than 1 appearace of kmer ... ";
          int diagonal = repSeq_i_pos - threadKmerBuffer[z].pos;

          // Test for canBeExtended in original C++ code:
          //   canBeExtended = diagonal < 0 || (diagonal > (queryLen - hashSeqPair[i].seqLen));
          // Test for canBeCovered:
          //   canBeCovered = (queryLength / targetLength >= covThr) && (targetLength / queryLength >= covThr)
          //     where covThr = 0.8
          // Given the default parameter settings, **** only canBeCovered is relevant ****

          int targetLen = threadKmerBuffer[z].seqLen;

          bool canBeCovered = (static_cast<float>(queryLen) / static_cast<float>(targetLen) >= covThr)
                           && (static_cast<float>(targetLen) / static_cast<float>(queryLen) >= covThr);


          if (canBeCovered) {
// Rcout << " CAN be covered, assigning ...\n";
            hashSeqPair[writePos].kmer = rId; 
            hashSeqPair[writePos].id = threadKmerBuffer[z].id;
            hashSeqPair[writePos].seqLen = threadKmerBuffer[z].seqLen;
            hashSeqPair[writePos].pos = diagonal;
// Rcout << "    hashSeqPair[" << writePos << "]: " << hashSeqPair[writePos].kmer   << " "
//                                                  << hashSeqPair[writePos].id     << " "
//                                                  << hashSeqPair[writePos].seqLen << " "
//                                                  << hashSeqPair[writePos].pos    << "\n";

            writePos++;
          }
//           else { // some debugging output
// Rcout << "  CANNOT be covered\n";
//           }

        }
        hashSeqPair[z].kmer = (z != writePos - 1) ? ULONG_MAX : hashSeqPair[z].kmer;

// if (z == writePos - 1) {
//   Rcout << "    z EQUALS writePos - 1\n";
// }
// else {
//   Rcout << "    z DOES NOT EQUAL writePos - 1\n";
// }

//  Rcout << "    setting hashSeqPair[" << z << "].kmer = " << hashSeqPair[z].kmer << "\n";
      }
      prevSetSize = 0;
      previousHashStart =             kmerIdx;
      repSeqId =     threadKmerBuffer[kmerIdx].id;
      queryLen =     threadKmerBuffer[kmerIdx].seqLen;
      repSeq_i_pos = threadKmerBuffer[kmerIdx].pos;
// Rcout << "writePos: " << writePos << " previousHash: " << previousHash << " repSeqId: " << repSeqId << " previousHashStart: " << previousHashStart << "\n";
// Rcout << "  prevSetSize: " << prevSetSize << " queryLen: " << queryLen << " repSeq_i_pos: " << repSeq_i_pos << "\n";
    }

// Rcout << "  kmerIdx: " << kmerIdx << "\n";

    if (hashSeqPair[kmerIdx].kmer == ULONG_MAX) {
// Rcout << "    hashSeqPair[" << kmerIdx << "].kmer == ULONG_MAX " <<  hashSeqPair[kmerIdx].kmer << "\n";
      break;      
    }
    // Some DEBUGging
//     else {
// Rcout << "    hashSeqPair[" << kmerIdx << "].kmer != ULONG_MAX " << hashSeqPair[kmerIdx].kmer << "\n";
//     }



    prevSetSize++; 
    previousHash = threadKmerBuffer[kmerIdx].kmer; 

  }

  unsigned int z;

  // Print the hashSeqPair
  if (DEBUG > 0) {
    Rcout << "writePos = " << writePos << " BUFFER_SIZE: " << BUFFER_SIZE << "\n";
    Rcout << "Printing hashSeqPair values (unsorted)\n";
    for (z = 0; z < writePos; z++) {
      Rcout <<         hashSeqPair[z].kmer;
      Rcout << "  " << hashSeqPair[z].id;
      Rcout << "  " << hashSeqPair[z].seqLen;
      Rcout << "  " << hashSeqPair[z].pos;
      Rcout << "\n";
    }
  }


  // Sort the hashSeqPar array
  std::sort(hashSeqPair, hashSeqPair + writePos, KmerPosition::compareRepSequenceAndIdAndDiag);

  // Print the hashSeqPair
  if (DEBUG > 0) {
    Rcout << "writePos = " << writePos << " BUFFER_SIZE: " << BUFFER_SIZE << "\n";
    Rcout << "Printing hashSeqPair values (sorted)\n";
    for (z = 0; z < writePos; z++) {
      Rcout <<         hashSeqPair[z].kmer;
      Rcout << "  " << hashSeqPair[z].id;
      Rcout << "  " << hashSeqPair[z].seqLen;
      Rcout << "  " << hashSeqPair[z].pos;
      Rcout << "\n";
    }
  }



  // Process the hashSeqPair array to create the pref (a.k.a. pref_filter1 or prefResults) array of structures
  // ---------------------------------------------------------------------------------------------------------

  size_t  prefResultsMax = 5*S;                     // Allow space for 5 times the number of sequences in the prefResults array
  hit_t * prefResults = new hit_t[prefResultsMax];  // TO DO: Determine a tighter upper bound on prefResults


   std::vector<int> repSequence(S,0);               // vector to mark all sequences that are representative of a cluster
   std::vector<int> prefGroupSize(S,1);             // vector to hold group size for each representative sequence

  size_t prefIdx = 0;
  size_t hashIdx = 0;
  size_t hashIdxMax = writePos;

  while (hashIdx < hashIdxMax) {

     KmerPosition * groupBlock = new KmerPosition[100000];  // 100000 is probably overkill for this block size
                                                            // ... but we'll delete it soon
     int blockIdx = 0;

     size_t groupId = hashSeqPair[hashIdx].kmer;           // First entry in a group block

     while (hashSeqPair[hashIdx].kmer == groupId) {
       groupBlock[blockIdx].kmer   = hashSeqPair[hashIdx].kmer;
       groupBlock[blockIdx].id     = hashSeqPair[hashIdx].id;
       groupBlock[blockIdx].seqLen = hashSeqPair[hashIdx].seqLen;
       groupBlock[blockIdx].pos    = hashSeqPair[hashIdx].pos;
       blockIdx++;
       hashIdx++;
     }

     if (DEBUG > 1) {
       Rcout << "Block: " << hashIdx << " size: " << blockIdx << "\n";
       for (i = 0; i < blockIdx; i++) {
         Rcout << groupBlock[i].kmer   << " ";
         Rcout << groupBlock[i].id     << " ";
         Rcout << groupBlock[i].seqLen << " ";
         Rcout << groupBlock[i].pos    << "\n";
       }
     }

     // process the block

     // Insert the representative sequence into prefResults
     // ... all we need to know is the seqId ... other values are 0
     prefResults[prefIdx].seqId     = groupId;
     prefResults[prefIdx].prefScore = 0;
     prefResults[prefIdx].diagonal  = 0;
     prefIdx++;

     repSequence[groupId] = 1;

     i = 0;
     while (i < blockIdx) {
       if (groupBlock[i].id == groupId) { i++; }  // representative sequence, ignore
       else {
         int memberId = groupBlock[i].id;
         int score = 0;
         std::vector<int> diagonals(0);
         while (memberId == groupBlock[i].id) {
           score++;
           diagonals.push_back(groupBlock[i].pos);
           i++;
         }

         // Search for the most frequent diagonal value for this group member
         // Code modified slightly from
         // ... https://stackoverflow.com/questions/47515121/finding-the-most-frequent-numbers-in-a-c-vector

         int counter = 0;
         int element = 0;

         for (j = 0; j < diagonals.size(); j++) {
           int tempElement = diagonals[j];
           int tempCount = 0;
           for (int k = 0; k < diagonals.size(); k++) {
             if (diagonals[k] == tempElement) {
               tempCount++;
               if (tempCount >= counter) {   // >= means ties go to the latter
                 element = tempElement;
                 counter = tempCount;
               }
             }
           }
         }

         prefResults[prefIdx].seqId     = memberId;
         prefResults[prefIdx].prefScore = score;
         prefResults[prefIdx].diagonal  = element;
         prefIdx++;

         prefGroupSize[groupId]++;
       }
     }

     delete [] groupBlock;
  }

  // Add the non-representative sequences as representative sequences of groups with only one member
  for (i = 0; i < S; i++) {
    if (!repSequence[i]) {
      prefResults[prefIdx].seqId     = i;
      prefResults[prefIdx].prefScore = 0;
      prefResults[prefIdx].diagonal  = 0;
      prefIdx++;
    }
  }



  // Print the prefResults
  if (DEBUG > 1) {
    Rcout << "prefIdx = " << prefIdx << "\n";
    Rcout << "Printing pref values\n";
    for (unsigned int z = 0; z < prefIdx; z++) {
      Rcout <<         prefResults[z].seqId;
      Rcout << "  " << prefResults[z].prefScore;
      Rcout << "  " << prefResults[z].diagonal;
      Rcout << "\n";
    }
  }


  // Print the group sizes
  if (DEBUG > 1) {
    Rcout << "Printing group sizes for representative sequences\n";
    for (unsigned int z = 0; z < S; z++) {
      Rcout << z << ": " << prefGroupSize[z] << "\n";
    }
  }




  // Construct the pref_rescore1 table
  // ---------------------------------

  hit_t * pref_rescore1 = new hit_t[prefResultsMax];  // TO DO: Determine a tighter upper bound on pref_rescore1

  int
      dbSeqId,
      dbSeqLen,
      repSeqLen;

  std::vector<int> rescore1groupSize(S);   // group sizes for pref_rescore1
  std::vector<int> repSeqLoc1(S);          // vector to hold the location of each representative sequence in the pref_rescore1 list

  int prefRe1Idx = 0;
  int grpSize = 0;

// Rcout << "Trace of pref_rescore1 table construction:\n";

  for (i = 0; i < prefIdx; i++) {
    unsigned int seqId       = prefResults[i].seqId;
    int          seqScore    = prefResults[i].prefScore;
    short        seqDiagonal = prefResults[i].diagonal;

//  Rcout << "i: " << i << "  seqId: " << seqId << "  seqScore: " << seqScore << "  seqDiagonal: " << seqDiagonal << "\n";

    if (seqScore == 0 && seqDiagonal == 0) {   // this is a (new) representative sequence
      if (grpSize != 0) {   // i.e., if this is NOT the first representative sequence, record the size of the previous representative sequence
        rescore1groupSize[repSeqId] = grpSize;
// Rcout << "  rescore1groupSize[" << repSeqId << "]: " << grpSize << "\n";
      }

      repSeqId = seqId;
      grpSize = 1;
      pref_rescore1[prefRe1Idx].seqId     = repSeqId;
      pref_rescore1[prefRe1Idx].prefScore = 100;
      pref_rescore1[prefRe1Idx].diagonal  = 0;

      repSeqLoc1[repSeqId] = prefRe1Idx;  // store location of this representative sequence
      prefRe1Idx++;
    }
    else {
      repSeqLen = strlen(seqs[repSeqId]);

      dbSeqId   = seqId;
      dbSeqLen  = strlen(seqs[dbSeqId]);

// Rcout << "  repSeqLen: " << repSeqLen << "  dbSeqLen: " << dbSeqLen << "\n";

      char repSeq[repSeqLen+1];    // provide one additional space
      char dbSeq [dbSeqLen +1];    // provide one additional space

      strcpy(repSeq, seqs[repSeqId]);
      strcpy(dbSeq,  seqs[dbSeqId]);

      int diagonal = seqDiagonal;

      int alnMode = HAMMING;
      ungappedAlignmentCounter++;
      LocalAlignment tmp = ungappedAlignmentByDiagonal(repSeq, repSeqLen, dbSeq, dbSeqLen, diagonal, alnMode);

      // alignment threshold is 0.9, requiring an alignment score of 90 or greater
      int alignScore = static_cast<int>((static_cast<float>(tmp.score)/(static_cast<float>(tmp.diagonalLen)))*100);

      bool canBeCovered = (static_cast<float>(tmp.diagonalLen) / static_cast<float>(repSeqLen) >= covThr)
                       && (static_cast<float>(tmp.diagonalLen) / static_cast<float>(dbSeqLen)  >= covThr);


      if ((alignScore >= 90) && canBeCovered) {
        pref_rescore1[prefRe1Idx].seqId     = dbSeqId;
        pref_rescore1[prefRe1Idx].prefScore = alignScore;
        pref_rescore1[prefRe1Idx].diagonal  = tmp.diagonal;
        prefRe1Idx++;
        grpSize++;
      }
    }
  }

  rescore1groupSize[repSeqId] = grpSize;


  // Print the pref_rescore1 results
  if (DEBUG > 1) {
    Rcout << "Printing pref_rescore1 values\n";
    for (unsigned int z = 0; z < prefRe1Idx; z++) {
      Rcout <<         pref_rescore1[z].seqId;
      Rcout << "  " << pref_rescore1[z].prefScore;
      Rcout << "  " << pref_rescore1[z].diagonal;
      Rcout << "\n";
    }
  }

  // Print the group sizes
  if (DEBUG > 1) {
    Rcout << "Printing pref_rescore1 group sizes\n";
    for (unsigned int z = 0; z < S; z++) {
      Rcout << "size[" << z << "] = " << rescore1groupSize[z] << "\n";
    }
  }

  // Print the representative sequence locations in pref_rescore1
  if (DEBUG > 1) {
    Rcout << "Printing pref_rescore1 rep sequence location\n";
    for (unsigned int z = 0; z < S; z++) {
      Rcout << "loc[" << z << "] = " << repSeqLoc1[z] << "\n";
    }
  }



  // Find CLUSTERS of sequences
  // --------------------------


  // Sort the pref_rescore1 table
  // ----------------------------

  struct SeqIdLenGrp {      // a structure primarily for sorting sequences
    unsigned int seqId;
    int          seqLen;
    int          seqGrpSiz;

    static bool compareIdAndLen(const SeqIdLenGrp &first, const SeqIdLenGrp &second){
      if (first.seqLen > second.seqLen)
        return true;
      if (second.seqLen > first.seqLen)
        return false;
      if (first.seqId < second.seqId)
        return true;
      if (second.seqId < first.seqId)
        return false;
      return false;
    }

    static bool compareGrpAndLen(const SeqIdLenGrp &first, const SeqIdLenGrp &second){
      if (first.seqGrpSiz < second.seqGrpSiz)
        return true;
      if (second.seqGrpSiz < first.seqGrpSiz)
        return false;
      if (first.seqLen > second.seqLen)
        return false;
      if (second.seqLen > first.seqLen)
        return true;
      return false;
    }

    static bool compareGrpAndId(const SeqIdLenGrp &first, const SeqIdLenGrp &second){
      if (first.seqGrpSiz < second.seqGrpSiz)
        return true;
      if (second.seqGrpSiz < first.seqGrpSiz)
        return false;
      if (first.seqId < second.seqId)
        return true;
      if (second.seqId < first.seqId)
        return false;
      return false;
    }

    static bool compareGrpAndLenAndId(const SeqIdLenGrp &first, const SeqIdLenGrp &second){
      if (first.seqGrpSiz < second.seqGrpSiz)
        return true;
      if (second.seqGrpSiz < first.seqGrpSiz)
        return false;
      if (first.seqLen < second.seqLen)
        return true;
      if (second.seqLen < first.seqLen)
        return false;
      if (first.seqId < second.seqId)
        return true;
      if (second.seqId < first.seqId)
        return false;
      return false;
    }

  };

  // Create the SeqIdLenGrp structure ...
  SeqIdLenGrp * sortedSeq = new SeqIdLenGrp[S];

  // ... populate ...
  for (i = 0; i < S; i++) {
    sortedSeq[i].seqId     = i;
    sortedSeq[i].seqLen    = strlen(seqs[i]);
    sortedSeq[i].seqGrpSiz = 0;                 // to be filled later
  }

  // ... sort ...
  std::sort(sortedSeq, sortedSeq + S, SeqIdLenGrp::compareIdAndLen);


  // Create map between the sequence ID (seqId) and the location in list sorted by length and id (sizId)
  std::vector<int> seqId2sizId(S);
  std::vector<int> sizId2seqId(S);
  for (i = 0; i < S; i++) {
    int seqId = sortedSeq[i].seqId;
    sizId2seqId[i] = seqId;
    seqId2sizId[seqId] = i;
  }

  // Print the map tables
  if (DEBUG > 1) {
    Rcout << "seqId and sizId maps\n";
    for (unsigned int z = 0; z < S; z++) {
      int q = sizId2seqId[z];
      Rcout << "  " << "sizId2seqId[" << z << "] = " <<             q  << "\n";
      Rcout << "  " << "seqId2sizId[" << q << "] = " << seqId2sizId[q] << "\n";
    }
  }



  // Find the cluster size for each representative sequence
  //   This is done by merging groups whenever possible
  // ------------------------------------------------------

  // Determine the sizId for *every* entry in pref_rescore1

  std::vector<unsigned int> sizIdAtPos(prefRe1Idx); // vector to hold the ***sizId*** for each entry in pref_rescore1

  for (unsigned int z = 0; z < prefRe1Idx; z++) {
    sizIdAtPos[z] = seqId2sizId[pref_rescore1[z].seqId];
  }

  if (DEBUG > 1) {
    Rcout << "sizIdAtPos array:\n";
    for (unsigned int z = 0; z < prefRe1Idx; z++) {
      Rcout << z << ": " << sizIdAtPos[z] << "\n";
    }
  }


  // Determine the group size for each representative sequence (sizId) in pref_rescore1

  std::vector<unsigned int> grpBysizId(S); // vector to hold the group size for each sequence indexed by *sizId*

  for (unsigned int z = 0; z < S; z++) {
    grpBysizId[z] = rescore1groupSize[sizId2seqId[z]];
  }



  // Determine cluster sizes by merging groups

  std::vector <std::vector <unsigned int> > elementLookupTable(S);

  std::vector<unsigned int> clusterSize(S); // vector to hold the cluster size for each sequence

  for (i = 0; i < S; i++) {
    clusterSize[i] = 1;         // each sequence is in a cluster with itself
    elementLookupTable[i].push_back(i);
  }




  bool merging_groupsTRACE = false;

  if (merging_groupsTRACE) { Rcout << "Trace of merging groups ...\n"; } 

  i = 0;
  while (i < prefRe1Idx) {
    int rep = pref_rescore1[i].seqId;
    int grpSiz = rescore1groupSize[rep];

    if (merging_groupsTRACE) {
      Rcout << "rep:" << rep << "  group size: " << grpSiz << "\n";
    }
  
    for (j = 1; j < grpSiz; j++) {
      int mem = pref_rescore1[i+j].seqId;

      // update rep data
      clusterSize[rep]++;
      elementLookupTable[rep].push_back(mem);

      // update mem data
      clusterSize[mem]++;
      elementLookupTable[mem].push_back(rep);

      if (merging_groupsTRACE) {
          Rcout << "  mem:" << mem << " cluster size: " << clusterSize[mem] << "\n";
      }
    }

    if (merging_groupsTRACE) {
      Rcout << "rep:" << rep << " cluster size: " << clusterSize[rep] << "\n";
      Rcout << "------------\n\n";
    }

    i += grpSiz;
  }


  // Print the cluster sizes (using sizId)
  if (DEBUG > 1) {
    Rcout << "Printing cluster sizes: \n";
    for (unsigned int z = 0; z < S; z++) {
      Rcout <<  z << ": " << clusterSize[z] << "\n";
    }
  }


  // Print the elementLookupTable
  if (DEBUG > 1) {
    Rcout << "Printing elementLookupTable:\n";
    for (unsigned int x = 0; x < elementLookupTable.size(); x++) {
      Rcout << x << ":";
      for (unsigned int z = 0; z < elementLookupTable[x].size(); z++) {
        Rcout << " " << elementLookupTable[x][z];
      }
      Rcout << "\n";
    }
  }








  // Print the clusters
  if (DEBUG > 1) {
    Rcout << "Printing elementLookupTable: \n";
    for (i = 0; i < S; i++) {
      Rcout <<  i << ":\n";
      for (j = 0; j < clusterSize[i]; j++) {
        Rcout << "  " <<  elementLookupTable[i][j] << "\n";
      }
    }
  }

  // Reuse the sortedSeq array to include cluster size in the sorting process

  for (i = 0; i < S; i++) {
    sortedSeq[i].seqId     = i;                             // this is actually sizId
    sortedSeq[i].seqLen    = strlen(seqs[i]);               // DON'T translate sizId to seqId to get length
    sortedSeq[i].seqGrpSiz = elementLookupTable[i].size();  // cluster sizes were determined using sizId identifiers
  }



  // Sort the sortedSeq array ... so that it actually will be sorted!
  // 1) by group size
  // 2) by sequence length
  // 3) by sequence ID
  // from smallest to largest, in all cases

  std::sort(sortedSeq, sortedSeq + S, SeqIdLenGrp::compareGrpAndLenAndId);



  // Print the sortedSeq array
  if (DEBUG > 1) {
    Rcout << "Printing sortedSeq array: \n";
    for (i = 0; i < S; i++) {
      Rcout <<  i << ":\n";
      Rcout << "  seqId -     " <<  sortedSeq[i].seqId << "\n";
      Rcout << "  seqLen -    " <<  sortedSeq[i].seqLen << "\n";
      Rcout << "  seqGrpSiz - " <<  sortedSeq[i].seqGrpSiz << "\n";
    }
  }



  // Compute the pre_clust and order_redundancy files
  // ------------------------------------------------
  std::vector <unsigned int> pre_clust_entry(0);    // Ordered list of pre_clust entries
  std::vector <bool>         pre_clust_repseq(0);   //   Is the pre_clust entry a representative sequence
  std::vector <bool>         seen_before(S,0);      //   Has the sequence already been processed?

  std::vector <unsigned int> order_redundancy(0);
  std::vector <bool>         already_pushed(S,0);   //   Has the sequence already been added to order_redundancy?


  // The following code processes the sortedSeq array to produce the pre_clust dataset
  //   It appears to work VERY WELL:
  //   * Each sequence ID appears in pre_clust exactly ONE TIME
  //   * There are differences between this code and the original C++ code,
  //      for example, instances of a sequence assigned to different groups, that is,
  //      groups with different representative sequences. In several cases tested,
  //      the sequences aligned BETTER with their representative sequences in this code
  //      than with their representative sequences in the original C++ code.


  bool sortedSeqTRACE = false;

   if (sortedSeqTRACE) { Rcout << "Printing pre_clust trace:\n"; }

  // Process the sortedSeq array in reverse order
  //   so that the largest groups, longest sequences, and largest sequence IDs are processed first

  for (i = S-1; i >= 0; i--) {

    if (sortedSeqTRACE) { Rcout << "iteration: " << i << "\n"; }

    unsigned int seqId    = sortedSeq[i].seqId;
    unsigned int clustSiz = sortedSeq[i].seqGrpSiz;

    if (sortedSeqTRACE) { 
      Rcout << "  seqId:       " << seqId << "\n";
      Rcout << "  seq length:  " << strlen(seqs[seqId]) << "\n";
      Rcout << "  seq length2: " << sortedSeq[i].seqLen << "\n";
      Rcout << "  clustSiz:    " << clustSiz << "\n";
      Rcout << "  seen_before: " << seen_before[seqId] << "\n";
    }

    if (seen_before[seqId] == 0) {  // This REPRESENTATIVE sequence has NOT been seen before
                                    //   as a MEMBER of another group

      if (sortedSeqTRACE) { Rcout << "  adding " << seqId << " as rep seq\n"; }

      pre_clust_entry.push_back(seqId);
      pre_clust_repseq.push_back(true);

      if (already_pushed[seqId] == 0) {
        order_redundancy.push_back(seqId);  // Add all SELECTED representative sequences ...
                                            // ... those that are NOT a member of an added group ...
                                            // to order_redundancy
        already_pushed[seqId] = 1;
      }

      for (j = 1; j < clustSiz; j++ ) {

        unsigned int memberId = elementLookupTable[seqId][j];

        if (seen_before[memberId] == 0) {

          if (sortedSeqTRACE) { Rcout << "  adding " << memberId << " as mem seq\n"; }

          pre_clust_entry.push_back(memberId);
          pre_clust_repseq.push_back(false);
        
          seen_before[memberId] = 1;
        }
        else {  // This MEMBER sequence HAS been seen before
                //   Add it to order_redundancy, if not already there

          if (already_pushed[memberId] == 0) {
            order_redundancy.push_back(memberId);
            already_pushed[memberId] = 1;
          }
        }
      }
    }
    else {
      if (sortedSeqTRACE) { Rcout << "  skipping " << seqId << " as rep seq\n"; }
    }
  }
  



  // Sorting order_redundancy
  std::sort (order_redundancy.begin(), order_redundancy.end());


  if (DEBUG > 1) {
    Rcout << "Printing the pre_clust file: \n";
    for (i = 0 ; i < S; i++) {
      if (pre_clust_repseq[i]) {
        Rcout << pre_clust_entry[i] << "\n";
      }
      else {
        Rcout << "* " << pre_clust_entry[i] << "\n";
      }
    }
  }

  if (DEBUG > 1) {
     Rcout << "Printing the order_redundancy file: \n";
     for (i = 0; i < order_redundancy.size(); i++) {
       Rcout << order_redundancy[i] << "\n";
     }
   }

   if (DEBUG > 1) {
     Rcout << "Printing sequences missing from the order_redundancy file: \n";
     for (i = 0; i < S; i++) {
       if (!(std::find(order_redundancy.begin(), order_redundancy.end(), i) != order_redundancy.end())) {
         Rcout << i << "\n";
       }
     }
   }


  // Setting up return of pre_clust
  //   Note change from "pre_clust" to "preClust"
  //     to avoid "error: redefinition"

  IntegerVector preClust_seqId(S);
  LogicalVector preClust_repseq(S);

  for (i = 0; i < S; i++) {
    preClust_seqId[i]  = pre_clust_entry[i];
    preClust_repseq[i] = pre_clust_repseq[i];
  }



  // "FAST" mode return
  // ------------------
  if (mode == 0) {
    // Rcout << "FAST return ...\n";
    return Rcpp::List::create(Rcpp::Named("preClust_seqId")  = preClust_seqId,
                              Rcpp::Named("preClust_repseq") = preClust_repseq);
  }




  // Continue to compute the datasets necessary for Smith-Waterman alignment
  // -----------------------------------------------------------------------


  // Compute the pref_filter2 file
  //  pref_filter2 is identical to pref_filter1 (which is identical to pref)
  //    with all seqId's NOT in order_redundancy removed


  // NOTE: It is not necessary to keep track of group sizes
  //   since ALL (and ONLY) representative sequences will have both
  //   * prefScore == 0
  //   * diagonal == 0

  bool pref_filter2TRACE = FALSE;

  hit_t * pref_filter2 = new hit_t[prefIdx];  // This is a loose bound, since pref_filter2 will be smaller than pref
  std::vector<int> filter2groupSize(S,0);     // vector to hold the size of group for each representative sequence

  size_t prefIdx2 = 0;

  i = 0;
  while (i < prefIdx) {
    unsigned int prefSeqId = prefResults[i].seqId;
    int oldGrpSiz = prefGroupSize[prefSeqId];

    if (pref_filter2TRACE) { Rcout << "rep seq: " << prefSeqId << "  group size: " << oldGrpSiz << "\n"; }

    int newGrpSiz = 0;

    // binary search works (and is fast) since order_redundancy is sorted
    if (std::binary_search (order_redundancy.begin(), order_redundancy.end(), prefSeqId)) {

      if (pref_filter2TRACE) { Rcout << "  adding rep seq & group\n"; }

      pref_filter2[prefIdx2].seqId     = prefResults[i].seqId;
      pref_filter2[prefIdx2].prefScore = prefResults[i].prefScore;
      pref_filter2[prefIdx2].diagonal  = prefResults[i].diagonal;
      prefIdx2++;
      newGrpSiz++;
      if (oldGrpSiz > 1) {
        for (j = 1; j < oldGrpSiz; j++) {
          unsigned int memberId = prefResults[i+j].seqId;

          if (pref_filter2TRACE) { Rcout << "  mem seq: " << memberId << "\n"; }

          if (std::binary_search (order_redundancy.begin(), order_redundancy.end(), memberId)) {
            if (pref_filter2TRACE) { Rcout << "    adding mem seq\n"; }
            pref_filter2[prefIdx2].seqId     = prefResults[i+j].seqId;
            pref_filter2[prefIdx2].prefScore = prefResults[i+j].prefScore;
            pref_filter2[prefIdx2].diagonal  = prefResults[i+j].diagonal;
            prefIdx2++;
            newGrpSiz++;
          }
          else { // Member sequence NOT in order_redundancy ... remove the member only
            if (pref_filter2TRACE) { Rcout << "    missing ... skipping member\n"; }
          }
        }
      }
      filter2groupSize[prefSeqId] = newGrpSiz;

      if (pref_filter2TRACE) { Rcout << "  new group size: " <<  filter2groupSize[prefSeqId] << "\n"; }
    }

    else { // Representitive sequence NOT in order_redundancy ... remove the entire group

      if (pref_filter2TRACE) { Rcout << "  missing ... skipping group\n"; }
      filter2groupSize[prefSeqId] = 0;
      if (pref_filter2TRACE) { Rcout << "  new group size: " <<  filter2groupSize[prefSeqId] << "\n"; }
    }

    i += oldGrpSiz;
  }


  // Print pref_filter2
  if (DEBUG > 0) {
    Rcout << "Printing pref_filter2:\n";
    for (unsigned int z = 0; z < prefIdx2; z++) {
      Rcout <<         pref_filter2[z].seqId;
      Rcout << "  " << pref_filter2[z].prefScore;
      Rcout << "  " << pref_filter2[z].diagonal;
      Rcout << "\n";
    }

    Rcout << "Printing pref_filter2 group sizes:\n";
    for (unsigned int z = 0; z < S; z++) {
      Rcout << z << ": " << filter2groupSize[z] << "\n";
    }
  }





  // Construct the pref_rescore2 table
  // ---------------------------------

  hit_t * pref_rescore2 = new hit_t[prefResultsMax];  // TO DO: Determine a tighter upper bound on pref_rescore2
                                                      // TO DO: Improve scoping in this section

  std::vector<int> rescore2groupSize(S);   // group sizes for pref_rescore2
  std::vector<int> repSeqLoc2(S);          // vector to hold the location of each representative sequence in the pref_rescore2 list

  int prefRe2Idx = 0;
      grpSize    = 0;

  // Values determined by reverse engineering the original C++ version
  double lambda =  0.3207378152604;
  double logK   = -1.9729463569813;

  bool pref_rescore2TRACE = FALSE;

  for (i = 0; i < prefIdx2; i++) {
    unsigned int seqId       = pref_filter2[i].seqId;
    int          seqScore    = pref_filter2[i].prefScore;
    short        seqDiagonal = pref_filter2[i].diagonal;

    if (seqScore == 0 && seqDiagonal == 0) {   // this is a (new) representative sequence
      if (grpSize != 0) {  // i.e., if this is NOT the first representative sequence,
                           //   record the size of the previous representative sequence
        rescore2groupSize[repSeqId] = grpSize;
        if (pref_rescore2TRACE) { Rcout << "i: " << i << "  setting rescore2groupSize[" << repSeqId << "] to " << grpSize << "\n"; }

      }

      // Score the alignment of the representative sequence with itself
      repSeqId  = seqId;
      repSeqLen = strlen(seqs[repSeqId]);

      if (pref_rescore2TRACE) { Rcout << "i: " << i << "  rep: " << repSeqId << "  length: " << repSeqLen << "\n"; }

      char repSeq[repSeqLen+1];    // provide one additional space
      strcpy(repSeq, seqs[repSeqId]);

      int alnMode = SUBSTITUTION;
      ungappedAlignmentCounter++;
      LocalAlignment tmp = ungappedAlignmentByDiagonal(repSeq, repSeqLen, repSeq, repSeqLen, 0, alnMode);

      int bitScore = static_cast<int>(((lambda * tmp.score - logK)/log(2.0))+0.5);
      if (pref_rescore2TRACE) { Rcout << "  bitScore: " << bitScore << "\n"; }

      pref_rescore2[prefRe2Idx].seqId     = repSeqId;
      pref_rescore2[prefRe2Idx].prefScore = bitScore;
      pref_rescore2[prefRe2Idx].diagonal  = 0;

      grpSize = 1;

      repSeqLoc2[repSeqId] = prefRe2Idx;  // store location of this representative sequence
      prefRe2Idx++;
    }
    else {
      // This is a non-representative member sequence
      dbSeqId  = seqId;
      dbSeqLen = strlen(seqs[dbSeqId]);

      if (pref_rescore2TRACE) { Rcout << "  mem: " << dbSeqId << "  length: " << dbSeqLen << "\n"; }

      char repSeq[repSeqLen+1];    // provide one additional space
      char dbSeq [dbSeqLen +1];    // provide one additional space
      strcpy(repSeq, seqs[repSeqId]);
      strcpy(dbSeq,  seqs[dbSeqId]);

      int diagonal = seqDiagonal;

      int alnMode = SUBSTITUTION;
      ungappedAlignmentCounter++;
      LocalAlignment tmp = ungappedAlignmentByDiagonal(repSeq, repSeqLen, dbSeq, dbSeqLen, diagonal, alnMode);

      double currScorePerCol = static_cast<double>(tmp.score) / static_cast<double>(tmp.diagonalLen); 

      if (currScorePerCol >= 2.4) {  // 2.4 = value of scorePerColThr in original C++ code

        int bitScore = static_cast<int>(((lambda * tmp.score - logK)/log(2.0))+0.5);

        if (pref_rescore2TRACE) {
          Rcout << "    bitScore: " << bitScore << "\n";
          Rcout << "    diagonal: " << diagonal << "\n";
        }

        pref_rescore2[prefRe2Idx].seqId     = dbSeqId;
        pref_rescore2[prefRe2Idx].prefScore = bitScore;
        pref_rescore2[prefRe2Idx].diagonal  = diagonal;

        grpSize++;

        prefRe2Idx++;
      }
    }
  }

if (FALSE) {
  // Set the size of the previous (final) representative sequence
  rescore2groupSize[repSeqId] = grpSize;
  if (pref_rescore2TRACE) { Rcout << "Final i: " << i << "  setting rescore2groupSize[" << repSeqId << "] to " << grpSize << "\n"; }
}





  // Print pref_rescore2
  if (DEBUG > 0) {
    Rcout << "Printing pref_rescore2 values\n";
    for (unsigned int z = 0; z < prefRe2Idx; z++) {
      Rcout <<         pref_rescore2[z].seqId;
      Rcout << "  " << pref_rescore2[z].prefScore;
      Rcout << "  " << pref_rescore2[z].diagonal;
      Rcout << "\n";
    }
  }


  // Print pref_rescore2 group sizes
  if (DEBUG > 0) {
    Rcout << "Printing pref_filter2 group sizes\n";
    for (unsigned int z = 0; z < S; z++) {
      Rcout << z << ": " << rescore2groupSize[z] << "\n";
    }
  }






  // Erase elementLookupTable
  for (i = 0; i < S; i++) {
    elementLookupTable[i].clear();
  }





  // SET UP RETURN

  IntegerVector pref_rescore2_seqId(prefRe2Idx);
  IntegerVector pref_rescore2_prefScore(prefRe2Idx);
  IntegerVector pref_rescore2_diagonal(prefRe2Idx);
  IntegerVector pref_rescore2_groupSize(S);

  for (i = 0; i < prefRe2Idx; i++) {
    pref_rescore2_seqId[i]     = pref_rescore2[i].seqId;
    pref_rescore2_prefScore[i] = pref_rescore2[i].prefScore;
    pref_rescore2_diagonal[i]  = pref_rescore2[i].diagonal;
  }

  for (i = 0; i < S; i++) {
    pref_rescore2_groupSize[i]  = rescore2groupSize[i];
  }



  // DEALLOCATE

  // Deallocate the threadKmerBuffer structure array
  delete [] threadKmerBuffer;

  // Deallocate the hashSeqPair structure array
  delete [] hashSeqPair;

  // Deallocate the prefResults structure array
  delete [] prefResults;

  Rcout << "Number of ungapped alignments: " << ungappedAlignmentCounter << "\n";


  // "SLOW" mode return
  // ------------------
  // Rcout << "SLOW return ...\n";
  return Rcpp::List::create(Rcpp::Named("preClust_seqId")          = preClust_seqId,
                            Rcpp::Named("preClust_repseq")         = preClust_repseq,
                            Rcpp::Named("pref_rescore2_seqId")     = pref_rescore2_seqId,
                            Rcpp::Named("pref_rescore2_prefScore") = pref_rescore2_prefScore,
                            Rcpp::Named("pref_rescore2_diagonal")  = pref_rescore2_diagonal,
                            Rcpp::Named("pref_rescore2_groupSize") = pref_rescore2_groupSize);

}
