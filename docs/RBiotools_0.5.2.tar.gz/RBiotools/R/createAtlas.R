#' createAtlas
#'
#' Creates an SVG file in the working directory containing a Genome Atlas figure for a specified organism
#'
#' @param organismAccession
#'
#' @details \code{createAtlas} creates a Genome Atlas for an organism specified by a GenBank accession number. Required data include the genome sequence, protein gene coordinates and strand, and rRNA gene coordinates and strand. If these data are not found in the \code{RBiotools} global data structures, they will automatically be downloaded or derived.
#' @section Lanes currently implemented:
#' \itemize{
#'   \item \code{Genomic sequence coordinate scale}
#'   \item \code{Percent AT}
#'   \item \code{GC skew}
#'   \item \code{Annotations:}
#'   \item \code{   Protein coding sequences on forward and reverse strands}
#'   \item \code{   Ribosomal RNA sequences on forward and reverse strands}
#'   \item \code{Position preference}
#'   \item \code{Stacking energy}
#' }
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' createAtlas("CP001859") # Acidaminococcus fermentans DSM 20731
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings countPattern width
#' @importFrom stats      smooth


createAtlas <- function(organismAccession) {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }



  organismAccession <- checkIdentifier(organismAccession)  # This statement will only change an identifer for a WGS sequencing project.
                                                           # It probably doesn't make (much) sense to create a Genome Atlas for a WGS,
                                                           # ... but, maybe later ...

  if (grepl("^[[:upper:]]{4}", organismAccession)) { # accession ID begins with 4 or more alphabetic characters, probably WGS
    paste0(organismAccession, " is a WGS sequence project identifier. createAtlas currently works only for complete genomes.")
  }
  else { # Should be a complete genome ...

  # Constants

  APPROACH <- "HIST"  # HIST ... strictly by rank
                      # PROB ... rank according to probability distribution of values
                      # COMP ... computed linearly between maximum and minimum values

  MODE     <- "AVGV"  # AVGV ... section value is the average of the feature values within the section
                      # MAXV ... section value is the maximum of the feature values within the section
                      # MINV ... section value is the minimum of the feature values within the section

  SMOOTH <- TRUE




  MINARC  <- 0.05     # Increased from 0.005 in Genewiz code
  CENTERX <-  275
  CENTERY <- -300

  GENE_WIDTH <- 6

  OFFSET_Scale      <- 100

  OFFSET_reverse <- 115.5
  OFFSET_divider <- 120
  OFFSET_forward <- 124.5

  OFFSET_Rings      <- 150

  MAXSECTIONS <- 2500

  scaleFontSize <-  9
  titleFontSize <- 10
  basesFontSize <-  8





  # Auxillary functions

  
  # Function to pull coordinates and strand from ProdicalCalls and RNAmmerCalls
  # ---------------------------------------------------------------------------

  computeAnnotation <- function(organism, type = "protein", strand = "+") {

    seqSet <- GenomeSeqList[organism][[organism]]

    #
    # Looking only at the first sequence in a DNAStringSet ...
    # ... for now

    seqLen <- width(seqSet)
  
    # Add "source" to the annotation dataframe

    annotation.df <- data.frame("type" = "source", "begin" = 1, "end" = seqLen, "strand" = "+", stringsAsFactors=FALSE)

    if (type == "protein") {
      genes.df <- ProdigalCalls[which(ProdigalCalls$accession == organism),]

      # Check whether genes have been called
      if (nrow(genes.df) == 0) { # Genes have not been called
        cat(paste("Calling protein genes for accession ID:", organism, "\n"))
        runProdigal(organism, verbose = FALSE)
        genes.df <- ProdigalCalls[which(ProdigalCalls$accession == organism),]
      }

      # Add protein genes to the annotation dataframe

      geneCoords.df <- genes.df[,c(3:5)]
      geneCoords.df <- data.frame("type" = "gene", geneCoords.df, stringsAsFactors=FALSE)   # Note: "gene" could be "CDS" ... or two lines, one each

      annotation.df <- rbind(annotation.df, geneCoords.df)

      if (strand == "+") {
        CDS.df <- annotation.df[annotation.df$type == "gene",]
        CDS.df <- CDS.df[CDS.df$strand == "+",]
      }

      if (strand == "-") {
        CDS.df <- annotation.df[annotation.df$type == "gene",]
        CDS.df <- CDS.df[CDS.df$strand == "-",]
      }
    }


    # Add ribosomal genes
    # ... TBD

    if (type == "rRNA") {
      genes.df <- RNAmmerCalls[which(RNAmmerCalls$accession == organism),]

#     # Check whether rRNA genes have been called
#     if (nrow(genes.df) == 0) { # Genes have not been called
#       # cat(paste("Calling rRNA genes for accession ID:", organism, "\n"))
#       runRNAmmer(organism, scope = "ALL")
#       genes.df <- RNAmmerCalls[which(RNAmmerCalls$accession == organism),]
#     }

      runRNAmmer(organism, scope = "ALL")
      genes.df <- RNAmmerCalls[which(RNAmmerCalls$accession == organism),]




      CDS.df <- data.frame()  # Empty data frame in case NO rRNA genes are found on a strand

      if (nrow(genes.df) > 0) {
        # Add rRNA genes to the annotation dataframe

        geneCoords.df <- genes.df[,c(6:8)]
        geneCoords.df <- data.frame("type" = "rRNA", geneCoords.df, stringsAsFactors=FALSE)

        annotation.df <- rbind(annotation.df, geneCoords.df)

        if (strand == "+") {
          CDS.df <- annotation.df[annotation.df$type == "rRNA",]
          CDS.df <- CDS.df[CDS.df$strand == "+",]
        }

        if (strand == "-") {
          CDS.df <- annotation.df[annotation.df$type == "rRNA",]
          CDS.df <- CDS.df[CDS.df$strand == "-",]
        }
      }
    }
  
    return(CDS.df)

  }


  # Function to compute STACKING ENERGY from the genome sequence
  # ------------------------------------------------------------

  computeOrnstein <- function(organism) {

    # An optimized potential function for the calculation of nucleic acid interaction energies.
    #   I. Base stacking.
    #     R Ornstein, R Rein, D Breen & R MacElroy
    #     Biopolymers 17 (1978), 2341-2360.

    seqSet <- GenomeSeqList[organism][[organism]]

    #
    # Looking only at the first sequence in a DNAStringSet ...
    # ... for now

    sequence <- as.character(seqSet[[1]])
    values <- numeric(length = 1)

    vector <- matchPattern("AA", sequence)
    coords <- start(vector)
    values[coords] <- -5.37

    vector <- matchPattern("AC", sequence)
    coords <- start(vector)
    values[coords] <- -10.51

    vector <- matchPattern("AG", sequence)
    coords <- start(vector)
    values[coords] <- -6.78

    vector <- matchPattern("AT", sequence)
    coords <- start(vector)
    values[coords] <- -6.57

    vector <- matchPattern("CA", sequence)
    coords <- start(vector)
    values[coords] <- -6.57

    vector <- matchPattern("CC", sequence)
    coords <- start(vector)
    values[coords] <- -8.26

    vector <- matchPattern("CG", sequence)
    coords <- start(vector)
    values[coords] <- -9.61

    vector <- matchPattern("CT", sequence)
    coords <- start(vector)
    values[coords] <- -6.78

    vector <- matchPattern("GA", sequence)
    coords <- start(vector)
    values[coords] <- -9.81

    vector <- matchPattern("GC", sequence)
    coords <- start(vector)
    values[coords] <- -14.59

    vector <- matchPattern("GG", sequence)
    coords <- start(vector)
    values[coords] <- -8.26

    vector <- matchPattern("GT", sequence)
    coords <- start(vector)
    values[coords] <- -10.51
  
    vector <- matchPattern("TA", sequence)
    coords <- start(vector)
    values[coords] <- -3.82
  
    vector <- matchPattern("TC", sequence)
    coords <- start(vector)
    values[coords] <- -9.81
  
    vector <- matchPattern("TG", sequence)
    coords <- start(vector)
    values[coords] <- -6.57
  
    vector <- matchPattern("TT", sequence)
    coords <- start(vector)
    values[coords] <- -5.37


    
    return(values)
  }



  # Function to compute POSITION PREFERENCE, the Travers DNA Flexibility Measure
  #   from the genome sequence
  # ----------------------------------------------------------------------------

  computeTravers <- function(organism) {

    # A DNA structural atlas for Escherichia coli.
    #   Pedersen AG, Jensen LJ, Brunak S, Staerfeldt HH, Ussery DW
    #   J. Mol. Biol. 299(4):907-30. (2000)

    seqSet <- GenomeSeqList[organism][[organism]]

    #
    # Looking only at the first sequence in a DNAStringSet ...
    # ... for now

    sequence <- as.character(seqSet[[1]])
    values <- numeric(length = 1)
  
    vector <- matchPattern("AAA", sequence)
    coords <- start(vector)
    values[coords] <- 0.36

    vector <- matchPattern("AAC", sequence)
    coords <- start(vector)
    values[coords] <- 0.06

    vector <- matchPattern("AAG", sequence)
    coords <- start(vector)
    values[coords] <- 0.06

    vector <- matchPattern("AAT", sequence)
    coords <- start(vector)
    values[coords] <- 0.30

    vector <- matchPattern("ACA", sequence)
    coords <- start(vector)
    values[coords] <- 0.06

    vector <- matchPattern("ACC", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("ACG", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("ACT", sequence)
    coords <- start(vector)
    values[coords] <- 0.11

    vector <- matchPattern("AGA", sequence)
    coords <- start(vector)
    values[coords] <- 0.09

    vector <- matchPattern("AGC", sequence)
    coords <- start(vector)
    values[coords] <- 0.25

    vector <- matchPattern("AGG", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("AGT", sequence)
    coords <- start(vector)
    values[coords] <- 0.11

    vector <- matchPattern("ATA", sequence)
    coords <- start(vector)
    values[coords] <- 0.13

    vector <- matchPattern("ATC", sequence)
    coords <- start(vector)
    values[coords] <- 0.07

    vector <- matchPattern("ATG", sequence)
    coords <- start(vector)
    values[coords] <- 0.18

    vector <- matchPattern("ATT", sequence)
    coords <- start(vector)
    values[coords] <- 0.30

    vector <- matchPattern("CAA", sequence)
    coords <- start(vector)
    values[coords] <- 0.09

    vector <- matchPattern("CAC", sequence)
    coords <- start(vector)
    values[coords] <- 0.17

    vector <- matchPattern("CAG", sequence)
    coords <- start(vector)
    values[coords] <- 0.02

    vector <- matchPattern("CAT", sequence)
    coords <- start(vector)
    values[coords] <- 0.18

    vector <- matchPattern("CCA", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("CCC", sequence)
    coords <- start(vector)
    values[coords] <- 0.13

    vector <- matchPattern("CCG", sequence)
    coords <- start(vector)
    values[coords] <- 0.02

    vector <- matchPattern("CCT", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("CGA", sequence)
    coords <- start(vector)
    values[coords] <- 0.31

    vector <- matchPattern("CGC", sequence)
    coords <- start(vector)
    values[coords] <- 0.25

    vector <- matchPattern("CGG", sequence)
    coords <- start(vector)
    values[coords] <- 0.02

    vector <- matchPattern("CGT", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("CTA", sequence)
    coords <- start(vector)
    values[coords] <- 0.18

    vector <- matchPattern("CTC", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("CTG", sequence)
    coords <- start(vector)
    values[coords] <- 0.02

    vector <- matchPattern("CTT", sequence)
    coords <- start(vector)
    values[coords] <- 0.06

    vector <- matchPattern("GAA", sequence)
    coords <- start(vector)
    values[coords] <- 0.12

    vector <- matchPattern("GAC", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("GAG", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("GAT", sequence)
    coords <- start(vector)
    values[coords] <- 0.07

    vector <- matchPattern("GCA", sequence)
    coords <- start(vector)
    values[coords] <- 0.13

    vector <- matchPattern("GCC", sequence)
    coords <- start(vector)
    values[coords] <- 0.45

    vector <- matchPattern("GCG", sequence)
    coords <- start(vector)
    values[coords] <- 0.25

    vector <- matchPattern("GCT", sequence)
    coords <- start(vector)
    values[coords] <- 0.25

    vector <- matchPattern("GGA", sequence)
    coords <- start(vector)
    values[coords] <- 0.05

    vector <- matchPattern("GGC", sequence)
    coords <- start(vector)
    values[coords] <- 0.45

    vector <- matchPattern("GGG", sequence)
    coords <- start(vector)
    values[coords] <- 0.13

    vector <- matchPattern("GGT", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("GTA", sequence)
    coords <- start(vector)
    values[coords] <- 0.06

    vector <- matchPattern("GTC", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("GTG", sequence)
    coords <- start(vector)
    values[coords] <- 0.17

    vector <- matchPattern("GTT", sequence)
    coords <- start(vector)
    values[coords] <- 0.06

    vector <- matchPattern("TAA", sequence)
    coords <- start(vector)
    values[coords] <- 0.20

    vector <- matchPattern("TAC", sequence)
    coords <- start(vector)
    values[coords] <- 0.06

    vector <- matchPattern("TAG", sequence)
    coords <- start(vector)
    values[coords] <- 0.18

    vector <- matchPattern("TAT", sequence)
    coords <- start(vector)
    values[coords] <- 0.13

    vector <- matchPattern("TCA", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("TCC", sequence)
    coords <- start(vector)
    values[coords] <- 0.05

    vector <- matchPattern("TCG", sequence)
    coords <- start(vector)
    values[coords] <- 0.31

    vector <- matchPattern("TCT", sequence)
    coords <- start(vector)
    values[coords] <- 0.09

    vector <- matchPattern("TGA", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("TGC", sequence)
    coords <- start(vector)
    values[coords] <- 0.13

    vector <- matchPattern("TGG", sequence)
    coords <- start(vector)
    values[coords] <- 0.08

    vector <- matchPattern("TGT", sequence)
    coords <- start(vector)
    values[coords] <- 0.06

    vector <- matchPattern("TTA", sequence)
    coords <- start(vector)
    values[coords] <- 0.20

    vector <- matchPattern("TTC", sequence)
    coords <- start(vector)
    values[coords] <- 0.12

    vector <- matchPattern("TTG", sequence)
    coords <- start(vector)
    values[coords] <- 0.09

    vector <- matchPattern("TTT", sequence)
    coords <- start(vector)
    values[coords] <- 0.36

    return(values)

  }




  # Function to compute GC-SKEW from the genome sequence
  # ------------------------------------------------------------

  computeGCskew <- function(organism, numSections, secLength) {

    seqSet <- GenomeSeqList[organism][[organism]]

    #
    # Looking only at the first sequence in a DNAStringSet ...
    # ... for now

    sequence <- as.character(seqSet[[1]])
    DNAseq   <- DNAString(sequence)
    sequenceLength <- length(DNAseq)

    beg <- 1
    end <- secLength

    sectionVector <- numeric(length = 1)

    for (i in 1:numSections) {
      C <- countPattern("C", DNAseq[beg:end])
      G <- countPattern("G", DNAseq[beg:end])
      if ((C+G) == 0) { skew <- 0 }
      else            { skew <- (C-G)/(C+G) }
      sectionVector[i] <- skew
      beg <- beg + secLength
      end <- end + secLength
      if (end > sequenceLength) { end <- sequenceLength }
    }

    return(sectionVector)
  }




  # Function to compute PERCENT AT from the genome sequence
  # ------------------------------------------------------------

  computePercentAT <- function(organism, numSections, secLength) {

    seqSet <- GenomeSeqList[organism][[organism]]

    #
    # Looking only at the first sequence in a DNAStringSet ...
    # ... for now

    sequence <- as.character(seqSet[[1]])
    DNAseq   <- DNAString(sequence)
    sequenceLength <- length(DNAseq)

    beg <- 1
    end <- secLength

    sectionVector <- numeric(length = 1)

    for (i in 1:numSections) {
      A <- countPattern("A", DNAseq[beg:end])
      T <- countPattern("T", DNAseq[beg:end])

      sectionVector[i] <- (A+T)/(end-beg+1)
      beg <- beg + secLength
      end <- end + secLength
      if (end > sequenceLength) { end <- sequenceLength }
    }

    return(sectionVector)
  }



  drawRing <- function(sectionVector, prob_table) {

    pTable <- prob_table


    if (APPROACH == "PROB") {
      cumProb <- cumsum(pTable/2500)

      sectionMax <- max(sectionVector, na.rm=TRUE)
      sectionMin <- min(sectionVector, na.rm=TRUE)

      sectionRange <- sectionMax - sectionMin

      colorVector <- integer(length = 1)

      colorBreaks <- sectionMin + cumProb * sectionRange

      for (i in 1:numSections) {
        section <- sectionVector[i]

        # This statement is a remnant from earlier code that in effect assigns colors
        #   using a flat probability distribution, that is, an assigned color reflects
        #   the relative position of a section average within the minimum average to maximum average range.
        #
        # colorLevel <- floor((numRows-2) * (section - sectionMin) / (sectionMax - sectionMin))
        #

        colorLevel <- 1
        while (section > colorBreaks[colorLevel]) {
          colorLevel <- colorLevel + 1
        }
        colorVector[i] <- colorLevel - 1
      }
    }



    if (APPROACH == "COMP") {
      maxColor <- 37

      sectionMax <- max(sectionVector, na.rm=TRUE)
      sectionMin <- min(sectionVector, na.rm=TRUE)

      colorVector <- integer(length = 1)

      for (i in 1:numSections) {
        section <- sectionVector[i]

        d <- (section - sectionMin) / (sectionMax - sectionMin)
        p <- floor(maxColor * d)
        if (p >= maxColor) { p <- maxColor - 1}
        if (p < 0)         { p <- 0}

        if (sectionMin == sectionMax) { p <- round(maxColor/2) }

        colorVector[i] <- p
      }
    }



    if (APPROACH == "HIST") {
      # This section assigns colors according to the probability distribution
      #   based solely on the rank and not the value of a section average.

      section.df <- data.frame(sectionVector)

      colnames(section.df) <- "value"

      section.df$position <- seq.int(nrow(section.df))        # Add row number, i.e., the position of the section

      section.df <- section.df[order(section.df$value),]   # Order the sections by value of section averages

      color <- vector()

      # Check to see if there are fewer than MAXSECTIONS sections
     
      if (numSections < MAXSECTIONS) {
        reduce <- MAXSECTIONS - numSections   # reduce the number of color assignments
        # cat(paste0("Reducing color vector by ", reduce, " entries\n"))
        pTable[19] <- pTable[19] - reduce               # the middle color
      }

      for (i in 1:length(pTable)) {
        if (pTable[i] == 0) {}
        else {
          for (j in 1:pTable[i]) {
            color <- c(color, i-1)  # R arrays are 1-based, SVG arrays are 0-based
          }
        }
      }

      # Some debugging statements
      # cat(paste("Length of section vector:", nrow(section.df), "\n"))
      # cat(paste("Length of color vector:", length(color), "\n"))

      section.df <- cbind(section.df, color, row.names = NULL)   # Add the color vector
      section.df <- section.df[order(section.df$position),]   # Reorder the sections by position
      colorVector <- section.df$color
    }

    return(section.df)

  }



  ################################
  ### MAIN BODY of createAtlas.R #
  ################################


  # Probability distributions for HIST assignment of colors
  #--------------------------------------------------------

  # Flat-ish
  #--------------
  probabilities_1 <- c(
      0,   0,  75,  75,  75,  75,  75,  75,  75,  75,  75,  75,
     75,  75,  75,  75,  75,  75, 100,  75,  75,  75,  75,  75, 75,
     75,  75,  75,  75,  75,  75,  75,  75,  75,  75,   0,   0
  )

  # Normal-ish
  #--------------
  probabilities_2 <- c(
      0,  30,  30,  30,  30,  30,  30,  30,  30,  30,  30,  40,
     50,  70, 110, 150, 185, 220, 250, 220, 185, 150, 110,  70,  50,
     40,  30,  30,  30,  30,  30,  30,  30,  30,  30,  30,   0
  )

  # Normal-ish with a larger peak
  #--------------
  probabilities_3 <- c(
      0,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,  40,
     50,  70, 110, 150, 210, 310, 420, 310, 210, 150, 110,  70,  50,
     40,  10,  10,  10,  10,  10,  10,  10,  10,  10,  10,   0
  )

  # Normal-ish with a larger peak and a flair at each end
  #--------------
  probabilities_4 <- c(
     30,  30,  30,  30,  20,  10,  10,  10,  10,  10,  10,  40,
     50,  50,  90, 130, 190, 290, 420, 290, 190, 130,  90,  50,  50,
     40,  10,  10,  10,  10,  10,  10,  20,  30,  30,  30,  30
  )

  # Normal-ish with a larger peak and a flair at each end
  #   ... and 0's on the first and last (black) colors
  #--------------
  probabilities_5 <- c(
      0,  50,  40,  30,  20,  10,  10,  10,  10,  10,  10,  40,
     50,  50,  90, 130, 190, 290, 420, 290, 190, 130,  90,  50,  50,
     40,  10,  10,  10,  10,  10,  10,  20,  30,  40,  50,   0
  )

  probabilities <- probabilities_4


  # Check whether GenBank information for this genome has been downloaded

  notDownloaded <- is.null(GenomeSeqList[[organismAccession]])

  if (notDownloaded) {
    # cat(paste("Genome data for accession ID:", organismAccession, "has not been downloaded\n"))
    downloadGenome(organismAccession)
  }

  name <- orgName.df$fullName[orgName.df$accession == organismAccession]

  
  genomeSize <- orgData.df$seq_length[orgData.df$accession == organismAccession]


  cat(paste("Writing SVG code for genome with accession ID:", organismAccession, "\n"))

  # SVG code
  # --------

#  plotSize <- 1000
#  plotSize <- 1200
   plotSize <- 1500
  plotX    <- plotSize * 1.5
  plotY    <- plotSize

  svg_file <- paste0("GenomeAtlas_", organismAccession, ".svg")

  write('<svg version="1.1"',                                    svg_file               )
  write('   baseProfile="full"',                                 svg_file, append = TRUE)
  # write('   width="1000" height="1000"',                       svg_file, append = TRUE)
  write(paste0('   width="', plotX, '" height="', plotY, '"'),   svg_file, append = TRUE)
  write('   xmlns="http://www.w3.org/2000/svg"',                 svg_file, append = TRUE)
  write('   xmlns:xlink="http://www.w3.org/1999/xlink">',        svg_file, append = TRUE)


  # A temporary statement to show the size of the plot
  #   ---------
  # write(paste0('<rect width="', plotX, '" height="', plotY, '" stroke="black" stroke-width="10" style="fill:rgb(255,255,255)"/>'), svg_file, append = TRUE)


  # Statements to scale and translate the entire circle plot to accomodate the addition of the "Percent AT" ring
  write(paste0('<g transform="translate(150,150) scale(0.8)">'), svg_file, append = TRUE)
  # ... NOTE: This transform ends BEFORE the Legend is drawn (search for "LEGEND" to find end of transform)


  circX  <- plotSize / 2
  circY  <- plotSize / 2
  radius <- plotSize / 5

  # Organism name
  # -------------

  # NEW - BEGIN


  # Reset name to test long organism names
  # name <-  "A really, really long name that must be split across multiple lines in order to keep it from extending into the atlas rings and looking ridiculous"
  
  # Lots of code to handle the case of an organism name that is too long
  #   to fit in the center of the genome atlas
  # Example: ’Catharanthus roseus’ aster yellows phytoplasma str. De Villa

  nameLimit <- 38 # Maximum number of characters allowed on a line
                  # Not the best solution, since fixed-width fonts are NOT used.
                  # However, it's not easy to determine the length of the title
                  # as rendered by SVG. :-(

  nameVector <- list()

  if (nchar(name) > nameLimit) {  # Too long for plot ... split into multiple lines
    wordList <- strsplit(name, " ")
    i <- 1
    while (length(wordList[[1]]) > 0) {
      nameVector[i] <- ""
      while (((nchar(nameVector[i]) + nchar(wordList[[1]][1]) + 1) < nameLimit)
               &&(length(wordList[[1]]) > 0))
      {
        nameVector[i] <- paste0(nameVector[i], " ", wordList[[1]][1])
        wordList[[1]] <- wordList[[1]][-1]
      }
      i <- i + 1
    }
  }
  else {
    nameVector <- name
  }

  # Note: A single blank may be inserted at the beginning of each element in the nameVector
  #   Check and remove

  numLines <- length(nameVector)
  for (i in 1:numLines) {
    if (substr(nameVector[[i]][1],1,1) == " ") {
      nameVector[[i]][1] <- substring(nameVector[[i]][1],2)
    }
  }

  lineIncr <- plotSize/50
  lineLoc  <- circY - plotSize/100 - (numLines - 1) * (lineIncr / 2)
  lineLoc  <- circY - (numLines - 1) * (lineIncr / 2)

  for (i in 1:numLines) {
    write(paste0('  <text x="', circX, '" y="', lineLoc, '" font-style="italic" text-anchor="middle" font-size="', plotSize/10 * 1.2, '%">', nameVector[[i]][1], '</text>'), svg_file, append = TRUE)
    lineLoc <- lineLoc + lineIncr
  }

  sizeLabel <- paste(genomeSize, "bp")
  write(paste0('  <text x="', circX, '" y="', lineLoc, '" font-style="italic" text-anchor="middle" font-size="', plotSize/10 * 1.0, '%">', sizeLabel, '</text>'), svg_file, append = TRUE)




  ###################
  # ADD CIRCLES ... #
  ###################



  # Circle for genome scale - INNERMOST
  # -----------------------------------
  # write('   <circle cx="500" cy="500" r="300" stroke="black" stroke-width="2" fill-opacity="0"/>', svg_file, append = TRUE)
  write(paste0('   <circle cx="', circX, '" cy="', circY, '" r="', radius, '" stroke="black" stroke-width="2" fill-opacity="0"/>'), svg_file, append = TRUE)

  
  write('   <defs>',                                                                                        svg_file, append = TRUE)
  # write('     <line id="major_tick" x1="0" y1="-310" x2="0" y2="-290" stroke="black" stroke-width="0.5"/>', svg_file, append = TRUE)
  write(paste0('     <line id="major_tick" x1="0" y1="', -radius-plotSize/150, '" x2="0" y2="', -radius+plotSize/150, '" stroke="black" stroke-width="0.5"/>'), svg_file, append = TRUE)
  # write('     <line id="minor_tick" x1="0" y1="-305" x2="0" y2="-295" stroke="black" stroke-width="0.5"/>', svg_file, append = TRUE)
  write(paste0('     <line id="minor_tick" x1="0" y1="', -radius-plotSize/300, '" x2="0" y2="', -radius+plotSize/300, '" stroke="black" stroke-width="0.5"/>'), svg_file, append = TRUE)
  write('   </defs>',                                                                                       svg_file, append = TRUE)
  


  # Determine the distance (in nucleotide bases) between major tick marks
  #   The following is a bit of kludge, determined by trial and error.
  #   It is not expected that the length of genomic sequences,
  #   at least for bacterial genomes, will result in logSize values
  #   outside of the range [18,24].

  logSize <- round(log2(genomeSize))

  if      (logSize <    18) { majorTick <-    5000 }
  else if (logSize ==   18) { majorTick <-   10000 }
  else if (logSize ==   19) { majorTick <-   25000 }
  else if (logSize ==   20) { majorTick <-   50000 }
  else if (logSize ==   21) { majorTick <-  100000 }
  else if (logSize ==   22) { majorTick <-  250000 }
  else if (logSize ==   23) { majorTick <-  500000 }
  else if (logSize ==   24) { majorTick <- 1000000 }
  else                      { majorTick <- 2000000 }

  labelIncr <- as.integer(majorTick / 1000)
  angleIncr <- 360 / (genomeSize / majorTick)

  # Debugging output ...
  # cat(paste0("Genome size: ", genomeSize, "\n"))
  # cat(paste0("Major Tick: ", majorTick, "\n"))
  # cat(paste0("Label Increment: ", labelIncr, "\n"))
  # cat(paste0("Angle Increment: ", angleIncr, "\n"))
  
  # Major tick marks
  # ----------------

  angle <- 0
  while(angle < 360) {
    write(paste0('   <use xlink:href="#major_tick" transform="translate(', circX, ' ', circY, '), rotate(', angle, ')"/>'),    svg_file, append = TRUE)
    angle <- angle + angleIncr
  }

  # Major tick mark labels
  # ----------------------

  angle <- 0
  label <- 0
  while(angle < 350) { # "350" to keep label from overlapping with label at the origin
    write(paste0('   <text x="0" y="', -radius+plotSize/50, '" text-anchor="middle"
                      font-size="', plotSize/11, '%" transform="translate(', circX, ' ', circY, '), rotate(', angle, ')">', label, 'k</text>'), svg_file, append = TRUE)
    angle <- angle + angleIncr
    label <- label + labelIncr
  }

  # Minor tick marks
  # ----------------

  minorTick <- majorTick / 5
  angleIncr <- 360 / (genomeSize / minorTick)

  angle <- 0
  while(angle < 360) {
    write(paste0('   <use xlink:href="#minor_tick" transform="translate(', circX, ' ', circY, '), rotate(', angle, ')"/>'),    svg_file, append = TRUE)
    angle <- angle + angleIncr
  }





  ####################
  # ADDITIONAL RINGS #
  ####################

  # Compute segment size ...

  secLength <- ceiling(genomeSize / MAXSECTIONS)
  numSections <- ceiling(genomeSize / secLength)

  sectionArc <- (2 * pi) / numSections



  ##############
  # PERCENT AT #
  ##############

  radius <- radius + plotSize/16   # Lots of adjusting was required to get this ring in a good position

  sectionVector <- computePercentAT(organismAccession, numSections, secLength)

  # Smooth the sectionVector using Tukey's (Running Median) Smoothing
  if (SMOOTH) {
    sectionVector <- as.numeric(smooth(sectionVector))
  }

  maxPercentAT <- max(sectionVector)
  minPercentAT <- min(sectionVector)

  # ... and choose display colors

  numRows <- 37

  rownames <- 1:numRows
  colnames <- c("R", "G", "B")

  percentAT_colorMap.df <- data.frame(
    matrix(
      c(
           0,  77,  77,
           0,   0, 230,
          26,  26, 230,
          51,  51, 230,
          77,  77, 230,
         102, 102, 230,
         128, 128, 230,
         140, 140, 230,
         153, 153, 230,
         166, 166, 230,
         179, 179, 230,
         191, 191, 230,
         204, 204, 230,
         217, 217, 230,
         219, 219, 230,
         222, 222, 230,
         224, 224, 230,
         227, 227, 230,
         230, 230, 230,
         230, 227, 227,
         230, 224, 224,
         230, 222, 222,
         230, 219, 219,
         230, 217, 217,
         230, 204, 204,
         230, 191, 191,
         230, 179, 179,
         230, 166, 166,
         230, 153, 153,
         230, 140, 140,
         230, 128, 128,
         230, 102, 102,
         230,  77,  77,
         230,  51,  51,
         230,  26,  26,
         230,   0,   0,
          77,   0,  77
      ),
      nrow = 37,
      ncol = 3,
      byrow = TRUE,
      dimnames = list(rownames,colnames)
    )
  )

  section.df <- drawRing(sectionVector, probabilities)

  rows <- nrow(section.df)

  angleIncr <- (2 * pi) / rows
   
  arcB <- 0
  arcE <- angleIncr
    
  for (i in 1:rows) {

    xBegOffset <- sin(arcB) * radius
    yBegOffset <- cos(arcB) * radius
    xEndOffset <- sin(arcE) * radius
    yEndOffset <- cos(arcE) * radius

    write(paste0('<path d="M ', circX + xBegOffset, ' ', circY - yBegOffset),                                                    svg_file, append = TRUE)
    write(paste0('         A ', radius, ' ', radius, ' 1 0 1 ', circX + xEndOffset, ' ', circY - yEndOffset, '"'),               svg_file, append = TRUE)

    color <- section.df[i,]$color + 1      # move back to R 1-based indexing
    red   <- percentAT_colorMap.df[color,]$R
    green <- percentAT_colorMap.df[color,]$G
    blue  <- percentAT_colorMap.df[color,]$B
      
    write(paste0('         stroke="rgb(', red, ',', green, ',', blue, ')" stroke-width="', plotSize/20, '" fill-opacity="0"/>'), svg_file, append = TRUE)

    arcB <- arcB + angleIncr
    arcE <- arcE + angleIncr
  }




  ###########
  # GC SKEW #
  ###########

  radius <- radius + plotSize/17

  sectionVector <- computeGCskew(organismAccession, numSections, secLength)

  # Smooth the sectionVector using Tukey's (Running Median) Smoothing
  if (SMOOTH) {
    sectionVector <- as.numeric(smooth(sectionVector))
  }

  maxGCskew <- max(sectionVector)
  minGCskew <- min(sectionVector)

  # ... and choose display colors

  numRows <- 37

  rownames <- 1:numRows
  colnames <- c("R", "G", "B")

  # BEGIN Reverse color map -- CORRECT
  gcSkew_colorMap.df <- data.frame(
    matrix(
      c(
           0,  77,  77,
           0, 230, 230,
          26, 230, 230,
          51, 230, 230,
          77, 230, 230,
         102, 230, 230,
         128, 230, 230,
         140, 230, 230,
         153, 230, 230,
         166, 230, 230,
         179, 230, 230,
         191, 230, 230,
         204, 230, 230,
         217, 230, 230,
         219, 230, 230,
         222, 230, 230,
         224, 230, 230,
         227, 230, 230,
         230, 230, 230,
         230, 227, 230,
         230, 224, 230,
         230, 222, 230,
         230, 219, 230,
         230, 217, 230,
         230, 204, 230,
         230, 191, 230,
         230, 179, 230,
         230, 166, 230,
         230, 153, 230,
         230, 140, 230,
         230, 128, 230,
         230, 102, 230,
         230,  77, 230,
         230,  51, 230,
         230,  26, 230,
         230,   0, 230,
          77,   0,  77
      ),
      nrow = 37,
      ncol = 3,
      byrow = TRUE,
      dimnames = list(rownames,colnames)
    )
  )
  # END Reverse color map


  # BEGIN Forward color map -- WRONG
  # gcSkew_colorMap.df <- data.frame(
  #   matrix(
  #     c(
  #         77,   0,  77,
  #        230,   0, 230,
  #        230,  26, 230,
  #        230,  51, 230,
  #        230,  77, 230,
  #        230, 102, 230,
  #        230, 128, 230,
  #        230, 140, 230,
  #        230, 153, 230,
  #        230, 166, 230,
  #        230, 179, 230,
  #        230, 191, 230,
  #        230, 204, 230,
  #        230, 217, 230,
  #        230, 219, 230,
  #        230, 222, 230,
  #        230, 224, 230,
  #        230, 227, 230,
  #        230, 230, 230,
  #        227, 230, 230,
  #        224, 230, 230,
  #        222, 230, 230,
  #        219, 230, 230,
  #        217, 230, 230,
  #        204, 230, 230,
  #        191, 230, 230,
  #        179, 230, 230,
  #        166, 230, 230,
  #        153, 230, 230,
  #        140, 230, 230,
  #        128, 230, 230,
  #        102, 230, 230,
  #         77, 230, 230,
  #         51, 230, 230,
  #         26, 230, 230,
  #          0, 230, 230,
  #          0,  77,  77
  #     ),
  #     nrow = 37,
  #     ncol = 3,
  #     byrow = TRUE,
  #     dimnames = list(rownames,colnames)
  #   )
  # )
  # END Forward color map

  section.df <- drawRing(sectionVector, probabilities)

  rows <- nrow(section.df)

  angleIncr <- (2 * pi) / rows
   
  arcB <- 0
  arcE <- angleIncr
    
  for (i in 1:rows) {

    xBegOffset <- sin(arcB) * radius
    yBegOffset <- cos(arcB) * radius
    xEndOffset <- sin(arcE) * radius
    yEndOffset <- cos(arcE) * radius

    write(paste0('<path d="M ', circX + xBegOffset, ' ', circY - yBegOffset),                                                    svg_file, append = TRUE)
    write(paste0('         A ', radius, ' ', radius, ' 1 0 1 ', circX + xEndOffset, ' ', circY - yEndOffset, '"'),               svg_file, append = TRUE)

    color <- section.df[i,]$color + 1      # move back to R 1-based indexing
    red   <- gcSkew_colorMap.df[color,]$R
    green <- gcSkew_colorMap.df[color,]$G
    blue  <- gcSkew_colorMap.df[color,]$B
      
    write(paste0('         stroke="rgb(', red, ',', green, ',', blue, ')" stroke-width="', plotSize/20, '" fill-opacity="0"/>'), svg_file, append = TRUE)

    arcB <- arcB + angleIncr
    arcE <- arcE + angleIncr
  }






  # CDS reverse strand
  # ------------------

  
  # centerX <- 500
  # centerY <- 500
  # radius  <- 340
  radius  <- radius + plotSize/20

  pi <- 3.1415926536

  CDSreverse.df <- computeAnnotation(organismAccession, strand = "-")
 
  rows <- nrow(CDSreverse.df)

  if (rows > 0) {
    for (i in 1:rows) {
      beg <- CDSreverse.df[i,]$begin
      end <- CDSreverse.df[i,]$end

      arcB <- 2 * pi * beg / genomeSize
      arcE <- 2 * pi * end / genomeSize

      xBegOffset <- sin(arcB) * radius
      yBegOffset <- cos(arcB) * radius
      xEndOffset <- sin(arcE) * radius
      yEndOffset <- cos(arcE) * radius

      # Example arc
      #   <path d="M 500 100 
      #            A 400 400 1 0 1 900 500"
      #            stroke="rgb(0,0,255)" stroke-width="20" fill-opacity="0"/>


      write(paste0('<path d="M ', circX + xBegOffset, ' ', circY - yBegOffset),                                       svg_file, append = TRUE)
      write(paste0('         A ', radius, ' ', radius, ' 1 0 1 ', circX + xEndOffset, ' ', circY - yEndOffset, '"'),  svg_file, append = TRUE)
      write(paste0('         stroke="rgb(255,0,0)" stroke-width="', plotSize/80, '" fill-opacity="0"/>'),             svg_file, append = TRUE)

    }
  }



  # rRNA reverse strand
  # -------------------

  rRNAreverse.df <- computeAnnotation(organismAccession, type = "rRNA", strand = "-")


  rows <- nrow(rRNAreverse.df)

  if (rows > 0) {
    for (i in 1:rows) {
      beg <- rRNAreverse.df[i,]$begin
      end <- rRNAreverse.df[i,]$end

      arcB <- 2 * pi * beg / genomeSize
      arcE <- 2 * pi * end / genomeSize

      xBegOffset <- sin(arcB) * radius
      yBegOffset <- cos(arcB) * radius
      xEndOffset <- sin(arcE) * radius
      yEndOffset <- cos(arcE) * radius

      write(paste0('<path d="M ', circX + xBegOffset, ' ', circY - yBegOffset),                                       svg_file, append = TRUE)
      write(paste0('         A ', radius, ' ', radius, ' 1 0 1 ', circX + xEndOffset, ' ', circY - yEndOffset, '"'),  svg_file, append = TRUE)
      write(paste0('         stroke="rgb(0,255,255)" stroke-width="', plotSize/80, '" fill-opacity="0"/>'),           svg_file, append = TRUE)
    }
  }



  # circle boundary between reverse and forward strands
  # ---------------------------------------------------
  radius <- radius + plotSize/100

  write(paste0('   <circle cx="', circX, '" cy="', circY, '" r="', radius, '" stroke="black" stroke-width="', plotSize/1000, '" fill-opacity="0"/>'), svg_file, append = TRUE)



  # CDS forward strand
  # ------------------

  radius  <- radius + plotSize/100

  CDSforward.df <- computeAnnotation(organismAccession, strand = "+")
 
  rows <- nrow(CDSforward.df)

  if (rows > 0) {
    for (i in 1:rows) {
      beg <- CDSforward.df[i,]$begin
      end <- CDSforward.df[i,]$end

      arcB <- 2 * pi * beg / genomeSize
      arcE <- 2 * pi * end / genomeSize

      xBegOffset <- sin(arcB) * radius
      yBegOffset <- cos(arcB) * radius
      xEndOffset <- sin(arcE) * radius
      yEndOffset <- cos(arcE) * radius

      write(paste0('<path d="M ', circX + xBegOffset, ' ', circY - yBegOffset),                                       svg_file, append = TRUE)
      write(paste0('         A ', radius, ' ', radius, ' 1 0 1 ', circX + xEndOffset, ' ', circY - yEndOffset, '"'),  svg_file, append = TRUE)
      write(paste0('         stroke="rgb(0,0,255)" stroke-width="', plotSize/80, '" fill-opacity="0"/>'),             svg_file, append = TRUE)

    }
  }



  # rRNA forward strand
  # -------------------

  rRNAforward.df <- computeAnnotation(organismAccession, type = "rRNA", strand = "+")

  rows <- nrow(rRNAforward.df)

  if (rows > 0) {
    for (i in 1:rows) {
      beg <- rRNAforward.df[i,]$begin
      end <- rRNAforward.df[i,]$end

      arcB <- 2 * pi * beg / genomeSize
      arcE <- 2 * pi * end / genomeSize

      xBegOffset <- sin(arcB) * radius
      yBegOffset <- cos(arcB) * radius
      xEndOffset <- sin(arcE) * radius
      yEndOffset <- cos(arcE) * radius

      write(paste0('<path d="M ', circX + xBegOffset, ' ', circY - yBegOffset),                                       svg_file, append = TRUE)
      write(paste0('         A ', radius, ' ', radius, ' 1 0 1 ', circX + xEndOffset, ' ', circY - yEndOffset, '"'),  svg_file, append = TRUE)
      write(paste0('         stroke="rgb(0,255,255)" stroke-width="', plotSize/80, '" fill-opacity="0"/>'),           svg_file, append = TRUE)
    }
  }








  ###############################
  # TRAVERS POSITION PREFERENCE #
  ###############################

  radius <- radius + plotSize/20

  featureVector <- computeTravers(organismAccession);
  featureLength <- length(featureVector)

  featureVector[is.na(featureVector)] <- 0

  # Compute vector of values for a section

  sectionVector <- vector()


  beg <- 1
  end <- secLength

  for (i in 1:numSections) {
    if        (MODE == "MAXV") { sectionVector[i] <- max (featureVector[beg:end], na.rm=TRUE) }
    else { if (MODE == "MINV") { sectionVector[i] <- min (featureVector[beg:end], na.rm=TRUE) }
    else {                       sectionVector[i] <- mean(featureVector[beg:end], na.rm=TRUE) }
    }

    beg <- beg + secLength
    end <- end + secLength
    if (end > featureLength) { end <- featureLength }
  }


  # Smooth the sectionVector using Tukey's (Running Median) Smoothing
  if (SMOOTH) {
    sectionVector <- as.numeric(smooth(sectionVector))
  }

  traversMin <- min(sectionVector)
  traversMax <- max(sectionVector)


  # ... and choose display colors

  # Original color map for position preference

  if (FALSE) {  # saved for reference

  numRows <- 37

  rownames <- 1:numRows
  colnames <- c("R", "G", "B")

  travers_colorMap.df <- data.frame(
    matrix(
      c(
           0,  77,   0,
           0, 230,   0,
          26, 230,  26,
          51, 230,  51,
          77, 230,  77,
         102, 230, 102,
         128, 230, 128,
         140, 230, 140,
         153, 230, 153,
         166, 230, 166,
         179, 230, 179,
         191, 230, 191,
         204, 230, 204,
         217, 230, 217,
         219, 230, 219,
         222, 230, 222,
         224, 230, 224,
         227, 230, 227,
         230, 230, 230,
         230, 227, 230,
         230, 224, 230,
         230, 222, 230,
         230, 219, 230,
         230, 217, 230,
         230, 204, 230,
         230, 191, 230,
         230, 179, 230,
         230, 166, 230,
         230, 153, 230,
         230, 140, 230,
         230, 128, 230,
         230, 102, 230,
         230,  77, 230,
         230,  51, 230,
         230,  26, 230,
         230,   0, 230,
          77,   0,  77
      ),
      nrow = 37,
      ncol = 3,
      byrow = TRUE,
      dimnames = list(rownames,colnames)
    )
  )

  }




  # Revised color map for position preference
  # Per Dave Ussery:
  #  "Change the color in the ‘position preference lane’,
  #   such that it only shows the green (low position preference),
  #   but what is now purple at the other end of the scale, is just grey"
  #
  # Color map gradient below: green -> gray -> white

  travers_colorMap.df <- data.frame(
    matrix(
      c(
           0,  77,   0,
           0, 230,   0,
          26, 230,  26,
          51, 230,  51,
          77, 230,  77,
         102, 230, 102,
         128, 230, 128,
         140, 230, 140,
         153, 230, 153,
         166, 230, 166,
         179, 230, 179,
         191, 230, 191,
         204, 230, 204,
         217, 230, 217,
         219, 230, 219,
         222, 230, 222,
         224, 230, 224,
         227, 230, 227,
         230, 230, 230,
         232, 232, 232,
         234, 234, 234,
         236, 236, 236,
         238, 238, 238,
         240, 240, 240,
         242, 242, 242,
         244, 244, 244,
         246, 246, 246,
         247, 247, 247,
         248, 248, 248,
         249, 249, 249,
         250, 250, 250,
         251, 251, 251,
         252, 252, 252,
         253, 253, 253,
         254, 254, 254,
         255, 255, 255,
         256, 256, 256
      ),
      nrow = 37,
      ncol = 3,
      byrow = TRUE,
      dimnames = list(rownames,colnames)
    )
  )

  section.df <- drawRing(sectionVector, probabilities)


  rows <- nrow(section.df)

  angleIncr <- (2 * pi) / rows
   
  arcB <- 0
  arcE <- angleIncr
    
  for (i in 1:rows) {

    xBegOffset <- sin(arcB) * radius
    yBegOffset <- cos(arcB) * radius
    xEndOffset <- sin(arcE) * radius
    yEndOffset <- cos(arcE) * radius

    write(paste0('<path d="M ', circX + xBegOffset, ' ', circY - yBegOffset),                                                    svg_file, append = TRUE)
    write(paste0('         A ', radius, ' ', radius, ' 1 0 1 ', circX + xEndOffset, ' ', circY - yEndOffset, '"'),               svg_file, append = TRUE)

    color <- section.df[i,]$color + 1      # move back to R 1-based indexing
    red   <- travers_colorMap.df[color,]$R
    green <- travers_colorMap.df[color,]$G
    blue  <- travers_colorMap.df[color,]$B
      
    write(paste0('         stroke="rgb(', red, ',', green, ',', blue, ')" stroke-width="', plotSize/20, '" fill-opacity="0"/>'), svg_file, append = TRUE)

    arcB <- arcB + angleIncr
    arcE <- arcE + angleIncr
  }




  ############################
  # ORNSTEIN STACKING ENERGY #
  ############################

  radius <- radius + plotSize/17

  featureVector <- computeOrnstein(organismAccession);
  featureLength <- length(featureVector)

  featureVector[is.na(featureVector)] <- 0

  # Compute vector of AVERAGE values for a section

  sectionVector <- vector()

  beg <- 1
  end <- secLength

  for (i in 1:numSections) {
    if        (MODE == "MAXV") { sectionVector[i] <- max (featureVector[beg:end], na.rm=TRUE) }
    else { if (MODE == "MINV") { sectionVector[i] <- min (featureVector[beg:end], na.rm=TRUE) }
    else {                       sectionVector[i] <- mean(featureVector[beg:end], na.rm=TRUE) }
    }

    beg <- beg + secLength
    end <- end + secLength
    if (end > featureLength) { end <- featureLength }
  }

  # Smooth the sectionVector using Tukey's (Running Median) Smoothing
  if (SMOOTH) {
    sectionVector <- as.numeric(smooth(sectionVector))
  }


  ornsteinMin <- min(sectionVector)
  ornsteinMax <- max(sectionVector)


  # ... and choose display colors

  numRows <- 37

  rownames <- 1:numRows
  colnames <- c("R", "G", "B")


  # Color map for stacking energy, ranging from green to purple

  ornstein_colorMap.df <- data.frame(
    matrix(
      c(
           0,  77,   0,
           0, 230,   0,
          26, 230,  26,
          51, 230,  51,
          77, 230,  77,
         102, 230, 102,
         128, 230, 128,
         140, 230, 140,
         153, 230, 153,
         166, 230, 166,
         179, 230, 179,
         191, 230, 191,
         204, 230, 204,
         217, 230, 217,
         219, 230, 219,
         222, 230, 222,
         224, 230, 224,
         227, 230, 227,
         230, 230, 230,
         230, 227, 227,
         230, 224, 224,
         230, 222, 222,
         230, 219, 219,
         230, 217, 217,
         230, 204, 204,
         230, 191, 191,
         230, 179, 179,
         230, 166, 166,
         230, 153, 153,
         230, 140, 140,
         230, 128, 128,
         230, 102, 102,
         230,  77,  77,
         230,  51,  51,
         230,  26,  26,
         230,   0,   0,
          77,   0,   0
      ),
      nrow = 37,
      ncol = 3,
      byrow = TRUE,
      dimnames = list(rownames,colnames)
    )
  )


  section.df <- drawRing(sectionVector, probabilities)


  rows <- nrow(section.df)

  angleIncr <- (2 * pi) / rows
   
  arcB <- 0
  arcE <- angleIncr
    
  for (i in 1:rows) {

    xBegOffset <- sin(arcB) * radius
    yBegOffset <- cos(arcB) * radius
    xEndOffset <- sin(arcE) * radius
    yEndOffset <- cos(arcE) * radius

    write(paste0('<path d="M ', circX + xBegOffset, ' ', circY - yBegOffset),                                                    svg_file, append = TRUE)
    write(paste0('         A ', radius, ' ', radius, ' 1 0 1 ', circX + xEndOffset, ' ', circY - yEndOffset, '"'),               svg_file, append = TRUE)

    color <- section.df[i,]$color + 1      # move back to R 1-based indexing
    red   <- ornstein_colorMap.df[color,]$R
    green <- ornstein_colorMap.df[color,]$G
    blue  <- ornstein_colorMap.df[color,]$B
      
    write(paste0('         stroke="rgb(', red, ',', green, ',', blue, ')" stroke-width="', plotSize/20, '" fill-opacity="0"/>'), svg_file, append = TRUE)

    arcB <- arcB + angleIncr
    arcE <- arcE + angleIncr

  }

  # End of transform for ring plots
  write(paste0('</g>'), svg_file, append = TRUE)



  # LEGEND
  # ------

  xCoord <- plotSize
  yCoord <- plotSize / 8

  write(paste0('<rect x="', xCoord, '" y="', yCoord, '" width="', plotSize * 0.4, '" height="', plotSize * 0.66, '" style="fill:rgb(230,230,230)"/>'), svg_file, append = TRUE)


  # Stacking Energy - Ornstein
  # --------------------------

  xCoord <- xCoord + plotSize / 25
  yCoord <- yCoord + plotSize / 20

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-size="', plotSize/10 * 1.75, '%">Stacking Energy</text>'), svg_file, append = TRUE)

  xPos        <- xCoord
  yCoord      <- yCoord + plotSize / 100
  strokeWidth <- plotSize * 0.009

  for (i in 1:numRows) {
    write(paste0('   <path d="M ', xPos, ' ', yCoord),                                                                              svg_file, append = TRUE)
    write(paste0('            L ', xPos, ' ', yCoord + plotSize / 20, '"'),                                                         svg_file, append = TRUE)
    write(paste0('            stroke="rgb(', ornstein_colorMap.df[i,]$R, ',',
                                             ornstein_colorMap.df[i,]$G, ',',
                                             ornstein_colorMap.df[i,]$B, ')" stroke-width="', strokeWidth, '" fill-opacity="0"/>'), svg_file, append = TRUE)
    xPos <- xPos + strokeWidth
  }

  yCoord <- yCoord + plotSize / 20 + plotSize / 80

  minLabel <- sprintf("%.3f", ornsteinMin)
  maxLabel <- sprintf("%.3f", ornsteinMax)

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" text-anchor="start" font-size="', plotSize/12, '%">', minLabel, '</text>'), svg_file, append = TRUE)
  write(paste0('   <text x="', xPos,   '" y="', yCoord, '" text-anchor="end" font-size="',   plotSize/12, '%">', maxLabel, '</text>'), svg_file, append = TRUE)


  # Position Preference - Travers
  # -----------------------------

  yCoord <- yCoord + plotSize / 30

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-size="', plotSize/10 * 1.75, '%">Position Preference</text>'), svg_file, append = TRUE)

  xPos        <- xCoord
  yCoord      <- yCoord + plotSize / 100
  strokeWidth <- plotSize * 0.009

  for (i in 1:numRows) {
    write(paste0('   <path d="M ', xPos, ' ', yCoord),                                                                             svg_file, append = TRUE)
    write(paste0('            L ', xPos, ' ', yCoord + plotSize / 20, '"'),                                                        svg_file, append = TRUE)
    write(paste0('            stroke="rgb(', travers_colorMap.df[i,]$R, ',',
                                             travers_colorMap.df[i,]$G, ',',
                                             travers_colorMap.df[i,]$B, ')" stroke-width="', strokeWidth, '" fill-opacity="0"/>'), svg_file, append = TRUE)
    xPos <- xPos + strokeWidth
  }

  yCoord <- yCoord + plotSize / 20 + plotSize / 80

  minLabel <- sprintf("%.3f", traversMin)
  maxLabel <- sprintf("%.3f", traversMax)

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" text-anchor="start" font-size="', plotSize/12, '%">', minLabel, '</text>'), svg_file, append = TRUE)
  write(paste0('   <text x="', xPos,   '" y="', yCoord, '" text-anchor="end" font-size="',   plotSize/12, '%">', maxLabel, '</text>'), svg_file, append = TRUE)




  # Annotations
  # -----------

  yCoord <- yCoord + plotSize/30

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-size="', plotSize/10 * 1.75, '%">Annotations:</text>'), svg_file, append = TRUE)


  # Forward coding sequences
  # ------------------------
  xPos        <- xCoord + plotSize/18
  yCoord      <- yCoord + plotSize/100

  write(paste0('   <rect x="', xPos, '" y="', yCoord, '" width="', plotSize/15, '" height="', plotSize/36, '" style="fill:rgb(0,0,255)"/>'),                svg_file, append = TRUE)
  write(paste0('   <text x="', xPos + plotSize/15 + plotSize/100, '" y="', yCoord + plotSize/36, '" font-size="', plotSize/10 * 1.5, '%">CDS +</text>'),    svg_file, append = TRUE)


  # Forward coding sequences
  # ------------------------
  yCoord      <- yCoord + plotSize/200 + plotSize/36

  write(paste0('   <rect x="', xPos, '" y="', yCoord, '" width="', plotSize/15, '" height="', plotSize/36, '" style="fill:rgb(255,0,0)"/>'),                svg_file, append = TRUE)
  write(paste0('   <text x="', xPos + plotSize/15 + plotSize/100, '" y="', yCoord + plotSize/36, '" font-size="', plotSize/10 * 1.5, '%">CDS -</text>'),    svg_file, append = TRUE)


  # rRNA sequences
  # ------------------------
  yCoord      <- yCoord + plotSize/200 + plotSize/36

  write(paste0('   <rect x="', xPos, '" y="', yCoord, '" width="', plotSize/15, '" height="', plotSize/36, '" style="fill:rgb(0,255,255)"/>'),              svg_file, append = TRUE)
  write(paste0('   <text x="', xPos + plotSize/15 + plotSize/100, '" y="', yCoord + plotSize/36, '" font-size="', plotSize/10 * 1.5, '%">rRNA</text>'),     svg_file, append = TRUE)



  # Note: The annotation lines collectively are wider than the other rings,
  #       so the yCoord value for the following ring must be incremented by a larger value (smaller denominator)


  # GC Skew
  # -------

  yCoord <- yCoord + plotSize / 16

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-size="', plotSize/10 * 1.75, '%">GC Skew</text>'), svg_file, append = TRUE)

  xPos        <- xCoord
  yCoord      <- yCoord + plotSize / 100
  strokeWidth <- plotSize * 0.009

  # Forward loop - INCORRECT
  # for (i in 1:numRows) {
  # Reverse loop - CORRECT
  for (i in numRows:1) {
    write(paste0('   <path d="M ', xPos, ' ', yCoord),                                                                             svg_file, append = TRUE)
    write(paste0('            L ', xPos, ' ', yCoord + plotSize / 20, '"'),                                                        svg_file, append = TRUE)
    write(paste0('            stroke="rgb(', gcSkew_colorMap.df[i,]$R, ',',
                                             gcSkew_colorMap.df[i,]$G, ',',
                                             gcSkew_colorMap.df[i,]$B, ')" stroke-width="', strokeWidth, '" fill-opacity="0"/>'),  svg_file, append = TRUE)
    xPos <- xPos + strokeWidth
  }

  yCoord <- yCoord + plotSize/20 + plotSize/80

  minLabel <- sprintf("%.3f", minGCskew)
  maxLabel <- sprintf("%.3f", maxGCskew)

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" text-anchor="start" font-size="', plotSize/12, '%">', minLabel, '</text>'), svg_file, append = TRUE)
  write(paste0('   <text x="', xPos,   '" y="', yCoord, '" text-anchor="end" font-size="',   plotSize/12, '%">', maxLabel, '</text>'), svg_file, append = TRUE)


  # PERCENT AT
  # ----------

  yCoord <- yCoord + plotSize / 30

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-size="', plotSize/10 * 1.75, '%">Percent AT</text>'), svg_file, append = TRUE)

  xPos        <- xCoord
  yCoord      <- yCoord + plotSize / 100
  strokeWidth <- plotSize * 0.009

  for (i in 1:numRows) {
    write(paste0('   <path d="M ', xPos, ' ', yCoord),                                                                             svg_file, append = TRUE)
    write(paste0('            L ', xPos, ' ', yCoord + plotSize / 20, '"'),                                                        svg_file, append = TRUE)
    write(paste0('            stroke="rgb(', percentAT_colorMap.df[i,]$R, ',',
                                             percentAT_colorMap.df[i,]$G, ',',
                                             percentAT_colorMap.df[i,]$B, ')" stroke-width="', strokeWidth, '" fill-opacity="0"/>'),  svg_file, append = TRUE)
    xPos <- xPos + strokeWidth
  }

  yCoord <- yCoord + plotSize/20 + plotSize/80

  minLabel <- sprintf("%.3f", minPercentAT)
  maxLabel <- sprintf("%.3f", maxPercentAT)

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" text-anchor="start" font-size="', plotSize/12, '%">', minLabel, '</text>'), svg_file, append = TRUE)
  write(paste0('   <text x="', xPos,   '" y="', yCoord, '" text-anchor="end" font-size="',   plotSize/12, '%">', maxLabel, '</text>'), svg_file, append = TRUE)


  if (FALSE) {
  # Annotations
  # -----------

  yCoord <- yCoord + plotSize/30

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-size="', plotSize/10 * 1.75, '%">Annotations:</text>'), svg_file, append = TRUE)


  # Forward coding sequences
  # ------------------------
  xPos        <- xCoord + plotSize/18
  yCoord      <- yCoord + plotSize/100

  write(paste0('   <rect x="', xPos, '" y="', yCoord, '" width="', plotSize/15, '" height="', plotSize/36, '" style="fill:rgb(0,0,255)"/>'),                svg_file, append = TRUE)
  write(paste0('   <text x="', xPos + plotSize/15 + plotSize/100, '" y="', yCoord + plotSize/36, '" font-size="', plotSize/10 * 1.5, '%">CDS +</text>'),    svg_file, append = TRUE)


  # Forward coding sequences
  # ------------------------
  yCoord      <- yCoord + plotSize/200 + plotSize/36

  write(paste0('   <rect x="', xPos, '" y="', yCoord, '" width="', plotSize/15, '" height="', plotSize/36, '" style="fill:rgb(255,0,0)"/>'),                svg_file, append = TRUE)
  write(paste0('   <text x="', xPos + plotSize/15 + plotSize/100, '" y="', yCoord + plotSize/36, '" font-size="', plotSize/10 * 1.5, '%">CDS -</text>'),    svg_file, append = TRUE)


  # rRNA sequences
  # ------------------------
  yCoord      <- yCoord + plotSize/200 + plotSize/36

  write(paste0('   <rect x="', xPos, '" y="', yCoord, '" width="', plotSize/15, '" height="', plotSize/36, '" style="fill:rgb(0,255,255)"/>'),              svg_file, append = TRUE)
  write(paste0('   <text x="', xPos + plotSize/15 + plotSize/100, '" y="', yCoord + plotSize/36, '" font-size="', plotSize/10 * 1.5, '%">rRNA</text>'),     svg_file, append = TRUE)
  }


  # Resolution
  # ----------
  yCoord <- yCoord + plotSize/15

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-size="', plotSize/10 * 1.75, '%">Resolution: ', ceiling(genomeSize/MAXSECTIONS),'</text>'), svg_file, append = TRUE)


  # Logo
  # ----
  yCoord <- yCoord + plotSize/12

  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-family="Century" font-style="italic" font-size="', plotSize/10 * 3,   '%">RBiotools</text>'),   svg_file, append = TRUE)

  yCoord <- yCoord + plotSize/30
  write(paste0('   <text x="', xCoord, '" y="', yCoord, '" font-family="Helvetica" font-style="italic" font-size="', plotSize/10 * 1.5, '%">createAtlas.R</text>'), svg_file, append = TRUE)





  write('</svg>', svg_file, append = TRUE)

  }

}
