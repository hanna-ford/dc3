#' downloadGenome
#'
#' Downloads genomic information for a set of genomes into an RBiotools session
#'
#' @param accessionList character vector containing GenBank accession numbers
#'
#' @details This function fetches information for a set of genomes specified by accession numbers. It uses \code{rentrez} functions that work with the NCBI Eutils API to search and download data from the GenBank nucleotide database. It catches errors -- both from the user, such as invalid accession numbers, and from GenBank, such as violations of access policies (not expected) -- and skips any accession number that causes an error.
#' For each accession number, \code{entrez_fetch} downloads a FASTA file of the genome sequence and \code{entrez_summary} downloads genomic information, including identifiers, taxonomy, and counts of various types of genes -- protein encoding, pseudo, and RNA.
#'
#' Side effects of \code{downloadGenBank}:
#' \itemize{
#'   \item Converts the sequence(s) in the FASTA file into a \code{DNAStringSet}
#'   \item Appends the \code{DNAStringSet} to the global list of genome sequences \code{GenomeSeqList}
#'   \item Adds sequence identifiers and taxonomy information, \strong{when avaiable via \code{Entrez}}, to the global data frame \code{orgName.df}
#'   \item Adds sequence identifiers, length, AT content, and gene counts to the global data frame \code{orgData.df}
#' }
#'
#' \strong{Note:} The gene counts in \code{orgData.df} are those downloaded from GenBank by \code{entrez_summary}. These counts may differ from the number of genes called by Prodigal or RNAmmer.
#'
#' Identifiers include organism, strain, and substrain names, if available. Additional identifiers are constructed, primarily to give the user options in labeling plots. These additional identifiers include "fullName", which contains organism, strain, and substrain identifers. The "fullName" identifier is necessary because of inconsistencies in organism naming in GenBank. In particular, organism names may include or omit strain and substrain identifiers. A short identifier that is useful for labeling trees for sets of organisms from the same species is the "shortName" identifier, which includes only strain and substrain identifiers.
#'
#' \emph{\strong{Note:} \code{downloadGenome} will seldom, if ever, need to be called directly by the \code{RBiotools} user. \code{RBiotools} functions will automatically initiate downloads from GenBank, if necessary.}
#'
#' \strong{Future enhancements:} Construct a download function for genomes with multiple contigs. These genomes include genomes with multiple chromosomes, such as \emph{Burkholderia mallei ATCC 23344} with chromosome accession numbers CP000010 and CP000011.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' E_coli <- c(
#'   "AP012306",  # Escherichia coli str. K-12 substr. MDS42 DNA
#'   "KK583188",  # Escherichia coli DSM 30083 = JCM 1649 = ATCC 11775
#'   "U00096",    # Escherichia coli str. K-12 substr. MG1655
#'   "CP000802",  # Escherichia coli HS
#'   "CP000800",  # Escherichia coli E24377A
#'   "AP009378",  # Escherichia coli SE15
#'   "FM180568",  # Escherichia coli 0127:H6 E2348/69
#'   "CU928163",  # Escherichia coli UMN026
#'   "CP008957",  # Escherichia coli O157:H7 str. EDL933
#'   "CP027027",  # Shigella dysenteriae strain E670/74
#'   "CP026802",  # Shigella sonnei strain ATCC 29930
#'   "CP026877",  # Shigella boydii strain ATCC 35964
#'   "CP026793",  # Shigella flexneri strain 74-1170
#'   "CP015831"   # Escherichia coli O157 strain 644-PT8
#' )
#'
#' downloadGenome(E_coli)
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings  DNAString DNAStringSet letterFrequency
#' @importFrom RCurl       merge.list
#' @importFrom rentrez     entrez_fetch entrez_summary
#' @importFrom utils       tail




downloadGenome <- function(accessionList) {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)
  get("rRNAcalled.df", envir = .GlobalEnv)

  for (aaa in accessionList) {

    done <- !is.null(GenomeSeqList[[aaa]])
 
    if (done) {  ## Genome data HAS been downloaded
      cat(paste("Genome data for accession ID:", aaa, "has already downloaded\n"))
    }

    if (!done) {    ## Genome data has NOT been downloaded

      ## Download the genome data ...
      ## ... and insert sequence into the GenomeSeqList as a DNAStringSet with the accession ID as its name

      cat(paste("Downloading genome data for organism with accession ID:", aaa, "\n"))

      goodDownload <- tryCatch(     # Skip any downloads that produce errors
        {
          fasta <- entrez_fetch(db = "nucleotide", id = aaa, rettype = "fasta")
          flag <- TRUE
        },
        error = function(e) {
          cat(paste0("   In downloadGenome: An error occured in downloading ", aaa, ": ", e, " Skipping this download.\n"))
          flag <- FALSE
        }
      )

      if (goodDownload) {

        fasta <- sub("\n", "|", fasta)
        fasta <- strsplit(fasta, "\\|")

        org <- fasta[[1]][1]

        org <- gsub(">", "", org)
        org <- sub(" ", "|", org)
        org <- strsplit(org, "\\|")

        # The following two variables are not used ...
        # ... this information is better retrieved using the entrez_summary function
        ver <- org[[1]][1]    # Accession number with version suffix
        nam <- org[[1]][2]

        seq <- fasta[[1]][2]
        seq <- gsub("\n", "", seq)
        seq <- DNAStringSet(as.character(seq))

        # Name the new element of the GenomeSeqList
        #   Note: creating a separate list and then merging is a way to name the sequence with its accession number
        newList <- list()
        newList <- c(newList, seq)
        names(newList) <- aaa

        # Note assignment to global variable - DANGEROUS!!!
        GenomeSeqList <<- merge.list(GenomeSeqList, newList)

        ## Add data to the organism data frames

        info <- entrez_summary(db = "nucleotide", id = aaa)
        s    <- info$statistics  # an informative table, but the number of entries is inconsistent.

        if (info$completeness == "complete") { complete <- "YES" }
        else                                 { complete <- "NO"  }




        ## Extract names for organism

        organismName <- info$organism

        # Check for strain and substrain names
        # ... and construct "fullName" -- the organism name with strain and substrain names appended
        strainName    <- NA
        substrainName <- NA
        isolateName   <- NA
        shortName     <- NA

        subNamesMissing <- TRUE   # Check whether the Entrez summary contains subname(s) ...
                                  # ... specifically a strain or an isolate and possibly a substrain

        subTypes <- unlist(strsplit(info$subtype, "\\|"))
        subNames <- unlist(strsplit(info$subname, "\\|"))
        for (i in 1:length(subTypes)) {
          if (subTypes[i] == "strain") {
            subNamesMissing <- FALSE
            strainName <- subNames[i]
            if (grepl(strainName, organismName)) { fullName <-       organismName                      }
            else                                 { fullName <- paste(organismName, "str.", strainName) }
            shortName <- strainName
          }
          if (subTypes[i] == "isolate") {
            subNamesMissing <- FALSE
            isolateName <- subNames[i]
            if (grepl(isolateName, organismName)) { fullName <-       organismName                          }
            else                                  { fullName <- paste(organismName, "isolate", isolateName) }
            shortName <- isolateName
          }
          if (subTypes[i] == "sub_strain") {
            subNamesMissing <- FALSE
            substrainName <- subNames[i]
            if (grepl(substrainName, organismName)) { fullName <-       organismName                            }
            else                                    { fullName <- paste(organismName, "substr.", substrainName) }
            shortName <- paste(strainName, "substr.", substrainName)
          }
        }

        if (subNamesMissing) {
          fullName <- organismName
          shortName <- tail(strsplit(organismName, split=" ")[[1]],1)  # This is just the last word in the organism name
                                                                       # ... which may work as a "strain" ... or not
        }



        newRow <- data.frame(accession  = aaa,
                             version    = info$accessionversion,
                             complete   = complete,
                             organism   = organismName,
                             strain     = strainName,
                             substrain  = substrainName,
                             fullName   = fullName,
                             shortName  = shortName,
                             taxonomyID = info$taxid,
                             GInumber   = info$gi,
                             stringsAsFactors = FALSE
                            )

        if (orgName.df$accession[1] == "NONE") {
          orgName.df <<- newRow
        }
        else {
          orgName.df <<- rbind(orgName.df, newRow)     ## assignment to a global variable
        }

        # Parse the summary statistics table returned via Entrez

        cnt_Genes   <- s[which(s$type == "gene"     & is.na(s$subtype)           & is.na(s$source)),]$count
        cnt_CDS     <- s[which(s$type == "cdregion" & s$subtype == "CDS"         & is.na(s$source)),]$count
        cnt_pseudo  <- s[which(s$type == "gene"     & s$subtype == "Gene/pseudo" & is.na(s$source)),]$count
        cnt_RNA     <- s[which(s$type == "rna"      & is.na(s$subtype)           & is.na(s$source)),]$count
        cnt_rRNA    <- s[which(s$type == "rna"      & s$subtype == "rRNA"        & is.na(s$source)),]$count
        cnt_tRNA    <- s[which(s$type == "rna"      & s$subtype == "tRNA"        & is.na(s$source)),]$count
        cnt_ncRNA   <- s[which(s$type == "rna"      & s$subtype == "ncRNA"       & is.na(s$source)),]$count
        cnt_tmRNA   <- s[which(s$type == "rna"      & s$subtype == "tmRNA"       & is.na(s$source)),]$count
        cnt_miscRNA <- s[which(s$type == "rna"      & s$subtype == "misc_RNA"    & is.na(s$source)),]$count


        # The Entrez data frame returned for a contig differs from that of a complete genome
        # A gene count of 0 from the search above is (probably) an indication of an incomplete genome

        if (!length(cnt_Genes )) { cnt_Genes <- 0 }

        # Change the parameters of the parse for a contig

        if (cnt_Genes == 0) {
          cnt_Genes   <- s[which(s$type == "gene"     & is.na(s$subtype)           & s$source == "component"),]$count
          cnt_CDS     <- s[which(s$type == "cdregion" & s$subtype == "CDS"         & s$source == "component"),]$count
          cnt_pseudo  <- s[which(s$type == "gene"     & s$subtype == "Gene/pseudo" & s$source == "component"),]$count
          cnt_RNA     <- s[which(s$type == "rna"      & is.na(s$subtype)           & s$source == "component"),]$count
          cnt_rRNA    <- s[which(s$type == "rna"      & s$subtype == "rRNA"        & s$source == "component"),]$count
          cnt_tRNA    <- s[which(s$type == "rna"      & s$subtype == "tRNA"        & s$source == "component"),]$count
          cnt_ncRNA   <- s[which(s$type == "rna"      & s$subtype == "ncRNA"       & s$source == "component"),]$count
          cnt_tmRNA   <- s[which(s$type == "rna"      & s$subtype == "tmRNA"       & s$source == "component"),]$count
          cnt_miscRNA <- s[which(s$type == "rna"      & s$subtype == "misc_RNA"    & s$source == "component"),]$count
        }

        if (!length(cnt_Genes  )) { cnt_Genes   <- 0 }
        if (!length(cnt_CDS    )) { cnt_CDS     <- 0 }
        if (!length(cnt_pseudo )) { cnt_pseudo  <- 0 }
        if (!length(cnt_RNA    )) { cnt_RNA     <- 0 }
        if (!length(cnt_rRNA   )) { cnt_rRNA    <- 0 }
        if (!length(cnt_tRNA   )) { cnt_tRNA    <- 0 }
        if (!length(cnt_ncRNA  )) { cnt_ncRNA   <- 0 }
        if (!length(cnt_tmRNA  )) { cnt_tmRNA   <- 0 }
        if (!length(cnt_miscRNA)) { cnt_miscRNA <- 0 }


        N_count <- sum(letterFrequency(seq, "N"))   # used for more accurate calculation of AT content
        seqLength = sum(seq@ranges@width)
     
        newRow <- data.frame(accession   = aaa,
                             organism    = info$organism,
                             strain      = info$strain,
                             seq_length  = seqLength,
                             AT_content  = paste0(sprintf("%4.2f", as.double(sum(letterFrequency(seq, "AT"))*100) / as.double(seqLength - N_count)), "%"),
                             num_Genes   = cnt_Genes,
                             num_CDS     = cnt_CDS,
                             num_pseudo  = cnt_pseudo,
                             num_RNA     = cnt_RNA,
                             num_rRNA    = cnt_rRNA,
                             num_tRNA    = cnt_tRNA,
                             num_ncRNA   = cnt_ncRNA,
                             num_tmRNA   = cnt_tmRNA, 
                             num_miscRNA = cnt_miscRNA, 
                             stringsAsFactors = FALSE
                            )

        if (orgData.df$accession[1] == "NONE") {
          orgData.df <<- newRow
        }
        else {
          orgData.df <<- rbind(orgData.df, newRow)     ## assignment to a global variable
        }



        # Initialize the rRNAcalled dataframe

        newRow <- data.frame(accession = aaa,
                             type      = "TSU",              ## 5S
                             called    = FALSE,
                             stringsAsFactors = FALSE
                            )

        if (rRNAcalled.df$accession[1] == "NONE") {
          rRNAcalled.df <<- newRow
        }
        else {
          rRNAcalled.df <<- rbind(rRNAcalled.df, newRow)
        }

        newRow <- data.frame(accession = aaa,
                             type      = "SSU",              ## 16S
                             called    = FALSE,
                             stringsAsFactors = FALSE
                            )
        rRNAcalled.df <<- rbind(rRNAcalled.df, newRow)

        newRow <- data.frame(accession = aaa,
                             type      = "LSU",              ## 23S
                             called    = FALSE,
                             stringsAsFactors = FALSE
                            )
        rRNAcalled.df <<- rbind(rRNAcalled.df, newRow)
      }
    }
  }
}
