#' addGenome
#'
#' Adds a user-supplied genome to the set of genomes in an RBiotools session
#'
#' @details The primary use of the \code{addGenome} function is to add a genome nucleotide sequence in FASTA format to the \code{GenomeSeqList} in the \code{RBiotools} global data infrastructure. This is necessary when a genome of interest is not available from GenBank. A typical application of \code{addGenome} is to incorporate a \emph{newly sequenced genome} into \code{RBiotools} so that it may be included in a set of known genomes for comparative genomics analyses.
#'
#' @details The user is interactively queried for
#' \itemize{
#'   \item \strong{Unique Identifier} -- A unique identifier that serves as an \emph{accession number} for the genome, such as: \code{XX000001} --- Note that "XX" is not currently used as an accession prefix by GenBank, EMBL, or DDBJ.
#'   \item \strong{FASTA file Name} -- The name of a file in FASTA format \emph{in the current working directory} that contains one or more nucleotide sequences, such as: \code{XX000001.fasta}
#'   \item \strong{General Identifier} -- An identifier that corresponds to a \emph{species}-level identifier, such as: \code{Clinical Isolates from Sample ABC}
#'   \item \strong{Specific Identifier} -- An identifier that corresponds to a \emph{strain}-level identifier, such as: \code{ABC.01}
#' }
#'
#' Side Effects of \code{addGenome}:
#' \itemize{
#'   \item Converts the sequence(s) in the FASTA file into a \code{DNAStringSet}
#'   \item Appends the \code{DNAStringSet} to the global list of genome sequences \code{GenomeSeqList}
#'   \item Adds sequence identifiers to the global data frame \code{orgName.df}
#'   \item Adds sequence identifiers, length, and AT content to the global data frame \code{orgData.df}
#' }
#'
#' @return None
#'
#' \strong{Development Notes}
#'
#' Questions
#' \itemize{
#'   \item{Should the user be prompted for identifiers and FASTA file name (as currently implemented), or should these be supplied as function parameters?}
#'   \item{Would an additional third-level identifier be useful to clinical and experimental biologists?}
#' }
#'
#' @examples
#' \dontrun{
#'
#' # Requires a nucleotide FASTA file (such as XX000001.fasta) in the current working directory
#' # Possible user input is shown after each prompt.
#'
#' addGenome()
#' Enter the unique identifier you will use to reference this genome: XX000001
#' Enter the FASTA file name for genomic sequence(s): XX000001.fasta
#' Enter a general identifier (e.g., species) for these genome sequence(s): Clinical Isolates from Sample ABC
#' Enter a specific identifier (e.g., strain) for these genome sequence(s): ABC.01
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings DNAString DNAStringSet letterFrequency
#' @importFrom RCurl merge.list




addGenome <- function() {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }
  
  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)

  # Check whether this genome is new or a replacement

  replace <- FALSE

  accessionID <- readline("Enter the unique identifier you will use to reference this genome: ")
  alreadyUsed <- !is.null(GenomeSeqList[[accessionID]])

  while (alreadyUsed) {  ## Unique ID  has already been used
    change <- readline("This identifer is already in use. Replace existing entry? ")
    change <- tolower(change)
    if (substring(change, 1, 1) == "y") {
      replace <- TRUE
      alreadyUsed <- FALSE
    }
    else {
      accessionID <- readline("Enter the unique identifier you will use to reference this genome: ")
      alreadyUsed <- !is.null(GenomeSeqList[[accessionID]])
    }
  }

  # Read FASTA file from working directory
  
  file_name <- readline("Enter the FASTA file name for genomic sequence(s): ")
  # cat(paste("File name: ", file_name, "\n"))

  if (!file.exists(file_name)) {
    cat(paste0("File '", file_name, "' not found in the current working directory '", getwd(), "'\n"))
    opt <- options(show.error.messages=FALSE) 
    on.exit(options(opt)) 
    stop()
  }

  # Read the sequences from the FASTA file ... 
  
  buffer <- file(file_name, "r")
  seqString <- paste(readLines(buffer), collapse = "\n")  # Read the FASTA file - no format checking done
  close(buffer)


  # ... and convert into a DNAStringSet

  seqString <- gsub("\n+", "\n", seqString)           # collapse multiple newlines into a single newline
  sequences <- strsplit(seqString, ">[^\n]+\n")[[1]]  # split the sequence string on the headers

  seqSet <- DNAStringSet()
  for (seq in sequences) {
    seq <- gsub("\\s", "", seq) # remove all whitespace from the sequence
    if (nchar(seq) > 0) {
      seqSet <- DNAStringSet(c(seqSet, DNAStringSet(as.character(seq))))
    }
  }

  # Name the new element of the GenomeSeqList
  #   Note: creating a separate list and then merging is a way to name the sequence with its accession number
  newList <- list()
  newList <- c(newList, seqSet)
  names(newList) <- accessionID

  # Note assignment to global variable - DANGEROUS!!!
  GenomeSeqList <<- merge.list(GenomeSeqList, newList)
  
  # return(seqSet)

  generalID   <- readline("Enter a general identifier (e.g., species level) for these genome sequence(s): ")
  specificID  <- readline("Enter a specific identifier (e.g., strain level) for these genome sequence(s): ")

  # ??? Would an even more specific identifier corresponing to a substrain level be useful?


  # Construct "fullName" -- the general identifier with specific identifier appended

  if (grepl(specificID, generalID)) {    # specific identifier IS part of the general identifier
    fullName <- generalID
  }
  else {                                 # specific identifier NOT part of the general identifier
    fullName <- paste(generalID, "str.", specificID)    # ??? Should something other than "str." be used here to attach the specific to the general?
  }


  # Add row to Organism Name dataframe

  newRow <- data.frame(accession  = accessionID,
                       version    = NA,
                       complete   = "DRAFT",
                       organism   = generalID,
                       strain     = specificID,
                       substrain  = NA,
                       fullName   = fullName,
                       shortName  = specificID,
                       taxonomyID = NA,
                       GInumber   = NA,
                       stringsAsFactors = FALSE
                      )

  if (orgName.df$accession[1] == "NONE") {
    orgName.df <<- newRow
  }
  else {
    orgName.df <<- rbind(orgName.df, newRow)     ## assignment to a global variable
  }

  # Add row to Organism Data dataframe

  N_count <- sum(letterFrequency(seqSet, "N"))   # used for more accurate calculation of AT content
  seqSetLength <- sum(seqSet@ranges@width)

  
  newRow <- data.frame(accession  = accessionID,
                       organism   = generalID,
                       strain     = specificID,
                       seq_length = seqSetLength,
                       AT_content = paste0(sprintf("%4.2f", as.double(sum(letterFrequency(seqSet, "AT"))*100) / as.double(seqSetLength - N_count)), "%"),
                       num_Genes   = NA,
                       num_CDS     = NA,
                       num_pseudo  = NA,
                       num_RNA     = NA,
                       num_rRNA    = NA,
                       num_tRNA    = NA,
                       num_ncRNA   = NA,
                       num_tmRNA   = NA,
                       num_miscRNA = NA,
                       stringsAsFactors = FALSE
                      )

  if (orgData.df$accession[1] == "NONE") {
    orgData.df <<- newRow
  }
  else {
    orgData.df <<- rbind(orgData.df, newRow)     ## assignment to a global variable
  }

}
