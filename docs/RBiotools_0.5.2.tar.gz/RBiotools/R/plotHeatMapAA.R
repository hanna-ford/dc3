#' plotHeatMapAA
#'
#' A function for plotting heatmaps for amino acid usage across a set of genomes
#'
#' @param accessionList character vector containing GenBank accession numbers
#' @param organismIdentifier character vector indicating the name to be used for organisms; options are \code{"fullName"} or \code{"shortName"}; \code{"fullName"} is recommended for a diverse, multi-species set of genomes; \code{"shortName"} is recommended for a single-species set of genomes
#' @param plotIdentifier character vector containing a title for the plot
#' @param colorPalette character vector indicating the color palette to be used in the heatmap; options are the color palettes from the \code{grDevices} package: \code{"cm"}, \code{"topo"}, \code{"terrain"}, \code{"heat"}, \code{"rainbow"}
#' @param plotMethod character vector indicating the R function to use for plotting the heatmap; options are \code{"heatmap"} from the \code{stats} package, \code{"heatmap.2"} from the \code{gplots} package, and \code{"pheatmap"} from the \code{"pheatmap"} package. This parameter is included during the development process. (See \strong{Development Notes} below.) When the best function for amino acid usage heatmaps is determined, this parameter will likely be removed.
#'
#' @details A heatmap is a graphical representation of data in a matrix that uses color-coding to represent different data values. \code{plotHeatMapAA} plots heatmaps for amino acid usage across a set of genomes (one or more) using a variety of methods from several R packages. A PNG file is created in the working directory.
#'
#' \strong{Development Notes}
#'
#' General questions
#' \itemize{
#'   \item{Which will be simpler for clinical / experimental biologists to use: 1) Splitting tasks into different functions -- separate heatmap functions for amino acids and for codons, for example, or 2) combining related tasks into a single function -- \code{plotUsage}, for example, which plots usage for amino acids or codons or plots position bias using either a radar plot or a circular bar plot?}
#'   \item{Should users provide names for the .PNG plot files? Should the heatmap plotting functions add sequence numbers to the plot file names to distinguish them and, in doing so, not overwrite earlier plot file? What are the tradeoffs?}
#' }
#'
#' Heatmaps can be challenging to configure. Some are based on the \code{ggplot2} R package by Hadley Wickham, a system for declaratively creating graphics, based on \emph{The Grammar of Graphics} by Leland Wilkinson. \code{ggplot2} is documented in \emph{ggplot2: Elegant Graphics for Data Analysis}, a 257-page Springer publication in the \emph{Use R!} series. Complications arise when a heatmap function built on \code{ggplot2} alters access to the \code{ggplot2} controls, and, in some cases, renames \code{ggplot2} functions. This results in situations where modifications to heatmaps must be made by either resetting the heatmap function parameters or \code{ggplot2} parameters -- sometimes either will work, sometimes neither. A rather complicated case in point: \code{ggplot2} rotates text labels by specifying \code{angle}. \code{angle} does not work with \code{pheatmap}, which uses \code{rot} in the \code{draw_columns} function, which is not directly accessible to the user. The \code{draw_columns} function, therefore, must be overwritten in the \code{pheatmap} namespace to rotate column labels. A couple of auxiliary functions have been added to \code{plotHeatMapAA} to overwrite the \code{pheatmap} namespace so that amino acid codes, which label the columns, will be displayed horizontally rather than vertically. So the bottom line is ... there is a lot of fine tuning of the heatmaps that can be done, but it's complicated. Development of heatmap codes for \code{RBiotools} is currently at a level where return for effort is significantly diminished.
#'
#' Heatmaps are displayed in a .PNG format in a window external to R Studio, rather than in the R Studio plot pane. This approach allows precise control over the size of the plot, which can vary significantly if visualized in the R Studio plot pane. \code{plotHeatMapAA} writes a file named \code{HeatMapAA.png} in the current working directory.
#'
#' Heatmap functions currently implemented are
#' \itemize{
#'   \item{\code{heatmap} from the \code{stats} package
#'     \itemize{
#'       \item{A square plot. The aspect ratio can be changed with \code{asp}, but dendrograms do not resize and are not, therefore, aligned with the heatmap.}
#'       \item{The title (specified with \code{main}) overlaps the top margin of the plot unless prepended with a newline (\code{"\n"}) to lower it into the display. The title appears in the space for the column dendrogram. Question: How to create a margin at the top of the display for a title?}
#'       \item{Bottom and right margins for the column and row names are set with \code{margins}, a numeric vector of length 2. These margins \strong{do not} adjust to the length of the names.}
#'       \item{Column labels are -90 degrees from a horizontal text line. Question: How to rotate the column labels (single character amino acid codes) so they are upright?}
#'     }
#'   }
#'   \item{\code{heatmap.2} from the \code{gplots} package
#'     \itemize{
#'       \item{\emph{Improvements over} \code{heatmap}: 1) Column labels can be rotated with the \code{srtCol} parameter. 2) Margin for row labels can be easily adjusted to accommodate short or full (long) names for organisms. Currently done by setting the margin to pre-determined widths, depending on whether short or full names are displayed. This could be a problem if an organism has a very long name. 3) A color-key with histogram (indicating the number of matrix entries within a certain range) is plotted.}
#'       \item{The title appears in the space for the column dendrogram. A less-than-optimal solution is to use the color-key as a substitute for the main title.}
#'     }
#'   }
#'   \item{\code{pheatmap} from the \code{pheatmap} package
#'     \itemize{
#'       \item{\emph{Improvements over} \code{heatmap} \emph{and} \code{heatmap.2}: 1) Margin for row labels is \emph{automatically} adjusted to accommodate short or full (long) names for organisms. 2) Numbers can be displayed inside a heatmap matrix entry to show the usage of an amino acid (relative to the maximum for that organism). 3) The upper margin of the plot is wide enough to accomodate a two-line title above the column dendrogram. }
#'       \item{A simple color-key is plotted in the upper right corner of the display. It is simpler than the \code{heatmap.2}, and, unfortunately, it seems to use the same point size as the main title of the plot. The color-key is currently supressed because of the point size issue and because it is redundant if relative amino acid usage is plotted inside each heatmap matrix entry.}
#'       \item{Column labels can be rotated, but, as noted above, \emph{it's complicated!}}
#'       \item{Question: How can the line width of the dendrograms be changed. They are currently too narrow.}
#'     }
#'   }
#' }
#'
#' Note that all of the currently implemented methods construct dendrograms use the \code{distfun} function to compute distances between vectors and the \code{hclust} function for clustering. Both of these functions are from the \code{stats} R package. \code{distfun} defaults to the \code{"euclidian"} method, and \code{hclust} defaults to the \code{"complete"} linkage method. These defaults may be changed (see the documentation for \code{distfun} and \code{hclust}) but are used in all of the heatmap functions currently implemented in \code{RBiotools}.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' myGenomes <- c("AP012306", "KK583188", "U00096", "CP000802", "CP000800")  # E. coli genomes
#' plotHeatMapAA(myGenomes)
#' }
#'
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings AAStringSet alphabetFrequency
#' @importFrom data.table setDT
#' @importFrom gplots heatmap.2
#' @importFrom grDevices colors cm.colors dev.off heat.colors png rainbow terrain.colors topo.colors
#' @importFrom grid gpar textGrob unit
#' @importFrom pheatmap pheatmap
#' @importFrom stats heatmap
#' @importFrom utils assignInNamespace



# ??? For future use ??? ... building a heatmap directly on ggplot2 ... some of the functions that will be needed:
# @importFrom ggplot2 aes coord_polar element_blank element_line element_rect element_text geom_bar ggplot guides labs rel scale_fill_manual scale_y_continuous theme



plotHeatMapAA <- function(accessionList, organismIdentifier = "shortName", plotIdentifier = NULL, colorPalette = "cm", plotMethod = "heatmap.2") {

  ## -----------
  ## --<BEGIN>-- Common code for all plotHeatMap functions
  ## -----------

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }
  
  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)


  # Replace the accessionList with a list of identifiers that have been checked
  #   See the checkIdentifier function documentation

  checkedList <- character()
  for (uncheckedID in accessionList) {
    checkedID <- checkIdentifier(uncheckedID)
    checkedList <- c(checkedList, checkedID)
  }

  # Check whether organisms have been downloaded

  newList <- character()
  for (organism in checkedList) {
    if (!(organism %in% orgName.df$accession)) {  # Not downloaded
      downloadGenBank(organism)
      if (!(organism %in% orgName.df$accession)) {  # Download failed
        # cat(paste("Download of organism with accession", organism, "failed\n"))
        cat(paste("  Continuing plotHeatMapAA without", organism, "\n"))
      }
      else {
        newList <- c(newList, organism)
      }
    }
    else {  # Previously downloaded
      newList <- c(newList, organism)
    }
  }

  # Redefine checkedList, omiting any organisms for which downloading failed
  checkedList <- newList


# Alternate (better?) way to check whether genomes have been downloaded

#  for (organism in checkedList) {
#
#    seqSet <- GenomeSeqList[organism][[organism]]
#    if (is.null(seqSet)) {  # NOT downloaded
#      # cat(paste("Downloading genome with acccession ID:", organism, " from GenBank\n"))
#      downloadGenBank(organism)
#    }
#  }


  # Check whether protein genes have been called

  for (organism in checkedList) {
    proteins <- AAStringSet(ProdigalCalls[which(ProdigalCalls$accession == organism),]$protein)

    if (length(proteins@ranges@width) == 0) {
      cat(paste("Calling protein genes for accession ID:", organism, "\n"))
      runProdigal(organism, verbose = FALSE)
    }
  }


  ## Set the method to be used for plotting the heatmap

  if (plotMethod == "heatmap"  ) method <- "heatmap"   # Basic heatmap in R package "stats"
  if (plotMethod == "heatmap.2") method <- "heatmap.2" # Provides extensions to the basic heatmap; in R package gplots
  if (plotMethod == "pheatmap" ) method <- "pheatmap"  # Plots "pretty heatmaps" using R package pheatmap


  if (organismIdentifier == "longName") {
    organismIdentifier <- "fullName"
  }

  ## ---------
  ## --<END>-- Common code for all plotHeatMap functions
  ## ---------


  aaCounts    <- data.frame()
  allProteins <- AAStringSet()

  for (organism in checkedList) {

    # Set up organism names to be used in the heatmap

    if (organismIdentifier == "fullName") {
      organismName <- paste0(" ", orgName.df[orgName.df$accession == as.name(organism),]$fullName)
    }
    if (organismIdentifier == "shortName") {
      organismName <- paste0(" ", orgName.df[orgName.df$accession == as.name(organism),]$shortName)
    }


    proteins <- AAStringSet(ProdigalCalls[which(ProdigalCalls$accession == organism),]$protein)


    # Sum amino acids across all protein translations

    # cat(paste0('Plotting amino acid heatmap for ', length(allProteins@ranges@width), ' proteins', '\n'))
    aaSum <- colSums(alphabetFrequency(proteins))
      
    aaUse <- aaSum[c("A","V","L","I","F","Y","W","H","K","R","D","E","N","Q","S","T","M","C","P","G")]
    aaUse <- as.data.frame(aaUse)
      
    # Add the aaUse row names to the dataframe as a column
    invisible(setDT(aaUse, keep.rownames = TRUE)[])
      
    # Rename the dataframe columns
    names(aaUse) <- c("symbol", "count")
      
    # Scale the AA counts
    aaUse$scaled <- aaUse$count/max(aaUse$count)

      
    aaData <- as.data.frame(t(aaUse$scaled))
    colnames(aaData) <- aaUse$symbol
    rownames(aaData) <- organismName

    if (method == "pheatmap") { # This is a kludge that seems to fix margin problems
      colnames(aaData) <- paste0(" ", aaUse$symbol, " ")
      rownames(aaData) <- paste0(organismName , "  ")
    }
    if (method == "heatmap.2") { # This is a kludge that seems to fix margin problems between the labels and the plot
      colnames(aaData) <- paste0("\n", aaUse$symbol)
      rownames(aaData) <- paste0(organismName , "  ")
    }
    
    aaCounts <- rbind(aaCounts, aaData)


  }

  # Set the color palette

  colPal <- NULL

  if (colorPalette == "cm"     ) { colPal <- cm.colors(100)      }
  if (colorPalette == "heat"   ) { colPal <- heat.colors(100)    }
  if (colorPalette == "topo"   ) { colPal <- topo.colors(100)    }
  if (colorPalette == "terrain") { colPal <- terrain.colors(100) }
  if (colorPalette == "rainbow") { colPal <- rainbow(100)        }
  
  if (is.null(colPal)) {
    cat(paste0('Color palette "',  colorPalette, '" not recognized. Using color palette "cm"', '\n'))
    colPal <- cm.colors(100)
  }


  ## Plot the heatmap

  if (method == "pheatmap" ) {

    ## Overwrite the default draw_colnames with a new version 

    assignInNamespace(
      x = "draw_colnames",
      value = .draw_colnames_AA,
      ns = asNamespace("pheatmap")
    )

    # Set-up for call to pheatmap
    
    plotHeight = 1500 + length(checkedList) * 160
    png(filename = "HeatMapAA.png", width = 8000, height = plotHeight)
    
    par(
        mar=c(70,80,70,70),
        lwd = 6, lty = 1      # These don't seem to have any effect - would like wider lines in the dendrograms
       )

    pheatmap(
      aaCounts,
    
      color = colPal,
      border_color = "grey60",

      treeheight_row = 1000,
      treeheight_col = 1000,
    
      fontsize = 100,
      fontsize_row = 70,
      fontsize_col = 90,
      
      legend = FALSE,
    
      display_numbers = TRUE,
      fontsize_number = 40,
      number_format = "%.3f",
    
      main = paste0("Amino Acid Usage - Relative Abundance", "\n", plotIdentifier)
    
    )
    
    dev.off()
  }

  
  
  
  if (method == "heatmap.2" ) {
    if (organismIdentifier == "shortName") { rMargin <-  60 }
    if (organismIdentifier == "fullName")  { rMargin <- 175 }
    
    plotHeight = 1500 + length(checkedList) * 120
    png(filename = "HeatMapAA.png", width = 8000, height = plotHeight)
    
    par(cex.main = 5.0,
        cex.axis = 4.0,
        mar = c(10,10,10,10),
        lwd = 6, lty = 1
        )
    
    heatmap.2(as.matrix(aaCounts),
              col = colPal,
              
              cexRow = 6,
              cexCol = 8,

              key = TRUE,
              keysize = 5,
              key.title = paste0("Amino Acid Relative Abundance", "\n", plotIdentifier),  # surrogate for title of entire plot
              key.xlab = NA,
              key.ylab = NA,
              key.par=list(mgp = c(3, 3, 0),
                           mar = c(5, 10, 20, 10),
                           cex = 1
                          ),
              tracecol = "black",

              density.info = "histogram",
              trace = "none",
              
              # main = paste0("Amino Acid Usage - Relative Abundance", "\n", plotIdentifier),
              main = NA,  # unable to adjust upper margin of plot to make space for title
              
              lwid = c(0.4, 1.6),
              lhei = c(0.5, 1.5),
              margins = c(20, rMargin),
              
              adjCol = 0.5,
              
              srtCol = 0     # column label rotation - not available in the "heatmap" function from package "stats"
             )
    dev.off()
    
  }
  
  if (method == "heatmap" ) {
    plotHeight = 1500 + length(checkedList) * 160
    png(filename = "HeatMapAA.png", width = 8000, height = plotHeight)
    
    par(cex.main = 5.0,
        cex.axis = 4.0,
        lwd = 6, lty = 1     # modify line width and type
    )
    
    heatmap(as.matrix(aaCounts),
            # Prepending a newline to the title in "main" moves it into the plot space, but
            #   it overwrites the column dendrogram.
            # main = paste0("\n", plotIdentifier)
            main = NA,      # unable to adjust upper margin of plot to make space for title

            col = colPal,
            cexRow = 6,
            cexCol = 6,
            
            margins = c(20,20)
    )
    
    dev.off()
  }
  
  ## Additional heatmap methods to be checked / added???

  # library(heatmaply)
  # library(plotly)
  # library(viridis)

  if (method == "heatmaply" ) {
    heatmaply(as.matrix(aaCounts)
    )
  }

  # library(ComplexHeatmap)

  if (method == "Heatmap" ) {
    Heatmap(as.matrix(aaCounts)
    )
  }

}



## An auxiliary function to overwrite the pheatmap namespace to rotate the column identifiers (amino acid codes) so that the text runs horizontally

# To display amino acid codes horizontally, overwrite default draw_colnames in the pheatmap package
# Code courtesy of Josh O'Brien at http://stackoverflow.com/questions/15505607

.draw_colnames_AA <- function (coln, gaps, ...) {
    coord = pheatmap:::find_coordinates(length(coln), gaps)
    x = coord$coord - 0.5 * coord$size
    res = textGrob(coln,
                    x = x,
                    y = unit(1, "npc") - unit(3,"bigpts"),
                    vjust = 1.5,
                    hjust = 0.5,
                    rot = 0,
                    gp = gpar(...)
                  )
    return(res)
}
