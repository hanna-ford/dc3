#' dendrogram16S
#'
#' A function for constructing and plotting a dendrogram using ribosomal RNA 16S sequences
#'
#' @references O. Gascuel (1997) \emph{BIONJ: an improved version of the NJ algorithm based on a simple model of sequence data} \url{https://doi.org/10.1093/oxfordjournals.molbev.a025808}
#'
#' @param accessionList character vector containing GenBank accession numbers
#' @param treeType character vector with values "FULL" or "BEST" indicating whether the full set of ribosomal RNA 16S sequences will be use to construct a dendrogram, or only the highest scoring 16S sequence from each organism.
#' @param leafLabel character vector indicating how the leaves of the dendrogram are to be labeled. Options are \code{"fullName"} or \code{"shortName"}. \code{"fullName"} is recommended for a diverse, multi-species set of genomes. \code{"shortName"} is recommended for a single-species set of genomes.
#' @param plotIdentifier character vector containing a title for the plot
#'
#' @details This function plots a dendrogram based on ribosomal RNA 16S sequences.
#'
#' The function \code{dendrogram16S}
#' \enumerate{
#'   \item{extracts the specified 16S sequences from the \code{RBiotools} global storage,}
#'   \item{aligns the sequences using the \code{msa} -- MultiSequence Alignment -- function from the \code{msa} R package,}
#'   \item{computes the pairwise distances between sequences using the "raw" evolutionary model -- the proportion or the number of sites that differ between each pair of sequences -- of the \code{dist.dna} function from the \code{ape} R package, and}
#'   \item{constructs a dendrogram using the \code{bionj} function, which performs the BIONJ algorithm of Gascuel, from the \code{ape} package. Note that clustering using the Neighbor Joining algorithm results in an \emph{unrooted} tree.}
#'   \item{It then plots the dendrogram using \code{plot} from the \code{R Graphics Package}.}
#' }
#'
#' \strong{Possible future enhancements:}
#' \itemize{
#'   \item{Scale the size of labels to accomodate for the size of the dendrogram}
#'   \item{Specify the maximum number of 16S sequences from a single genome to be used in constructing the dendrogram, allowing gradations between "BEST" and "FULL"}
#'   \item{Construct a representative 16S sequence for each organism from its set of 16S sequences, and use representative sequences to construct the dendrogram}
#'   \item{Use more sophisticated methods for constructing trees, such as those found in the \emph{Phylogenetic Inference} packages from the CRAN \emph{Phylogenetics} project}
#' }
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' myGenomes <- c("CP018228", "CP017405", "HG530068", "CP002031", "CP002332") # Proteobacteria
#' dendrogram16S(myGenomes)
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom ape add.scale.bar as.DNAbin bionj dist.dna
#' @importFrom Biostrings DNAStringSet
#' @importFrom graphics par plot
#' @importFrom msa msa




dendrogram16S <- function(accessionList, treeType = "BEST", leafLabel = "shortName", plotIdentifier = NULL) {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)

  # Replace the accessionList with a list of identifiers that have been checked
  #   See the checkIdentifier function documentation

  checkedList <- character()
  for (uncheckedID in accessionList) {
    checkedID <- checkIdentifier(uncheckedID)
    checkedList <- c(checkedList, checkedID)
  }

  # Check whether organisms have been downloaded

  newList <- character()
  for (organism in checkedList) {
    if (!(organism %in% orgName.df$accession)) {  # Not downloaded
      downloadGenBank(organism)
      if (!(organism %in% orgName.df$accession)) {  # Download failed
        # cat(paste("Download of organism with accession", organism, "failed\n"))
        cat(paste("  Continuing dendrogram16s without", organism, "\n"))
      }
      else {
        newList <- c(newList, organism)
      }
    }
    else {  # Previously downloaded
      newList <- c(newList, organism)
    }
  }

  # Redefine checkedList, omiting any organisms for which downloading failed
  checkedList <- newList


  # Check whether 16S rRNA genes have been called

  for (organism in checkedList) {
    genes.df <- RNAmmerCalls[which(RNAmmerCalls$accession == organism),]
    if (nrow(genes.df) == 0) { # Genes have not been called
      runRNAmmer(organism, scope = "16s")
    }
  }


  ## Choose the subset of 16S genes from the organisms in checkedList

  ## TO DO:
  ##   Perhaps replace FULL and BEST with an integer indicating the maximum number of 16S sequences to use from each organism?

  # Extract FULL set of 16S genes ... assume that RNAmmerCalls may also contain TSU and LSU rRNA genes
  geneSet <- RNAmmerCalls[which(RNAmmerCalls$accession %in% checkedList),]      # All rRNA
  geneSet <- geneSet[which(geneSet$molecule == "SSU"),]                         # Subset of only 16s rRNA

  if (treeType == "BEST") {
    geneSet <- geneSet[which(geneSet$rank == 1),]
  }

  numGenes <- nrow(geneSet)

  if (numGenes < 3) {
    cat("The accession list contains", numGenes, "genes. There must be as least 3.\n")
  }

  else {
  
    ## Plot dendrogram for the set of 16S rRNA sequences
  
    cat(paste("Creating dendrogram for", numGenes, "16S rRNA sequences\n"))
  
    rRNAset <- DNAStringSet(geneSet$gene)


    # Add names to the sequences

    if (leafLabel == "longName") {
      leafLabel <- "fullName"
    }

    labels <- character(0)

    for (n in 1:nrow(geneSet)) {
      if (leafLabel == "accession") {
        labels[n] <- paste0(" ", geneSet$accession[n])
      }
      if (leafLabel == "fullName") {
        labels[n] <- paste0(" ", orgName.df[orgName.df$accession == geneSet[n,]$accession,]$fullName)
      }
      if (leafLabel == "shortName") {
        labels[n] <- paste0(" ", orgName.df[orgName.df$accession == geneSet[n,]$accession,]$shortName)
      }

      if (treeType == "FULL") {
         labels[n] <- paste0(labels[n], " #", geneSet$rank[n])
      }
    }

    names(rRNAset) <- labels

  
    seq.dist.raw <- dist.dna(as.DNAbin(msa(rRNAset)), model = "raw", pairwise.deletion = FALSE)
    
    nj.tree <- bionj(seq.dist.raw)

    par(mfrow=c(1,1))
    par(cex.main = 2.0)
    plot(nj.tree, main = paste0("16S rRNA Dendrogram - Neighbor-Joining Algorithm (BIONJ)", "\n", plotIdentifier))
    add.scale.bar(cex = 1.5)
    
    # Retained from earlier code - maybe useful in fine-tuning the plot
    # layout(matrix(c(1,2), 2, 1), height = c(1, 0.2))
    # par(mar = c(0, 0, 2, 0) + 0.1)
    # plot(nj.tree, main = "NJ")

  }
}
