#' removeGenomes
#'
#' Removes a set of genomes from an RBiotools session
#'
#' @details The primary function of this function is to reclaim storage.
#'
#' @param accessionList character vector containing accession numbers of genomes to be removed from the RBiotools global data infrastructure
#'
#' @details All data for each organism specified in the \code{accessionList} parameter is removed from all \code{RBiotools} global data structuress, specifically:
#' \itemize{
#'   \item \code{GenomeSeqList}
#'   \item \code{orgName.df}
#'   \item \code{orgData.df}
#'   \item \code{wgsName.df}
#'   \item \code{ProdigalCalls}
#'   \item \code{RNAmmerCalls}
#'   \item \code{rRNAcalled.df}
#' }
#'
#' @return None
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"


removeGenomes <- function(accessionList) {

  ## For a list of organisms, remove data from
  ##   GenomeSeqList - genomic sequences in DNAstring format
  ##   orgName.df - data frame with organism identifiers
  ##   orgData.df - data frame with organism basic statistics
  ## The primary function is to reclaim storage, since sets of organisms for comparison
  ## are defined by lists of accession numbers, not by data in the sequence list or data frames.

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv) 
  get("orgData.df", envir = .GlobalEnv) 
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)

  for (uncheckedID in accessionList) {

    aaa <- checkIdentifier(unchecked)

    if (aaa %in% names(GenomeSeqList)) {

      cat(paste("Removing genome for organism with accession ID:", aaa, "\n"))

      GenomeSeqList[aaa] <<- NULL

      if ("accession" %in% colnames(orgName.df)) { orgName.df <<- subset(orgName.df, accession != aaa) }
      if ("accession" %in% colnames(orgData.df)) { orgData.df <<- subset(orgData.df, accession != aaa) }

      if ("accession" %in% colnames(ProdigalCalls)) { ProdigalCalls <<- subset(ProdigalCalls, accession != aaa) }
      if ("accession" %in% colnames(RNAmmerCalls) ) { RNAmmerCalls  <<- subset(RNAmmerCalls , accession != aaa) }

      # Data frame row names are by default indices.
      # The following statements reset the row names to a sequential order.
      # This is of no consequence, since row names are not used.

      if (nrow(orgName.df)    > 0) { row.names(orgName.df)    <<- 1:nrow(orgName.df)    }
      if (nrow(orgData.df)    > 0) { row.names(orgData.df)    <<- 1:nrow(orgData.df)    }
      if (nrow(ProdigalCalls) > 0) { row.names(ProdigalCalls) <<- 1:nrow(ProdigalCalls) }
      if (nrow(RNAmmerCalls)  > 0) { row.names(RNAmmerCalls)  <<- 1:nrow(RNAmmerCalls)  }
    }

    else {
      cat(paste("Genome for organism with accession ID:", aaa, "is not downloaded\n"))
    }

  }

}
