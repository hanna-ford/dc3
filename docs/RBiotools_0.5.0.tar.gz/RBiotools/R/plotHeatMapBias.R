#' plotHeatMapBias
#'
#' A function for plotting heatmaps for codon usage across a set of genomes
#'
#' @param accessionList character vector containing GenBank accession numbers
#' @param organismIdentifier character vector indicating the name to be used for organisms; options are \code{"fullName"} or \code{"shortName"}; \code{"fullName"} is recommended for a diverse, multi-species set of genomes; \code{"shortName"} is recommended for a single-species set of genomes
#' @param plotIdentifier character vector containing a title for the plot
#' @param colorPalette character vector indicating the color palette to be used in the heatmap; options are the color palettes from the \code{grDevices} package: \code{"cm"}, \code{"topo"}, \code{"terrain"}, \code{"heat"}, \code{"rainbow"}
#' @param plotMethod character vector indicating the R function to use for plotting the heatmap; options are \code{"heatmap"} from the \code{stats} package, \code{"heatmap.2"} from the \code{gplots} package, and \code{"pheatmap"} from the \code{"pheatmap"} package. This parameter is included during the development process. (See \strong{Development Notes} in the documentation for \code{plotHeatMapsAA}.) When the best function for postion bias heatmaps is determined, this parameter will likely be removed.
#'
#' @details A heatmap is a graphical representation of data in a matrix that uses color-coding to represent different data values. \code{plotHeatMapBias} plots heatmaps for postion bias across a set of genomes (one or more) using a variety of methods from several R packages.
#'
#' \strong{Development Notes}
#'
#' See notes in \code{plotHeatMapAA} documentation
#'
#' Heatmaps are displayed in a .PNG format in a window external to R Studio, rather than in the R Studio plot pane. This approach allows precise control over the size of the plot, which can vary significantly if visualized in the R Studio plot pane. \code{plotHeatMapBias} writes a file named \code{HeatMapBias.png} in the current working directory.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' myGenomes <- c("AP012306", "KK583188", "U00096", "CP000802", "CP000800")  # E. coli genomes
#' plotHeatMapBias(myGenomes)
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom data.table setDT
#' @importFrom gplots heatmap.2
#' @importFrom grDevices colors cm.colors dev.off heat.colors png rainbow terrain.colors topo.colors
#' @importFrom grid gpar textGrob unit
#' @importFrom pheatmap pheatmap
#' @importFrom seqinr s2c
#' @importFrom stats heatmap
#' @importFrom utils assignInNamespace


plotHeatMapBias <- function(accessionList, organismIdentifier = "shortName", plotIdentifier = NULL, colorPalette = "cm", plotMethod = "heatmap.2") {

  ## -----------
  ## --<BEGIN>-- Common code for all plotHeatMap functions
  ## -----------

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
    cat(paste("Initializing RBiotools\n"))
  }
 
  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)


  # Replace the accessionList with a list of identifiers that have been checked
  #   See the checkIdentifier function documentation

  checkedList <- character()
  for (uncheckedID in accessionList) {
    checkedID <- checkIdentifier(uncheckedID)
    checkedList <- c(checkedList, checkedID)
  }

  # Check whether organisms have been downloaded

  newList <- character()
  for (organism in checkedList) {
    if (!(organism %in% orgName.df$accession)) {  # Not downloaded
      downloadGenBank(organism)
      if (!(organism %in% orgName.df$accession)) {  # Download failed
        # cat(paste("Download of organism with accession", organism, "failed\n"))
        cat(paste("  Continuing plotHeatMapAA without", organism, "\n"))
      }
      else {
        newList <- c(newList, organism)
      }
    }
    else {  # Previously downloaded
      newList <- c(newList, organism)
    }
  }

  # Redefine checkedList, omiting any organisms for which downloading failed
  checkedList <- newList


# Alternate (better?) way to check whether genomes have been downloaded

#  for (organism in checkedList) {
#
#    seqSet <- GenomeSeqList[organism][[organism]]
#    if (is.null(seqSet)) {  # NOT downloaded
#      # cat(paste("Downloading genome with acccession ID:", organism, " from GenBank\n"))
#      downloadGenBank(organism)
#    }
#  }


  # Check whether protein genes have been called

  for (organism in checkedList) {
    proteins <- AAStringSet(ProdigalCalls[which(ProdigalCalls$accession == organism),]$protein)

    if (length(proteins@ranges@width) == 0) {
      cat(paste("Calling protein genes for accession ID:", organism, "\n"))
      runProdigal(organism, verbose = FALSE)
    }
  }


  ## Set the method to be used for plotting the heatmap

  if (plotMethod == "heatmap"  ) method <- "heatmap"   # Basic heatmap in R package "stats"
  if (plotMethod == "heatmap.2") method <- "heatmap.2" # Provides extensions to the basic heatmap; in R package gplots
  if (plotMethod == "pheatmap" ) method <- "pheatmap"  # Plots "pretty heatmaps" using R package pheatmap


  if (organismIdentifier == "longName") {
    organismIdentifier <- "fullName"
  }

  ## ---------
  ## --<END>-- Common code for all plotHeatMap functions
  ## ---------


  # Assemble the codon data

  biasCounts <- data.frame()

  for (organism in checkedList) {

    # Set up organism names to be used in the heatmap

    if (organismIdentifier == "fullName") {
      organismName <- paste0(" ", orgName.df[orgName.df$accession == as.name(organism),]$fullName)
    }
    if (organismIdentifier == "shortName") {
      organismName <- paste0(" ", orgName.df[orgName.df$accession == as.name(organism),]$shortName)
    }

    genes <- DNAStringSet(ProdigalCalls[which(ProdigalCalls$accession == organism),]$gene)

    # Sum codons across all genes

    allGenes <- paste(genes, sep = '', collapse = '')
    codonUse <- seqinr::count(s2c(as.character(allGenes)), 3, by = 3, alphabet = s2c("ACGT"))


    # Reorder the codons
    codonUse <- codonUse[c("ATT","ATG","ATC","ATA",
                           "AGT","AGG","AGC","AGA",
                           "ACT","ACG","ACC","ACA",
                           "AAT","AAG","AAC","AAA",
                           "TTT","TTG","TTC","TTA",
                           "TGT","TGG","TGC","TGA",
                           "TCT","TCG","TCC","TCA",
                           "TAT","TAG","TAC","TAA",
                           "GTT","GTG","GTC","GTA",
                           "GGT","GGG","GGC","GGA",
                           "GCT","GCG","GCC","GCA",
                           "GAT","GAG","GAC","GAA",
                           "CTT","CTG","CTC","CTA",
                           "CGT","CGG","CGC","CGA",
                           "CCT","CCG","CCC","CCA",
                           "CAT","CAG","CAC","CAA"
                          )]

    # Reorder the codons keeping 3rd postion together - this ordering is generally preferred
    codonUse <- codonUse[c("AAA","CAA","GAA","TAA",
                           "ACA","CCA","GCA","TCA",
                           "AGA","CGA","GGA","TGA",
                           "ATA","CTA","GTA","TTA",
                           "AAC","CAC","GAC","TAC",
                           "ACC","CCC","GCC","TCC",
                           "AGC","CGC","GGC","TGC",
                           "ATC","CTC","GTC","TTC",
                           "AAG","CAG","GAG","TAG",
                           "ACG","CCG","GCG","TCG",
                           "AGG","CGG","GGG","TGG",
                           "ATG","CTG","GTG","TTG",
                           "AAT","CAT","GAT","TAT",
                           "ACT","CCT","GCT","TCT",
                           "AGT","CGT","GGT","TGT",
                           "ATT","CTT","GTT","TTT"
                          )]

    codonUse <- as.data.frame(codonUse)

    # Add the codon names (codonUse row names) to the dataframe as a column
    # invisible(setDT(codonUse, keep.rownames = TRUE)[])

    names(codonUse) <- c("codon", "count")

    # Bias computation

    biasMatrix <- matrix(0L, nrow = 4, ncol = 3)
    rownames(biasMatrix) <- c("A","C","G","T")

    for (i in 1:nrow(codonUse)) {
      codon <- s2c(as.character(codonUse$codon[i]))
      for (j in 1:3) {
        biasMatrix[codon[j], j] <- biasMatrix[codon[j], j] + codonUse$count[i]
      }
    }

    # Coerce into a 1-column dataframe ...
    biasDF <- as.data.frame(c(biasMatrix))

    # ... and add row names
    biasDF$position <- c("1:A","1:C","1:G","1:T",
                         "2:A","2:C","2:G","2:T",
                         "3:A","3:C","3:G","3:T")

    names(biasDF) <- c("count", "position")

    # Scale the codon counts - is this the proper transformation to prepare for clustering?
    biasDF$scaled <- biasDF$count/max(biasDF$count)

    biasData <- as.data.frame(t(biasDF$scaled))
    colnames(biasData) <- biasDF$position
    rownames(biasData) <- organismName

    if (method == "pheatmap") { # This is a kludge that seems to fix margin problems
      colnames(biasData) <- paste0(" ", biasDF$position, " ")
      rownames(biasData) <- paste0(organismName , "  ")
    }
    if (method == "heatmap.2") { # This is a kludge that seems to fix margin problems between the labels and the plot
      colnames(biasData) <- paste0("\n", biasDF$position)
      rownames(biasData) <- paste0(organismName , "  ")
    }

    biasCounts <- rbind(biasCounts, biasData)
  }

  # Set the color palette

  colPal <- NULL

  if (colorPalette == "cm"     ) { colPal <- cm.colors(100)      }
  if (colorPalette == "heat"   ) { colPal <- heat.colors(100)    }
  if (colorPalette == "topo"   ) { colPal <- topo.colors(100)    }
  if (colorPalette == "terrain") { colPal <- terrain.colors(100) }
  if (colorPalette == "rainbow") { colPal <- rainbow(100)        }
  
  if (is.null(colPal)) {
    cat(paste0('Color palette "',  colorPalette, '" not recognized. Using color palette "cm"', '\n'))
    colPal <- cm.colors(100)
  }


  ## Plot the heatmap

  if (method == "pheatmap" ) {

    ## Overwrite default draw_colnames with a new version

    assignInNamespace(
      x = "draw_colnames",
      value = .draw_colnames_bias,
      ns = asNamespace("pheatmap")
    )

    # Set-up for call to pheatmap

    plotHeight = 1500 + length(checkedList) * 160
    png(filename = "HeatMapBias.png", width = 8000, height = plotHeight)

    par(                      # pheatmap uses grid graphics, so base graphics functions like par() is not going have an effect
        mar=c(70,80,70,70),
        lwd = 6, lty = 1      # These don't seem to have any effect - would like wider lines in the dendrograms
       )


    pheatmap(
      biasCounts,
    
      color = colPal,
      border_color = "gray60",
    
      treeheight_row = 1000,
      treeheight_col = 1000,
    
      fontsize = 100,
      fontsize_row = 70,
      fontsize_col = 90,

      legend = FALSE,
    
      display_numbers = TRUE,
      fontsize_number = 40,
      number_format = "%.3f",
    
      main = paste0("Position Bias - Relative Abundance", "\n", plotIdentifier)
    )

    dev.off()
  }


 
 
 
  if (method == "heatmap.2" ) {
    if (organismIdentifier == "shortName") { rMargin <-  60 }
    if (organismIdentifier == "fullName")  { rMargin <- 175 }
   
    plotHeight = 1500 + length(checkedList) * 120
    png(filename = "HeatMapBias.png", width = 8000, height = plotHeight)
   
    par(cex.main = 5.0,
        cex.axis = 4.0,
        mar = c(10,10,10,10),
        lwd = 6, lty = 1
        )
   
    heatmap.2(as.matrix(biasCounts),
              col = colPal,

              cexRow = 6,
              cexCol = 8,

              key = TRUE,
              keysize = 5,
              key.title = paste0("Position Bias Abundance", "\n", plotIdentifier),  # surrogate for title of entire plot
              key.xlab = NA,
              key.ylab = NA,
              key.par=list(mgp = c(3, 3, 0),
                           mar = c(5, 10, 20, 10),
                           cex = 1
                          ),
              tracecol = "black",

              density.info = "histogram",
              trace = "none",

              # main = paste0("Position Bias - Relative Abundance", "\n", plotIdentifier),
              main = NA,  # unable to adjust upper margin of plot to make space for title

              lwid = c(0.4, 1.6),
              lhei = c(0.5, 1.5),
              margins = c(20, rMargin),

              adjCol = 0.5,

              srtCol = 0    # column label rotation - not available in the "heatmap" function from package "stats"
             )

    dev.off()
  }




 
  if (method == "heatmap" ) {
    plotHeight = 1500 + length(checkedList) * 160
    png(filename = "HeatMapBias.png", width = 8000, height = plotHeight)

    par(cex.main = 5.0,
        cex.axis = 4.0,
        lwd = 6, lty = 1     # modify line width and type
    )

    heatmap(as.matrix(biasCounts),
            # Prepending a newline to the title in "main" moves it into the plot space, but
            #   it overwrites the column dendrogram.
            # main = paste0("\n", plotIdentifier)
            main = NA,      # unable to adjust upper margin of plot to make space for title

            col = colPal,
            cexRow = 6,
            cexCol = 6,

            margins = c(20,20)
    )

    dev.off()
  }


}



# Auxillary functions

# To display amino acid codes horizontally in the pheatmap plot, overwrite default draw_colnames in the pheatmap package namespace
# Modified code from Josh O'Brien at http://stackoverflow.com/questions/15505607

.draw_colnames_bias <- function (coln, gaps, ...) {
    coord = pheatmap:::find_coordinates(length(coln), gaps)
    x = coord$coord - 0.5 * coord$size
    res = textGrob(coln,
                    x = x,
                    y = unit(1, "npc") - unit(3,"bigpts"),
                    vjust = 1.5,
                    hjust = 0.5,
                    rot = 0,
                    gp = gpar(...)
                  )
    return(res)
}
