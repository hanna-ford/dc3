#' plotUsage
#'
#' A function for plotting the usage of amino acids or codons or the position bias for a genome or set of genomes
#'
#' @param accessionList character vector containing GenBank accession numbers
#' @param plotData character vector with values \code{"AA"} (amino acid), \code{"codon"} (codon), or \code{"positionBias"} (position bias)
#' @param codonOrder character vector with values "firstPosition" or "thirdPosition" (default)
#' @param plotType character vector with values "radar" or "circleBar" indicating the type of plot
#' @param plotColor character vector with an R-recognized color name or an RGB hex code, such as "\code{#FF0000}" for red
#' @param plotIdentifier character vector that is used in the chart title
#'
#' @details \code{plotUsage} creates "radar" charts (also known as "spider" charts) and "circle bar" charts (bar charts in polar coordinates) that show the usage of amino acids or codons or the position bias for a genome or set of genomes. In the specification of chart color, \code{plotUsage} recognizes 657 named colors known to R and all RGB hex codes, such as "\code{#FF0000}" for "red". If the user specifies a color that is not recognized, \code{plotUsage} outputs a message, choses a random color from the set of named colors, and creates the plot. Note that some of these colors are not particularly suitable for plotting. If the user specifies a plot identifier using the \code{plotIdentifier} parameter, the identifier will appear in the chart title. If a plot identifier is not specified and the \code{accessionList} parameter contains a single accession number, the full name of the organism is used as the identifer. If a plot identifier is not specified and the \code{accessionList} contains multiple accession numbers, "Multiple Organisms" is used as the identifier.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' E_coli <- c("AP012306", "KK583188", "U00096", "CP000802", "CP000800")
#'
#' # Create a radar plot for amino acid usage across the set of genomes in the E_coli list
#' plotUsage(E_coli)
#'
#' # Create a customized plot for the E_coli list
#' plotUsage(E_coli, plotData = "codon",
#'                   plotType = "circleBar",
#'                   plotColor = "darkred",
#'                   plotIdentifier = "Set of Escherichia coli Genomes")
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings AAStringSet alphabetFrequency
#' @importFrom data.table setDT
#' @importFrom fmsb radarchart
#' @importFrom ggplot2 aes coord_polar element_blank element_line element_rect element_text geom_bar ggplot guides labs rel scale_fill_manual scale_y_continuous theme
#' @importFrom grDevices colors col2rgb rgb
#' @importFrom grid gpar textGrob
#' @importFrom gridExtra grid.arrange
#' @importFrom seqinr count s2c






plotUsage <- function(accessionList, plotData = "AA", codonOrder = "thirdPosition", plotType = "radar", plotColor = "darkblue", plotIdentifier = NULL) {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
    cat(paste("Initializing RBiotools\n"))
  }

  # Replace the accessionList with a list of identifiers that have been checked
  #   See the checkIdentifier function documentation

  checkedList <- character()
  for (uncheckedID in accessionList) {
    checkedID <- checkIdentifier(uncheckedID)
    checkedList <- c(checkedList, checkedID)
  }

  # Check whether GenBank information for this genome has been downloaded

  for (checkedID in checkedList) {
    notDownloaded <- is.null(GenomeSeqList[[checkedID]])

    if (notDownloaded) {
      # cat(paste("Genome data for accession ID:", checkedID, "has not been downloaded\n"))
      downloadGenome(checkedID)
    }
  }


  ## Plot AA usage, codon usage, and position bias

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)

  # A function to check whether a color is recognized

  isColor <- function(aColor) {
    tryCatch(is.matrix(col2rgb(aColor)), error = function(e) FALSE)
  }

  if (!isColor(plotColor)) {
    cat(paste0('"', plotColor, '"', ' is not a recognized color.', '\n'))
    cat(paste0('   Choose a color recognized by R ... execute colors() to see a list ...', '\n'))
    cat(paste0('   ... or use an RGB hex code, such as "#FF0000" for red.', '\n'))

    plotColor <- colors()[sample(1:657,1)]
    cat(paste0('   Meanwhile, creating a plot using a random color: "', plotColor, '"\n'))
  }


  # Check the value of plotData

  if (!((plotData == 'AA') | (plotData == 'codon') | (plotData == 'positionBias'))) {
    cat(paste0('"', plotData, '"', ' is an unrecognized value for plotData\nRecognized values are "AA", "codon", and "positionBias"\n'))
  }

  # Check the value of plotType

  else if (!((plotType == 'radar') | (plotType == 'circleBar'))) {
    cat(paste0('"', plotType, '"', ' is an unrecognized value for plotType\nRecognized values are "radar" and "circleBar"\n'))
  }

  else {
  
    # If not set by user, set plotIdentifier to be used in title of plot

    if (is.null(plotIdentifier)) {
      if (length(checkedList) == 1) {
        plotIdentifier <- orgName.df[orgName.df$accession == as.name(checkedList[1]),]$fullName
      }
      else {
        plotIdentifier <- "Multiple Organisms"
      }
    }




  
    if (plotData == "AA") {

      # Extract protein sequences from the ProdigalCall global data store

      allProteins <- AAStringSet()
      
      for (aaa in checkedList) {
        # Check to see if Prodigal has been run for the accession number

        proteins <- AAStringSet(ProdigalCalls[which(ProdigalCalls$accession == aaa),]$protein)

        if (length(proteins@ranges@width) == 0) {
          # cat(paste0('No genes called for genome with accession ID: ', aaa, '\n'))
          # cat(paste0('  Execute runProdigal("', aaa, '") to predict proteins', '\n'))
          # cat(paste0('  Continuing without proteins from genome with accession ID: ', aaa, '\n'))

          # If genes have not been called, call them
          runProdigal(aaa)
          proteins <- AAStringSet(ProdigalCalls[which(ProdigalCalls$accession == aaa),]$protein)
        }
        # else {
        #   allProteins <- c(allProteins, proteins)
        # }

        # Replacement code
        allProteins <- c(allProteins, proteins)
      }

      # if (length(allProteins@ranges@width) == 0) {  # no data found
      #   stop('No genes called for any genomes in the accession list', '\n',
      #        '  Execution terminating ...', '\n', call. = FALSE)
      # }
      
      # Sum amino acids across all protein translations
      cat(paste0('Plotting AA usage across ', length(allProteins@ranges@width), ' proteins', '\n'))
      aaSum <- colSums(alphabetFrequency(allProteins))
  
      aaUse <- aaSum[c("A","V","L","I","F","Y","W","H","K","R","D","E","N","Q","S","T","M","C","P","G")]
      aaUse <- as.data.frame(aaUse)
  
      # Add the aaUse row names to the dataframe as a column
      invisible(setDT(aaUse, keep.rownames = TRUE)[])
  
      # Rename the dataframe columns
      names(aaUse) <- c("symbol", "count")
  
      # Scale the AA counts - is this the proper transformation to prepare for clustering?
      aaUse$scaled <- aaUse$count/max(aaUse$count)
  
      aaData = as.data.frame(t(aaUse$scaled))
      colnames(aaData) <- aaUse$symbol
      # rownames(aaData) <- organismName
      rownames(aaData) <- plotIdentifier
  
    }





    if ((plotData == "codon") | (plotData == "positionBias")) {

      allGenes <- DNAStringSet()
      
      for (aaa in checkedList) {
        # Check to see if Prodigal has been run for the accession number

        genes <- DNAStringSet(ProdigalCalls[which(ProdigalCalls$accession == aaa),]$gene)

        if (length(genes@ranges@width) == 0) {
          # cat(paste0('No genes called for genome with accession ID: ', aaa, '\n'))
          # cat(paste0('  Execute runProdigal("', aaa, '") to predict genes', '\n'))
          # cat(paste0('  Continuing without genes from genome with accession ID: ', aaa, '\n'))

          # If genes have not been called, call them
          runProdigal(aaa)
          genes <- DNAStringSet(ProdigalCalls[which(ProdigalCalls$accession == aaa),]$gene)

        }
        # else {
        #   allGenes <- c(allGenes, genes)
        # }

        allGenes <- c(allGenes, genes)
      }

      # if (length(allGenes@ranges@width) == 0) {  # no data found
      #   stop('No genes called for any genomes in the accession list', '\n',
      #        '  Execution terminating ...', '\n', call. = FALSE)
      # }
 
      # Paste the coding sequences together and count codons
      allGeneString <- paste(allGenes, sep = '', collapse = '')
      codonUse <- seqinr::count(s2c(as.character(allGeneString)), 3, by = 3, alphabet = s2c("ACGT"))
 
      # Reorder the codons
      if (codonOrder == "firstPosition") {
        codonUse <- codonUse[c("ATT","ATG","ATC","ATA",
                               "AGT","AGG","AGC","AGA",
                               "ACT","ACG","ACC","ACA",
                               "AAT","AAG","AAC","AAA",
                               "TTT","TTG","TTC","TTA",
                               "TGT","TGG","TGC","TGA",
                               "TCT","TCG","TCC","TCA",
                               "TAT","TAG","TAC","TAA",
                               "GTT","GTG","GTC","GTA",
                               "GGT","GGG","GGC","GGA",
                               "GCT","GCG","GCC","GCA",
                               "GAT","GAG","GAC","GAA",
                               "CTT","CTG","CTC","CTA",
                               "CGT","CGG","CGC","CGA",
                               "CCT","CCG","CCC","CCA",
                               "CAT","CAG","CAC","CAA"
                              )]
      }

      # Reorder the codons keeping 3rd postion together
      if (codonOrder == "thirdPosition") {
        codonUse <- codonUse[c("AAA","CAA","GAA","TAA",
                               "ACA","CCA","GCA","TCA",
                               "AGA","CGA","GGA","TGA",
                               "ATA","CTA","GTA","TTA",
                               "AAC","CAC","GAC","TAC",
                               "ACC","CCC","GCC","TCC",
                               "AGC","CGC","GGC","TGC",
                               "ATC","CTC","GTC","TTC",
                               "AAG","CAG","GAG","TAG",
                               "ACG","CCG","GCG","TCG",
                               "AGG","CGG","GGG","TGG",
                               "ATG","CTG","GTG","TTG",
                               "AAT","CAT","GAT","TAT",
                               "ACT","CCT","GCT","TCT",
                               "AGT","CGT","GGT","TGT",
                               "ATT","CTT","GTT","TTT"
                              )]
      }

      codonUse <- as.data.frame(codonUse)

      # Add the codon names (codonUse row names) to the dataframe as a column
      # invisible(setDT(codonUse, keep.rownames = TRUE)[])

      # Rename the dataframe columns
      names(codonUse) <- c("codon", "count")

      # Scale the codon counts - is this the proper transformation to prepare for clustering?
      codonUse$scaled <- codonUse$count/max(codonUse$count)

      codonData <- as.data.frame(t(codonUse$scaled))
      colnames(codonData) <- codonUse$codon
      # rownames(codonData) <- organismName
      rownames(codonData) <- plotIdentifier

      codonData <- codonData[,ncol(codonData):1]
      codonData = rbind(rep(max(codonData),ncol(codonData)) , rep(0,ncol(codonData)) , codonData)

      if (plotData == "positionBias") {

        biasMatrix = matrix(0L, nrow = 4, ncol = 3)
        rownames(biasMatrix) <- c("A","C","G","T")

        for (i in 1:nrow(codonUse)) {
          codon <- s2c(as.character(codonUse$codon[i]))
          for (j in 1:3) {
            biasMatrix[codon[j], j] <- biasMatrix[codon[j], j] + codonUse$count[i]
          }
        }
 
        # Coerce into a 1-column dataframe ...
        biasDF <- as.data.frame(c(biasMatrix))

        # ... and add row names
        biasDF$position <- c("1:A","1:C","1:G","1:T",
                             "2:A","2:C","2:G","2:T",
                             "3:A","3:C","3:G","3:T")

        names(biasDF) <- c("count", "position")

        # Scale the codon counts - is this the proper transformation to prepare for clustering?
        biasDF$scaled <- biasDF$count/max(biasDF$count)

        biasData <- as.data.frame(t(biasDF$scaled))
        colnames(biasData) <- biasDF$position
        # rownames(biasData) <- organismName
        rownames(biasData) <- plotIdentifier

        biasData <- biasData[,ncol(biasData):1]
        biasData = rbind(rep(max(biasData),ncol(biasData)) , rep(0,ncol(biasData)) , biasData)

      }
 
    }

  


  
    ## The plots
  
    # Set the colors and density for the radar plots

    pcRGB       <- col2rgb(plotColor)
    pc          <- rgb(pcRGB[1], pcRGB[2], pcRGB[3], maxColorValue = 255) 
        
    pColor      <- paste0(pc, "FF")

    # The two fill colors with different values for alpha produce approximately the same result
    pFillColor1 <- paste0(pc, "10")  # used in radar plots
    pFillColor2 <- paste0(pc, "70")  # used in circular bar plots

  
    if (plotData == "AA") {
  
      if (plotType == "radar") {
        # Reverse aaData, since radarchart plots counter-clockwise
        aaData <- aaData[,ncol(aaData):1]
  
        # Add maximum and minimum values for each axis - using 0 from minimum
        # Note: the maxmin parameter for radarchart does not seem to function properly
        aaData = rbind(rep(max(aaData),ncol(aaData)) , rep(0,ncol(aaData)) , aaData)

        radarchart(aaData, axistype = 0, centerzero = TRUE,
                   #custom polygon
                   pcol = pColor, pfcol = pFillColor1, plwd = 4, plty = 1, pdensity = 200, pty = 32,

                   #custom grid
                   cglcol = "grey", cglty = 1, axislabcol = "grey", cglwd = 0.8,

                   #custom labels
                   vlcex = 2.5,

                   # title - there does not seem to be any way to format the title of a radarchart
                   title = paste0("Amino Acid Usage", "\n", plotIdentifier)
        )
      }

  
      if (plotType == "circleBar") {

        ## Note: The two lines of code below that are commented out and replaced by the two lines immediately following
        ##       will create a plot that uses the default ggplot2 colour palette.

        # Set "levels" to keep the specified order of the AA symbols
#       aaPlot <- ggplot(aaUse, aes(factor(symbol, levels = symbol), count, fill = factor(symbol))) + geom_bar(stat = "identity", width = 1) + guides(fill = FALSE) + theme(
        aaPlot <- ggplot(aaUse, aes(factor(symbol, levels = symbol), count, fill = factor(symbol))) + geom_bar(stat = "identity", color = pColor, width = 1) + guides(fill = FALSE) + theme(
          panel.background = element_rect(fill = NA),
          panel.grid.major = element_line(colour = "grey90"),
          panel.ontop = FALSE
#       )
        ) + scale_fill_manual(values = rep(pFillColor2, 20))
  
        # Switch to polar coordinates
        aaPlot <- aaPlot + scale_y_continuous(breaks = 0:10) + coord_polar() + labs(x = "", y = "")
  
        # Clean up the labeling
        aaPlot <- aaPlot + theme(axis.text = element_text(size = rel(3)), axis.text.y = element_blank(), axis.ticks.y = element_blank())

        # Add a title
        plotTitle <- paste0("Amino Acid Usage", "\n", plotIdentifier)

        grid.arrange(textGrob(plotTitle, gp = gpar(fontsize = 22, fontface = "bold")), 
             aaPlot, 
             heights = c(0.1, 1))
      }
    }

    if (plotData == "codon" ) {
      if (plotType == "radar") {

        radarchart(codonData, axistype = 0, centerzero = TRUE,
                   #custom polygon
                   pcol = pColor, pfcol = pFillColor1, plwd = 1, plty = 1, pdensity = 200, pty = 32,

                   #custom grid
                   cglcol = "grey", cglty = 1, axislabcol = "grey", cglwd = 0.8,

                   #custom labels
                   vlcex = 0.8,

                   # title - there does not seem to be any way to format the title of a radarchart
                   title = paste0("Codon Usage", "\n", plotIdentifier)
        )

      }

      if (plotType == "circleBar") {

        ## Note: The two lines of code below that are commented out and replaced by the two lines immediately following
        ##       will create a plot that uses the default ggplot2 colour palette.

#       codonPlot <- ggplot(codonUse, aes(factor(codon, levels = codon), count, fill = factor(codon))) + geom_bar(stat = "identity", width = 1) + guides(fill = FALSE) + theme(
        codonPlot <- ggplot(codonUse, aes(factor(codon, levels = codon), count, fill = factor(codon))) + geom_bar(stat = "identity", color = pColor, width = 1, size = 0.1) + guides(fill = FALSE) + theme(
          panel.background = element_rect(fill = NA),
          panel.grid.major = element_line(colour = "grey90"),
          panel.ontop = FALSE
#       )
        ) + scale_fill_manual(values = rep(pFillColor2, 64))

        codonPlot <- codonPlot + scale_y_continuous(breaks = 0:10) + coord_polar() + labs(x = "", y = "")
        codonPlot <- codonPlot + theme(axis.text = element_text(size = rel(1)), axis.text.y = element_blank(), axis.ticks.y = element_blank())
    
        # Add a title
        plotTitle <- paste0("Codon Usage", "\n", plotIdentifier)
        
        grid.arrange(textGrob(plotTitle, gp = gpar(fontsize = 22, fontface = "bold")),
             codonPlot, 
             heights = c(0.1, 1))

        # print(codonPlot)
      }
    }

    if (plotData == "positionBias" ) {

      if (plotType == "radar") {
        radarchart(biasData, axistype = 0, centerzero = TRUE,
                   #custom polygon
                   pcol = pColor, pfcol = pFillColor1, plwd = 4, plty = 1, pdensity = 200, pty = 32,

                   #custom grid
                   cglcol = "grey", cglty = 1, axislabcol = "grey", cglwd = 0.8,

                   #custom labels
                   vlcex = 2.5,

                   # title - there does not seem to be any way to format the title of a radarchart
                   title = paste0("Postion Bias", "\n", plotIdentifier)
        )

      }

      if (plotType == "circleBar") {

        ## Note: The two lines of code below that are commented out and replaced by the two lines immediately following
        ##       will create a plot that uses the default ggplot2 colour palette.

#       biasPlot <- ggplot(biasDF, aes(factor(position, levels = position), count, fill = factor(position))) + geom_bar(stat = "identity", width = 1) + guides(fill = FALSE) + theme(
        biasPlot <- ggplot(biasDF, aes(factor(position, levels = position), count, fill = factor(position))) + geom_bar(stat = "identity", color = pColor, width = 1) + guides(fill = FALSE) + theme(
          panel.background = element_rect(fill = NA),
          panel.grid.major = element_line(colour = "grey90"),
          panel.ontop = FALSE
#       )
        ) + scale_fill_manual(values = rep(pFillColor2, 12))
        
        biasPlot <- biasPlot + scale_y_continuous(breaks = 0:10) + coord_polar() + labs(x = "", y = "")
        biasPlot <- biasPlot + theme(axis.text = element_text(size = rel(3)), axis.text.y = element_blank(), axis.ticks.y = element_blank())

        # Add a title
        plotTitle <- paste0("Position Bias", "\n", plotIdentifier)

        grid.arrange(textGrob(plotTitle, gp = gpar(fontsize = 22, fontface = "bold")),
             biasPlot,
             heights = c(0.1, 1))
      }
    }
  }
}
