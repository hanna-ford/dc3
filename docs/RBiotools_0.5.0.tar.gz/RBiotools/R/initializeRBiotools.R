#' initializeRBiotools
#'
#' Initialize the global data store for an \code{RBiotools} session
#'
#' @param None
#'
#' @details This function initializes the global data structures that collectively constitute the global data store for an \code{RBiotools} session. This global data store makes the writing and reading of temporary files unnecessary.
#'
#' \code{RBiotools} global data structures:
#' \itemize{
#'   \item \code{GenomeSeqList} -- an R list of named \code{DNAStringSets}, each of which is a genomic sequence identified by an accession number
#'   \item \code{orgName.df} -- an R data frame containing genome identifiers
#'   \item \code{orgData.df} -- an R data frame containing genome data, including sequence length, AT content, and gene counts
#'   \item \code{wgsName.df} -- an R data frame containing alternative names for WGS projects
#'   \item \code{ProdigalCalls} -- an R data frame containing Prodigal called genes, locations, scores, and nucleotide and protein sequences for a set of genomes
#'   \item \code{RNAmmerCalls} -- an R data frame containing RNAmmer called genes, locations, scores, and nucleotide sequences for a set of genomes
#'   \item \code{rRNAcalled.df} -- an R data frame that tracks which types of rRNA genes have been called by RNAmmer for a set of genomes
#' }
#'
#' \emph{\strong{Note:} \code{initializeRBiotools} will seldom, if ever, need to be called directly by the \code{RBiotools} user. \code{RBiotools} functions will automatically initialize the global data store, if necessary.}
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' initializeRBiotools()
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"





initializeRBiotools <- function() {

  ## Initialize GLOBAL variables

  ## List to hold GenBank data
  GenomeSeqList <<- list()

  ## Data Frame to hold organism information
  ##   We have to insert a dummy row because rbind will not add new rows to a 0-row data frame

  orgName.df <<- data.frame(
    accession = "NONE",
    stringsAsFactors = FALSE
  )

  orgData.df <<- data.frame(
    accession  = "NONE",
    stringsAsFactors = FALSE
  )

  ## Data Frame to hold alternative names for WGS projects
  ## Note: The labels are not 100% consistent with NCBI terminology

  wgsName.df <<- data.frame(
    WGS_Prefix       = "NONE",
    WGS_Project      = "NONE",
    WGS_Caption      = "NONE",
    WGS_Locus        = "NONE",
    GenBank_Assembly = "NONE",
    RefSeq_Assembly  = "NONE",
    GenomeID         = "NONE",
    scaffolds        = "NONE",
    contigs          = "NONE",
    stringsAsFactors = FALSE
  )


  ## Data frame to hold Prodigal gene calls for a set of organisms
  ProdigalCalls <<- data.frame()

  ## Data frame to hold RNAmmer gene calls for a set of organisms ...
  RNAmmerCalls <<- data.frame()

  ## ... and a data frame to track WHICH types of rRNA genes have been called
  rRNAcalled.df <<- data.frame(
    accession  = "NONE",
    stringsAsFactors = FALSE
  )

}
