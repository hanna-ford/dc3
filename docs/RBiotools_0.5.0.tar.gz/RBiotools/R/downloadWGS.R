#' downloadWGS
#'
#' Downloads genomic information for a set of Whole Genome Shotgun sequencing projects into an RBiotools session
#'
#' @param accessionList character vector containing GenBank accession numbers
#'
#' @details This function fetches information for a set of WGS (Whole Genome Shotgun) sequencing projects specified by accession numbers. If an accession number corresponds to a contig in a WGS sequencing project, it is \emph{\strong{replaced with the accession number for the entire project}}, and all project sequences (scaffolds or contigs) are downloaded. \code{downloadWGS} uses \code{rentrez} functions that work with the NCBI Eutils API to search and download data from the GenBank nucleotide database. It catches errors -- both from the user, such as invalid accession numbers or accession numbers that do not correspond to WGS projects, and from GenBank, such as violations of access policies (not expected) -- and skips any accession number that causes an error.
#' For each WGS contig accession number, \code{entrez_fetch} downloads a FASTA file of the contig sequence and \code{entrez_summary} downloads genomic information, including identifiers, taxonomy, and counts of various types of genes -- protein encoding, pseudo, and RNA -- which are summed for entry into the \code{orgData.df} data frame.
#'
#' \strong{Note:} The gene counts in \code{orgData.df} are those downloaded from GenBank by \code{entrez_summary}. These counts may differ from the number of genes called by Prodigal or RNAmmer.
#'
#' \emph{\strong{Note:} \code{downloadWGS} will seldom, if ever, need to be called directly by the \code{RBiotools} user. \code{RBiotools} functions will automatically initiate downloads from GenBank, if necessary.}
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' accessionIDs <- c(
#'   "REQD01000000",  # Listeria monocytogenes strain PNUSAL004150  (9 sequences)
#'   "PJKH01000000"   # Akkermansia muciniphila strain GP11  (42 sequences)
#' )
#'
#' downloadWGS(accessionIDs)
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom Biostrings DNAString DNAStringSet letterFrequency
#' @importFrom RCurl merge.list
#' @importFrom rentrez entrez_fetch entrez_summary



downloadWGS <- function(accessionList) {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
    cat(paste("Initializing RBiotools\n"))
  }

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)

  for (aaa in accessionList) {

    skip <- FALSE
    done <- FALSE

    ## Check if accession ID is valid and catch errors

    goodDownload <- tryCatch(
      {
        summary <- entrez_summary(db = "nucleotide", id = aaa)
        flag <- TRUE
      },
      error = function(e) {
        cat(paste0("   In downloadWGS: An error occured in downloading ", aaa, ": ", e, " Skipping this WGS.\n"))
        flag <- FALSE
      }
    )

    if (goodDownload) {   # valid accession ID
      title <- summary$title

      if (grep("whole genome shotgun", title) == 1) {      # accession number from a WGS project
        # do nothing
      }
      else {
        cat(paste("Accession ID:", aaa, "does not appear to be a WGS accession number\n"))
        skip <- TRUE
      }
    }
    else {   # invalid accession ID
      cat(paste("Accession ID:", aaa, "is not a valid accession number\n"))
      skip <- TRUE
    }


    if (!skip) {
      done <- !is.null(GenomeSeqList[[aaa]])
      if (done) {  ## Genome data HAS been downloaded
        cat(paste("Genome data for accession ID:", aaa, "has already been downloaded\n"))
      }
    }

    if (!done && !skip) {

      ## Download the genome data ...

      cat(paste("Downloading genome data for organism with accession ID:", aaa, "\n"))

      ##---------------------------------------##
      ## Initialize variables prior to looping ##
      ##---------------------------------------##

      # Extract the prefix and counter for pre-2019 or 2019+ WGS "LOCUS" identifiers

      prefix  <- gsub('(^[[:upper:]]+[[:digit:]]{2}).*$', '\\1', aaa)
      counter <- gsub('^[[:upper:]]+[[:digit:]]{2}(.*$)', '\\1', aaa)

      seqSet <- DNAStringSet()

      ## Add data to the organism data frames

      info <- entrez_summary(db = "nucleotide", id = aaa)
      s    <- info$statistics  # an informative table, but the number of entries is inconsistent.
  
      if (info$completeness == "complete") { complete <- "YES" }
      else                                 { complete <- "NO"  }




      ## Extract names for organism

      organismName <- info$organism
      fullName     <- organismName    # fullName may be redefined if a strain or substrain is found

      # Check for strain and substrain names
      # ... and construct "fullName" -- the organism name with strain and substrain names appended

      # ------
      # To Do: Consider organisms that have no "strain" or "substrain" but do have "serovar" or "isolate"
      #   This would likely require adding columns to the global dataframe orgName.df
      # ------
      
      strainName    <- NA
      substrainName <- NA
      shortName     <- NA

      subTypes <- unlist(strsplit(info$subtype, "\\|"))
      subNames <- unlist(strsplit(info$subname, "\\|"))
      for (i in 1:length(subTypes)) {
        if (subTypes[i] == "strain") {
          strainName <- subNames[i]
          if (grepl(strainName, organismName)) { fullName <-       organismName                      }
          else                                 { fullName <- paste(organismName, "str.", strainName) }
          shortName <- strainName
        }
        if (subTypes[i] == "sub_strain") {
          substrainName <- subNames[i]
          if (grepl(substrainName, organismName)) { fullName <-       organismName                            }
          else                                    { fullName <- paste(organismName, "substr.", substrainName) }
          shortName <- paste(strainName, "substr.", substrainName)
        }
      }

      # The following is NOT a very good way to handle organisms with no strain or substrain,
      #   particularly if there are multiple such organisms in the same analysis

      if (is.na(strainName) && is.na(substrainName)) {
        strainName <- "no-strain"
        shortName  <- strainName
        fullName   <- paste(organismName, "str.", strainName)
      }

      newRow <- data.frame(accession  = aaa,
                           version    = info$accessionversion,
                           complete   = complete,
                           organism   = organismName,
                           strain     = strainName,
                           substrain  = substrainName,
                           fullName   = fullName,
                           shortName  = shortName,
                           taxonomyID = info$taxid,
                           GInumber   = info$gi,
                           stringsAsFactors = FALSE
                          )

      if (orgName.df$accession[1] == "NONE") {
        orgName.df <<- newRow
      }
      else {
        orgName.df <<- rbind(orgName.df, newRow)     ## assignment to a global variable
      }


      total_cnt_Genes   <- 0
      total_cnt_CDS     <- 0
      total_cnt_pseudo  <- 0
      total_cnt_RNA     <- 0
      total_cnt_rRNA    <- 0
      total_cnt_tRNA    <- 0
      total_cnt_ncRNA   <- 0
      total_cnt_tmRNA   <- 0
      total_cnt_miscRNA <- 0


      ##---------------------##
      ## Loop over sequences ##
      ##---------------------##

      sequences_downloaded <- 0

      check_next <- TRUE
      while (check_next) {

        if (nchar(counter) == 6) { counter <- sprintf("%06d", as.integer(counter) + 1) }
        if (nchar(counter) == 7) { counter <- sprintf("%07d", as.integer(counter) + 1) }
        # ... if necessary with future WGS identifiers

        contig <- paste(prefix, counter, sep = "")

        goodDownload <- tryCatch(     # End loop when a download that produces an error ...
                                      # ... indicating that all sequences have been processed
          {
            fasta <- entrez_fetch(db = "nucleotide", id = contig, rettype = "fasta")
            flag <- TRUE
          },
          error = function(e) {
            flag <- FALSE
          }
        )

        if (goodDownload) {

          # Commented out ... there may be MANY scaffolds or contigs for some WGS projects 
          # cat(paste0("     Downloading ", contig, "\n"))

          sequences_downloaded <- sequences_downloaded + 1   # Count and report after end of download loop

          fasta <- sub("\n", "|", fasta)
          fasta <- strsplit(fasta, "\\|")

          org <- fasta[[1]][1]

          org <- gsub(">", "", org)
          org <- sub(" ", "|", org)
          org <- strsplit(org, "\\|")

          seq <- fasta[[1]][2]
          seq <- gsub("\n", "", seq)

          seqSet <- DNAStringSet(c(seqSet, DNAStringSet(as.character(seq))))



          goodInfo <- tryCatch (     # Check for the existence of an entrez summary
                                     #   Note: WGS sequences PJKH01000001 to PJKH01000042 had summaries in June 2018 ...
                                     #   ... in February 2019, entrez_summary for these contigs returns this error:
                                     #   Error: No esummary records found in file
            {
              info <- entrez_summary(db = "nucleotide", id = contig)
              flag <- 0
            },
            warning=function(w) {
              flag <- 1
            },
            error = function(e) {
              flag <- 2
            }
          )


          if (goodInfo == 0) {
            s <- info$statistics

            # Parse the summary statistics table returned via Entrez

            cnt_Genes   <- s[which(s$type == "gene"     & is.na(s$subtype)           & is.na(s$source)),]$count
            cnt_CDS     <- s[which(s$type == "cdregion" & s$subtype == "CDS"         & is.na(s$source)),]$count
            cnt_pseudo  <- s[which(s$type == "gene"     & s$subtype == "Gene/pseudo" & is.na(s$source)),]$count
            cnt_RNA     <- s[which(s$type == "rna"      & is.na(s$subtype)           & is.na(s$source)),]$count
            cnt_rRNA    <- s[which(s$type == "rna"      & s$subtype == "rRNA"        & is.na(s$source)),]$count
            cnt_tRNA    <- s[which(s$type == "rna"      & s$subtype == "tRNA"        & is.na(s$source)),]$count
            cnt_ncRNA   <- s[which(s$type == "rna"      & s$subtype == "ncRNA"       & is.na(s$source)),]$count
            cnt_tmRNA   <- s[which(s$type == "rna"      & s$subtype == "tmRNA"       & is.na(s$source)),]$count
            cnt_miscRNA <- s[which(s$type == "rna"      & s$subtype == "misc_RNA"    & is.na(s$source)),]$count

            # Check for integer(0) values

            if (identical(cnt_Genes  , integer(0)))  { cnt_Genes   <- 0 }
            if (identical(cnt_CDS    , integer(0)))  { cnt_CDS     <- 0 }
            if (identical(cnt_pseudo , integer(0)))  { cnt_pseudo  <- 0 }
            if (identical(cnt_RNA    , integer(0)))  { cnt_RNA     <- 0 }
            if (identical(cnt_rRNA   , integer(0)))  { cnt_rRNA    <- 0 }
            if (identical(cnt_tRNA   , integer(0)))  { cnt_tRNA    <- 0 }
            if (identical(cnt_ncRNA  , integer(0)))  { cnt_ncRNA   <- 0 }
            if (identical(cnt_tmRNA  , integer(0)))  { cnt_tmRNA   <- 0 }
            if (identical(cnt_miscRNA, integer(0)))  { cnt_miscRNA <- 0 }

            total_cnt_Genes   <- total_cnt_Genes   + cnt_Genes
            total_cnt_CDS     <- total_cnt_CDS     + cnt_CDS
            total_cnt_pseudo  <- total_cnt_pseudo  + cnt_pseudo
            total_cnt_RNA     <- total_cnt_RNA     + cnt_RNA
            total_cnt_rRNA    <- total_cnt_rRNA    + cnt_rRNA
            total_cnt_tRNA    <- total_cnt_tRNA    + cnt_tRNA
            total_cnt_ncRNA   <- total_cnt_ncRNA   + cnt_ncRNA
            total_cnt_tmRNA   <- total_cnt_tmRNA   + cnt_tmRNA
            total_cnt_miscRNA <- total_cnt_miscRNA + cnt_miscRNA
          }
        }
        else { # Contig downloading has been completed ...
          check_next <- FALSE
        }
      }

      cat(paste0("     Number of sequences downloaded: ", sequences_downloaded, "\n"))

      ## Insert sequences into the GenBankList as a DNAStringSet with the WGS project accession ID as its name
      #    Name the new element of the GenomeSeqList
      #    Note: creating a separate list and then merging is a way to name the sequence with its accession number

      newList <- list()
      newList <- c(newList, seqSet)
      names(newList) <- aaa

      # Note assignment to global variable - DANGEROUS!!!
      GenomeSeqList <<- merge.list(GenomeSeqList, newList)


      ## Update the orgData.df table

      N_count <- sum(letterFrequency(seqSet, "N"))   # used for more accurate calculation of AT content
      seqLength <- sum(seqSet@ranges@width)
     
      newRow <- data.frame(accession   = aaa,
                           organism    = organismName,
                           strain      = strainName,
                           seq_length  = seqLength,
                           AT_content  = paste0(sprintf("%4.2f", as.double(sum(letterFrequency(seqSet, "AT"))*100) / as.double(seqLength - N_count)), "%"),
                 ##  The following data are not (typically) available for WGS sequencing projects
                           num_Genes   = total_cnt_Genes,
                           num_CDS     = total_cnt_CDS,
                           num_pseudo  = total_cnt_pseudo,
                           num_RNA     = total_cnt_RNA,
                           num_rRNA    = total_cnt_rRNA,
                           num_tRNA    = total_cnt_tRNA,
                           num_ncRNA   = total_cnt_ncRNA,
                           num_tmRNA   = total_cnt_tmRNA, 
                           num_miscRNA = total_cnt_miscRNA, 
                           stringsAsFactors = FALSE
                          )

      if (orgData.df$accession[1] == "NONE") {
        orgData.df <<- newRow
      }
      else {
        orgData.df <<- rbind(orgData.df, newRow)     ## assignment to a global variable
      }


      # Initialize the rRNAcalled dataframe

      newRow <- data.frame(accession = aaa,
                           type      = "TSU",              ## 5S
                           called    = FALSE,
                           stringsAsFactors = FALSE
                          )

      if (rRNAcalled.df$accession[1] == "NONE") {
        rRNAcalled.df <<- newRow
      }
      else {
        rRNAcalled.df <<- rbind(rRNAcalled.df, newRow)
      }

      newRow <- data.frame(accession = aaa,
                           type      = "SSU",              ## 16S
                           called    = FALSE,
                           stringsAsFactors = FALSE
                          )
      rRNAcalled.df <<- rbind(rRNAcalled.df, newRow)

      newRow <- data.frame(accession = aaa,
                           type      = "LSU",              ## 23S
                           called    = FALSE,
                           stringsAsFactors = FALSE
                          )
      rRNAcalled.df <<- rbind(rRNAcalled.df, newRow)
    }
  }
}
