#' plotPanCore
#'
#' Creates a pan-core figure for a pan-genome
#'
#' @param homologyMatrix a dataframe constructed by \code{runLinclust} containing protein grouping information
#' @param xAxis character vector indicating the labels to be used for organisms; options are \code{"accession"} (default), \code{"fullName"}, or \code{"shortName"}
#' @param title character vector containing the title for the Pan-Core figure
#'
#' @details \code{plotPanCore} creates a pan-core plot using gene-grouping information in a homology matrix contructed using \code{runLinclust}.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' myGenomes <- c("AP012306", "KK583188", "U00096", "CP000802", "CP000800") # E. coli genomes
#' homologyMatrix <- runLinclust(myGenomes)
#' plotPanCore(homologyMatrix)
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom ggplot2 aes geom_line geom_point ggplot ggtitle theme ylab




plotPanCore <- function(homologyMatrix, xAxis = "accession", title = "") {

  orthologCounts <- as(homologyMatrix, 'matrix')
  
  rrr <- nrow(orthologCounts)
  ccc <- ncol(orthologCounts)
  
  ## cat(paste0("rows: ", rrr, "     columns: ", ccc, "\n"))
  
  oCntBinary <- orthologCounts

  for (i in 1:rrr) {
    for (j in 1:ccc) {
      oCntBinary[i,j] <- 0
      if (orthologCounts[i,j] > 0) {
        oCntBinary[i,j] <- 1
      }
    }
  }
  
  counts <- data.frame(matrix(ncol = 4, nrow = 0))

  Pan       <- 0
  Core      <- 0
  Accessory <- 0
  Singleton <- 0
  
  for (i in 1:rrr) {
    if (oCntBinary[i,1]) {
      Pan  <- Pan  + 1
      Core <- Core + 1
    }
  }
  
  # cat(paste(Pan, Core, Accessory, Singleton,"\n"))
  


  genome  <- 1
  accNum <- colnames(orthologCounts)[1]
  if (xAxis == "accession") {
    organism <- accNum
  }
  if (xAxis == "shortName") {
    organism <- orgName.df[orgName.df$accession == accNum,]$shortName
  }
  if (xAxis == "fullName") {
    organism <- orgName.df[orgName.df$accession == accNum,]$fullName
  }

  ordering <- organism

  counts <- rbind(counts, c(organism, genome, Pan,       "Pan"      ))
  counts <- rbind(counts, c(organism, genome, Core,      "Core"     ))
  counts <- rbind(counts, c(organism, genome, Accessory, "Accessory"))
  counts <- rbind(counts, c(organism, genome, Singleton, "Singleton"))

  for (j in 2:ccc) {

    genome   <- j
    accNum <- colnames(orthologCounts)[j]
    if (xAxis == "accession") {
      organism <- accNum
    }
    if (xAxis == "shortName") {
      organism <- orgName.df[orgName.df$accession == accNum,]$shortName
    }
    if (xAxis == "fullName") {
      organism <- orgName.df[orgName.df$accession == accNum,]$fullName
    }

    ordering <- c(ordering, organism)

    Pan       <- 0
    Core      <- 0
    Accessory <- 0
    Singleton <- 0
    for (i in 1:rrr) {
      sss <- sum(oCntBinary[i,1:j])
      if (sss == 0) {
      }
      else {
        if (sss == 1) {
          Pan       <- Pan       + 1
          Singleton <- Singleton + 1
        }
        else {
          if (sss == j) {
            Pan  <- Pan  + 1
            Core <- Core + 1
          }
          else {
            Pan       <- Pan       + 1
            Accessory <- Accessory + 1
          }
        }
      }
    }

    # cat(paste(Pan, Core, Accessory, Singleton,"\n"))

    counts <- rbind(counts, c(organism, genome, Pan,       "Pan"      ))
    counts <- rbind(counts, c(organism, genome, Core,      "Core"     ))
    counts <- rbind(counts, c(organism, genome, Accessory, "Accessory"))
    counts <- rbind(counts, c(organism, genome, Singleton, "Singleton"))
  }

  colnames(counts) <- c("organism", "genome", "val", "type")

  counts$genome   <- as.numeric(as.character(counts$genome))
  counts$val      <- as.numeric(as.character(counts$val))
  counts$organism <- factor(as.character(counts$organism), levels = ordering)
  
  
  ggplot(counts, aes(x=organism, y=val, colour=type, group=type)) +
    geom_line(size = 1) +
    geom_point() +
    theme(axis.text.x = element_text(angle = -30, vjust = 1, hjust = 0)) +
    ylab(NULL) +
    theme(legend.title=element_blank()) +
    theme(plot.title = element_text(hjust = 0.5)) +
    ggtitle(title)

}
